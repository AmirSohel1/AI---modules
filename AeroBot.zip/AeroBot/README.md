# AeroGPT - Local AI Chatbot

A complete, working, fully structured local chatbot application with a calm, warm Claude-inspired user interface, built with an Angular standalone frontend, Tailwind CSS, and a Python FastAPI backend powered by the `openai` client.

Runs **strictly on your local machine (`localhost`)**. No Docker, no external databases, no cloud authentication, no telemetry.

---

## Architecture & Project Structure

```
chatbot/
├── backend/
│   ├── app/
│   │   ├── main.py            # FastAPI app, CORS configuration, router registration
│   │   ├── config.py          # Environment settings loader (.env)
│   │   ├── routes/chat.py     # /api/chat and /api/chat/stream endpoints
│   │   ├── services/llm.py    # OpenAI client wrapper (synchronous & SSE streaming)
│   │   └── schemas/chat.py    # Pydantic request/response validation models
│   ├── requirements.txt       # Backend dependencies
│   ├── .env.example           # Environment template
│   └── .env                   # Local environment configuration
├── frontend/
│   ├── src/
│   │   ├── environments/      # API URL configuration (http://localhost:8000)
│   │   ├── app/
│   │   │   ├── core/
│   │   │   │   ├── models/    # message.model.ts, conversation.model.ts
│   │   │   │   └── services/  # chat.service.ts, storage.service.ts, voice.service.ts
│   │   │   ├── layout/        # sidebar (search, groups, export, delete), header
│   │   │   ├── features/chat/ # chat-window, message-list, message-bubble, chat-input, welcome-screen
│   │   │   └── shared/        # markdown.pipe.ts (syntax highlighting), copy-button.component.ts
│   │   ├── styles.css         # Tailwind base, dark mode, typography & code highlight
│   │   └── index.html
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   └── package.json
└── README.md                  # Setup and execution guide
```

---

## 1. Prerequisites

- **Python 3.10+** (tested with Python 3.13)
- **Node.js 18+ / 22+** and **npm**

---

## 2. Backend Setup & Run

Open a terminal and navigate to `chatbot/backend`:

```bash
cd chatbot/backend
```

### 1. Create and activate a virtual environment
- **macOS / Linux:**
  ```bash
  python3 -m venv .venv
  source .venv/bin/activate
  ```
- **Windows (PowerShell):**
  ```powershell
  python -m venv .venv
  .\.venv\Scripts\Activate.ps1
  ```
- **Windows (Command Prompt):**
  ```cmd
  python -m venv .venv
  .\.venv\Scripts\activate.bat
  ```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Configure environment variables
Copy the example file:
```bash
cp .env.example .env
```
*(On Windows: `copy .env.example .env`)*

Edit `.env` as needed:
```env
API_KEY=your_openai_or_compatible_api_key
BASE_URL=
MODEL=anthropic.claude-sonnet-5
TEMPERATURE=0.7
FRONTEND_ORIGIN=http://localhost:4200
```
> **Note**: If `API_KEY` is not set or set to `mock`, the backend automatically runs in safe development mock mode, streaming responsive replies so you can preview the full application UI and streaming mechanics without needing a live paid key right away. When you provide a valid `API_KEY` (and optional `BASE_URL`), it calls the live LLM endpoint via the `openai` SDK.

### 4. Start the backend server
```bash
uvicorn app.main:app --reload --port 8000
```

The backend starts at `http://localhost:8000`.
- Health check: `http://localhost:8000/api/health`

---

## 3. Frontend Setup & Run

Open a second terminal and navigate to `chatbot/frontend`:

```bash
cd chatbot/frontend
```

### 1. Install packages
```bash
npm install
```

### 2. Start the development server
```bash
npx ng serve
```
*(or `npm start`)*

The frontend starts at `http://localhost:4200`.

---

## 4. Key Features & AeroGPT UI Highlights

1. **🎙️ Voice Command & Speech Interaction (100% Local)**:
   - **Voice Input (Speech-to-Text)**: Microphone button in the input bar captures your voice live, transcribing speech directly into the prompt box. You can say *"send"* to submit immediately by voice.
   - **Voice Output (Text-to-Speech)**: Read aloud button (`Read`) on each assistant response naturally vocalizes replies without any cloud voice fees.
2. **Conversation Search & Chronological Grouping**:
   - Conversations are grouped into **Today**, **Yesterday**, **Previous 7 Days**, and **Older**.
   - Live search bar filters through chat titles instantly.
3. **Export to Markdown**:
   - 1-click **Export Chat** button in the header and sidebar downloads your complete chat as a `.md` file with timestamps and roles.
4. **Enhanced Chat Experience**:
   - **Assistant Messages**: Clean markdown typography, code syntax highlighting with language labels and individual code block copy buttons, timestamp display, retry button, and read-aloud voice playback.
   - **User Messages**: Soft rounded pill bubble with subtle timestamp.
   - **Auto-growing Input**: Auto-resizes, supports Enter to send, Shift+Enter for newline, one-click `Clear` button, and `Stop generating` button.
   - **Smart Auto-Scroll**: Non-intrusive scroll that pauses if you scroll up, with a floating *"New messages below"* badge.
5. **Full Mobile & Desktop Responsiveness**:
   - Dynamic viewport height `100dvh` prevents mobile keyboard jumps.
   - Persistent sidebar on desktop and smooth slide-out drawer on tablet/mobile with backdrop blur overlay and Escape key support.
   - Light and dark mode with persistent user choice saved in browser `localStorage`.

---

## 5. API Endpoints

- `GET /api/health`
  - Response: `{ "status": "ok" }`
- `POST /api/chat`
  - Body: `{ "messages": [{ "role": "user", "content": "Hello AeroGPT" }] }`
  - Response: `{ "reply": "Hello! How can I help you today?" }`
- `POST /api/chat/stream`
  - Body: `{ "messages": [{ "role": "user", "content": "Explain relativity" }] }`
  - Response: Server-Sent Events (`data: {"content": "..."}\n\n`), ending with `data: [DONE]\n\n`.
