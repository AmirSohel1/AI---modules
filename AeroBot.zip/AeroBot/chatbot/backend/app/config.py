from typing import Optional
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field


class Settings(BaseSettings):
    """Application settings loaded from .env file or environment variables."""
    api_key: str = Field(default="", description="OpenAI-compatible API key")
    base_url: Optional[str] = Field(default=None, description="OpenAI-compatible base URL")
    model: str = Field(default="anthropic.claude-sonnet-5", description="Model name to call")
    temperature: float = Field(default=0.7, description="Sampling temperature")
    frontend_origin: str = Field(default="http://localhost:4200", description="Allowed origin for CORS")
    default_system_prompt: str = Field(
        default="You are AeroGPT, a helpful, intelligent, and precise AI assistant.",
        description="Default system prompt used when none is provided in the message history"
    )

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )


settings = Settings()
