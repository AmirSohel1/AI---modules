from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.routes.chat import router as chat_router
from app.schemas.chat import HealthResponse

app = FastAPI(
    title="AeroGPT API",
    description="Stateless local backend for AeroGPT Chatbot",
    version="1.0.0"
)

# Configure CORS - allowed strictly for the local frontend origin
app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_origin],
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)


@app.get("/api/health", response_model=HealthResponse, tags=["health"])
async def health_check():
    """Health check endpoint to verify backend status."""
    return HealthResponse(status="ok")


# Register chat routes (/api/chat, /api/chat/stream)
app.include_router(chat_router)
