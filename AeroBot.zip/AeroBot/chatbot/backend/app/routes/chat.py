from fastapi import APIRouter, HTTPException, status
from fastapi.responses import StreamingResponse
from app.schemas.chat import ChatRequest, ChatResponse
from app.services.llm import generate_chat_completion, stream_chat_completion

router = APIRouter(prefix="/api", tags=["chat"])


@router.post("/chat", response_model=ChatResponse)
async def chat_endpoint(request: ChatRequest):
    """Stateless chat endpoint returning full reply."""
    try:
        messages = [m.model_dump() for m in request.messages]
        reply = generate_chat_completion(messages)
        return ChatResponse(reply=reply)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=str(e)
        )


@router.post("/chat/stream")
async def chat_stream_endpoint(request: ChatRequest):
    """Stateless chat endpoint returning SSE token-by-token stream ending in [DONE]."""
    try:
        messages = [m.model_dump() for m in request.messages]
        generator = stream_chat_completion(messages)
        return StreamingResponse(
            generator,
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no"
            }
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=str(e)
        )
