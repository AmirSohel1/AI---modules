from typing import List, Literal
from pydantic import BaseModel, Field


class Message(BaseModel):
    """Single chat message schema."""
    role: Literal["user", "assistant", "system"] = Field(
        ...,
        description="Role of the message sender: user, assistant, or system"
    )
    content: str = Field(
        ...,
        min_length=1,
        description="Text content of the message"
    )


class ChatRequest(BaseModel):
    """Incoming chat request payload."""
    messages: List[Message] = Field(
        ...,
        min_length=1,
        description="Full conversation history sent statelessly by the client"
    )


class ChatResponse(BaseModel):
    """Outgoing chat response payload."""
    reply: str = Field(..., description="Assistant text response")


class HealthResponse(BaseModel):
    """Health check status payload."""
    status: str = Field(default="ok", description="Server health status")


class ErrorResponse(BaseModel):
    """Standard error response payload."""
    error: str = Field(..., description="Human-readable error description")
