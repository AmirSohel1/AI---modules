import json
import logging
from typing import AsyncGenerator, List, Dict
from openai import OpenAI, OpenAIError
from app.config import settings

logger = logging.getLogger(__name__)


def get_openai_client() -> OpenAI:
    """Initialize OpenAI client using settings."""
    base_url = settings.base_url.strip() if settings.base_url and settings.base_url.strip() else None
    return OpenAI(
        api_key=settings.api_key.strip() if settings.api_key else "placeholder-key",
        base_url=base_url
    )


def prepare_messages(messages: List[Dict[str, str]]) -> List[Dict[str, str]]:
    """Format messages and prepend default system prompt if absent."""
    formatted = [{"role": m["role"], "content": m["content"]} for m in messages]
    has_system = any(m["role"] == "system" for m in formatted)
    if not has_system and settings.default_system_prompt:
        formatted.insert(0, {"role": "system", "content": settings.default_system_prompt})
    return formatted


def is_mock_mode() -> bool:
    """Return True if no valid API key is configured or explicitly set to mock/placeholder."""
    key = settings.api_key.strip() if settings.api_key else ""
    return not key or key == "placeholder-key" or key.lower() == "mock"


async def mock_streaming_response(user_query: str) -> AsyncGenerator[str, None]:
    """Realistic streaming token generator for local development when no API key is set."""
    import asyncio
    mock_reply = (
        f"Hello! I am **AeroGPT**. I received your message:\n\n"
        f"> *\"{user_query}\"*\n\n"
        "Your local full-stack **AeroGPT** application is running smoothly with real-time token streaming!\n\n"
        "To connect to your live LLM endpoint, set your `API_KEY` and optional `BASE_URL` in `backend/.env`."
    )
    words = mock_reply.split(" ")
    for i, word in enumerate(words):
        chunk_text = word if i == len(words) - 1 else word + " "
        payload = json.dumps({"content": chunk_text})
        yield f"data: {payload}\n\n"
        await asyncio.sleep(0.03)
    yield "data: [DONE]\n\n"


def generate_chat_completion(messages: List[Dict[str, str]]) -> str:
    """Execute synchronous chat completion."""
    prepared = prepare_messages(messages)

    if is_mock_mode():
        last_msg = messages[-1]["content"] if messages else ""
        return (
            f"Hello! I am AeroGPT. I received your message: \"{last_msg}\".\n\n"
            "Your local full-stack AeroGPT application is running smoothly!\n"
            "To connect to your live LLM endpoint, set your API_KEY and BASE_URL in backend/.env."
        )

    try:
        client = get_openai_client()
        response = client.chat.completions.create(
            model=settings.model,
            messages=prepared,  # full conversation history
            temperature=settings.temperature,
        )
        return response.choices[0].message.content or ""
    except OpenAIError as e:
        logger.error(f"OpenAI API Error: {str(e)}")
        # Safe error message - never leak the API key
        raise RuntimeError(f"LLM API error ({e.__class__.__name__}): {str(e)}")
    except Exception as e:
        logger.error(f"Unexpected error in LLM service: {str(e)}")
        raise RuntimeError("An unexpected error occurred while communicating with the LLM.")


async def stream_chat_completion(messages: List[Dict[str, str]]) -> AsyncGenerator[str, None]:
    """Execute streaming chat completion returning SSE tokens ending with [DONE]."""
    prepared = prepare_messages(messages)

    if is_mock_mode():
        last_msg = messages[-1]["content"] if messages else ""
        async for chunk in mock_streaming_response(last_msg):
            yield chunk
        return

    try:
        client = get_openai_client()
        response = client.chat.completions.create(
            model=settings.model,
            messages=prepared,  # full conversation history
            temperature=settings.temperature,
            stream=True,
        )
        for chunk in response:
            if chunk.choices and len(chunk.choices) > 0:
                delta = chunk.choices[0].delta
                if delta and delta.content:
                    payload = json.dumps({"content": delta.content})
                    yield f"data: {payload}\n\n"
        yield "data: [DONE]\n\n"
    except OpenAIError as e:
        logger.error(f"OpenAI Streaming Error: {str(e)}")
        error_payload = json.dumps({"error": f"LLM streaming error ({e.__class__.__name__}): {str(e)}"})
        yield f"data: {error_payload}\n\n"
        yield "data: [DONE]\n\n"
    except Exception as e:
        logger.error(f"Unexpected streaming error: {str(e)}")
        error_payload = json.dumps({"error": "An unexpected error occurred during streaming."})
        yield f"data: {error_payload}\n\n"
        yield "data: [DONE]\n\n"
