import {
  __async,
  __spreadProps,
  __spreadValues
} from "./chunk-TXDUYLVM.js";

// node_modules/marked/lib/marked.esm.js
function G() {
  return {
    async: false,
    breaks: false,
    extensions: null,
    gfm: true,
    hooks: null,
    pedantic: false,
    renderer: null,
    silent: false,
    tokenizer: null,
    walkTokens: null
  };
}
var S = G();
function ue(l3) {
  S = l3;
}
var q = {
  exec: () => null
};
function D(l3) {
  let e = [];
  return (t) => {
    let n = Math.max(0, Math.min(3, t - 1)), r = e[n];
    return r || (r = l3(n), e[n] = r), r;
  };
}
function g(l3, e = "") {
  let t = typeof l3 == "string" ? l3 : l3.source, n = {
    replace: (r, s) => {
      let o = typeof s == "string" ? s : s.source;
      return o = o.replace(O.caret, "$1"), t = t.replace(r, o), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
var _e = ((l3 = "") => {
  try {
    return !!new RegExp("(?<=1)(?<!1)" + l3);
  } catch {
    return false;
  }
})();
var O = {
  codeRemoveIndent: /^(?: {0,3}\t| {1,4})/gm,
  listInterruptsParagraph: /^ {0,3}(?:[*+-]|1[.)])[ \t]+[^ \t\n]/,
  outputLinkReplace: /\\([\[\]])/g,
  indentCodeCompensation: /^(\s+)(?:```)/,
  beginningSpace: /^\s+/,
  endingHash: /#$/,
  startingSpaceChar: /^ /,
  endingSpaceChar: / $/,
  endingSpaceTabChar: /[ \t]$/,
  nonSpaceChar: /[^ ]/,
  newLineCharGlobal: /\n/g,
  tabCharGlobal: /\t/g,
  leadingSpaceTab: /^[ \t]+/,
  multipleSpaceGlobal: /\s+/g,
  blankLine: /^[ \t]*$/,
  doubleBlankLine: /\n[ \t]*\n[ \t]*$/,
  blockquoteStart: /^ {0,3}>/,
  blockquoteSetextReplace: /\n {0,3}((?:=+|-+)[ \t]*)(?=\n|$)/g,
  blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm,
  blockquoteMarkerWhitespace: /^( {0,3}>)(\t[ \t]*)/gm,
  nestedBlockMarker: /^ {0,3}(?:(?:[*+-]|\d{1,9}[.)])(?: |$)|> ?)/,
  listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g,
  listIsTask: /^\[[ xX]\][ \t]+\S/,
  listReplaceTask: /^\[[ xX]\][ \t]+/,
  listTaskCheckbox: /\[[ xX]\]/,
  anyLine: /\n.*\n/,
  hrefBrackets: /^<(.*)>$/,
  tableDelimiter: /[:|]/,
  tableAlignChars: /^\||\| *$/g,
  tableRowBlankLine: /\n[ \t]*$/,
  tableAlignRight: /^ *-+: *$/,
  tableAlignCenter: /^ *:-+: *$/,
  tableAlignLeft: /^ *:-+ *$/,
  startATag: /^<a /i,
  endATag: /^<\/a>/i,
  startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i,
  endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i,
  startAngleBracket: /^</,
  endAngleBracket: />$/,
  pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/,
  unicodeAlphaNumeric: /[\p{L}\p{N}]/u,
  numericCharacterReference: /&#(?:(\d{1,7})|[Xx]([A-Fa-f0-9]{1,6}));/,
  numericCharacterReferenceOrAmpersand: /&#(?:(\d{1,7})|[Xx]([A-Fa-f0-9]{1,6}));|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,
  escapeTest: /[&<>"']/,
  escapeReplace: /[&<>"']/g,
  escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,
  escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,
  caret: /(^|[^\[])\^/g,
  percentDecode: /%25/g,
  findPipe: /\|/g,
  splitPipe: / \|/,
  slashPipe: /\\\|/g,
  carriageReturn: /\r\n|\r/g,
  spaceLine: /^ +$/gm,
  notSpaceStart: /^\S*/,
  endingNewline: /\n$/,
  listItemRegex: (l3) => new RegExp(`^( {0,3}${l3})((?:[	 ][^\\n]*)?(?:\\n|$))`),
  nextBulletRegex: D((l3) => new RegExp(`^ {0,${l3}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`)),
  hrRegex: D((l3) => new RegExp(`^ {0,${l3}}((?:-[ 	]*){3,}|(?:_[ 	]*){3,}|(?:\\*[ 	]*){3,})(?:\\n+|$)`)),
  fencesBeginRegex: D((l3) => new RegExp(`^ {0,${l3}}(?:\`\`\`|~~~)`)),
  headingBeginRegex: D((l3) => new RegExp(`^ {0,${l3}}#{1,6}(?:\\s|$)`)),
  pedanticHeadingBeginRegex: D((l3) => new RegExp(`^ {0,${l3}}#`)),
  htmlBeginRegex: D((l3) => new RegExp(`^ {0,${l3}}(?:</?(?:${he})(?:[ \\t]+|$|/?>)|<(?:(?:script|pre|style|textarea)(?:[\\s>]|$)|!--)|<\\?|<![A-Za-z]|<!\\[CDATA\\[)`, "i")),
  blockquoteBeginRegex: D((l3) => new RegExp(`^ {0,${l3}}>`)),
  nestedContainerMarkers: /^(?: {0,3}(?:(?:[*+-]|\d{1,9}[.)])[ \t]+|>[ \t]?))+/
};
var Ge = /^(?:[ \t]*(?:\n|$))+/;
var Ne = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/;
var Fe = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}(?:(?=`)\1`*|(?=~)\1~*) *(?=\n|$)|$)/;
var V = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/;
var Qe = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/;
var ce = / {0,3}(?:[*+-]|\d{1,9}[.)])/;
var he = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul";
var J = g(" {0,3}(?:</?(?:tag)(?:[ \\t]+|\\n|/?>)|<(?:(?:script|pre|style|textarea)(?:[\\s>]|$)|!--)|<\\?|<![A-Za-z]|<!\\[CDATA\\[)").replace("tag", he).getRegex();
var $e = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |fences|blockquote|heading|hr|html|table))+?)\n {0,3}(=+|-+)[ \t]*(?:\n+|$)/;
var Le = g($e).replace(/bull/g, ce).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}(?:\s|$)/).replace(/hr/g, / {0,3}(?:(?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/).replace(/\|table/g, "").replace(/html/g, J).getRegex();
var We = g($e).replace(/bull/g, ce).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}(?:\s|$)/).replace(/hr/g, / {0,3}(?:(?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).replace(/html/g, J).getRegex();
var de = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table|[ \t]+\n)[^\n]+)*)/;
var Ue = /^[^\n]+/;
var ge = /(?!\s*\])(?:\\[\s\S]|[^\[\]\\\n]|\n(?![ \t]*\n))+/;
var Ke = g(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<(?:\\.|[^\n<>\\])*>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", ge).replace("title", /(?:"(?:\\[\s\S]|[^"\\])*"|'(?:\\[\s\S]|[^'\\\n]|\n(?!\n))*'|\((?:\\[\s\S]|[^()\\])*\))/).getRegex();
var Xe = g(/^(bull)([ \t][^\n]*?)?(?:\n|$)/).replace(/bull/g, ce).getRegex();
var ke = /<!--(?:-?>|[\s\S]*?(?:-->|$))/;
var Ve = g("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n*|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>[^\\n]*\\n*|$)|<![A-Z][\\s\\S]*?(?:>[^\\n]*\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>[^\\n]*\\n*|$)|</?(tag)(?:[ \\t]+|\\n|/?>|$)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!(?:script|pre|style|textarea)(?![a-z0-9-]))([a-z][a-z0-9-]*)(?:attribute)*?[ \\t]*/?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</[a-z][a-z0-9-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))", "i").replace("comment", ke).replace("tag", he).replace("attribute", /[ \t]+[a-zA-Z:_][\w.:-]*(?:[ \t]*=[ \t]*"[^"\n]*"|[ \t]*=[ \t]*'[^'\n]*'|[ \t]*=[ \t]*[^\s"'=<>`]+)?/).getRegex();
var Ce = (l3) => g(de).replace("hr", V).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*(?:\\n|$))|~~~)[^\\n]*(?:\\n|$)").replace("list", l3).replace("html", J).getRegex();
var Je = Ce(/ {0,3}(?:[*+-]|1[.)])[ \t]+[^ \t\n]/);
var Ye = Ce(/ {0,3}(?:[*+-]|\d{1,9}[.)])(?:[ \t]|\n|$)/);
var et = g(/^( {0,3}> ?(?:(?![ \t]*(?:\n|$))(paragraph)|[^\n]*)(?:\n|$))+/).replace("paragraph", Ye).getRegex();
var fe = {
  blockquote: et,
  code: Ne,
  def: Ke,
  fences: Fe,
  heading: Qe,
  hr: V,
  html: Ve,
  lheading: Le,
  list: Xe,
  newline: Ge,
  paragraph: Je,
  table: q,
  text: Ue
};
var Pe = g("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", V).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*(?:\\n|$))|~~~)[^\\n]*(?:\\n|$)").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]").replace("html", J).getRegex();
var tt = __spreadProps(__spreadValues({}, fe), {
  lheading: We,
  table: Pe,
  paragraph: g(de).replace("hr", V).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Pe).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*(?:\\n|$))|~~~)[^\\n]*(?:\\n|$)").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]+[^ \\t\\n]").replace("html", J).getRegex()
});
var nt = __spreadProps(__spreadValues({}, fe), {
  html: g(`^ *(?:comment(?: *\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1>(?: *\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?>(?: *\\n{2,}|\\s*$))`).replace("comment", ke).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: q,
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: g(de).replace("hr", V).replace("heading", ` *#{1,6} *[^
]`).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").replace("lheading", Le).getRegex()
});
var rt = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/;
var st = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/;
var Ie = /^( {2,}|\\)\n(?!\s*$)[ \t]*/;
var it = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/;
var L = /[\p{P}\p{S}]/u;
var N = /[\s\p{P}\p{S}]/u;
var Y = /[^\s\p{P}\p{S}]/u;
var ot = g(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, N).getRegex();
var at = /[\p{Pi}\p{Ps}"']/u;
var Ae = /(?!~)[\p{P}\p{S}]/u;
var lt = /(?!~)[\s\p{P}\p{S}]/u;
var ut = /(?:[^\s\p{P}\p{S}]|~)/u;
var pt = g(/link|precode-code|html/, "g").replace("link", /\[(?:[^\[\]`]|(?<a>`+)[^`]+\k<a>(?!`))*?\]\((?:\\[\s\S]|[^\\\(\)]|\((?:\\[\s\S]|[^\\\(\)])*\))*\)/).replace("precode-", _e ? "(?<!`)()" : "(^^|[^`])").replace("code", /(?<b>`+)[^`]+\k<b>(?!`)/).replace("html", /<(?! )[^<>]*?>/).getRegex();
var Ee = /^(?:\*+(?:((?!\*)punct)|([^\s*]))?)|^_+(?:((?!_)punct)|([^\s_]))?/;
var ct = g(Ee, "u").replace(/punct/g, L).getRegex();
var ht = g(Ee, "u").replace(/punct/g, Ae).getRegex();
var dt = /^(?:\*+(?:((?!\*)(?!openQuote)punct)|([^\s*]))?)|^_+(?:((?!_)(?!openQuote)punct)|([^\s_]))?/;
var gt = g(dt, "u").replace(/openQuote/g, at).replace(/punct/g, L).getRegex();
var ze = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)";
var kt = g(ze, "gu").replace(/notPunctSpace/g, Y).replace(/punctSpace/g, N).replace(/punct/g, L).getRegex();
var ft = g(ze, "gu").replace(/notPunctSpace/g, ut).replace(/punctSpace/g, lt).replace(/punct/g, Ae).getRegex();
var mt = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)[\\s](\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|(?:(?!\\*)punct|notPunctSpace)(\\*+)(?!\\*)(?=notPunctSpace)";
var xt = g(mt, "gu").replace(/notPunctSpace/g, Y).replace(/punctSpace/g, N).replace(/punct/g, L).getRegex();
var bt = g("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)", "gu").replace(/notPunctSpace/g, Y).replace(/punctSpace/g, N).replace(/punct/g, L).getRegex();
var Rt = "^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)[\\s](_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)|(?:(?!_)punct|notPunctSpace)(_+)(?!_)(?=notPunctSpace)";
var Tt = g(Rt, "gu").replace(/notPunctSpace/g, Y).replace(/punctSpace/g, N).replace(/punct/g, L).getRegex();
var Ot = g(/^~~?(?:((?!~)punct)|[^\s~])/, "u").replace(/punct/g, L).getRegex();
var wt = "^[^~]+(?=[^~])|(?!~)punct(~~?)(?=[\\s]|$)|notPunctSpace(~~?)(?!~)(?=punctSpace|$)|(?!~)punctSpace(~~?)(?=notPunctSpace)|[\\s](~~?)(?!~)(?=punct)|(?!~)punct(~~?)(?!~)(?=punct)|notPunctSpace(~~?)(?=notPunctSpace)";
var Pt = g(wt, "gu").replace(/notPunctSpace/g, Y).replace(/punctSpace/g, N).replace(/punct/g, L).getRegex();
var yt = g(/\\(punct)/, "gu").replace(/punct/g, L).getRegex();
var St = g(/(`+)(?:[^`]|[^`][\s\S]*?[^`])\1(?!`)|`+|\\(punct)/, "gu").replace(/punct/g, L).getRegex();
var _t = g(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex();
var $t = g(ke).replace("(?:-->|$)", "-->").getRegex();
var Lt = g("^comment|^</[a-zA-Z][a-zA-Z0-9-]*\\s*>|^<[a-zA-Z][a-zA-Z0-9-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", $t).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex();
var Me = /\[(?:\\[\s\S]|[^\[\]\\])*\]/;
var ie = g(/(?:\[(?:brackets|\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+(?!`)[^`]*?`+(?!`)|``+(?=\])|[^\[\]\\`])*?/).replace("brackets", Me).getRegex();
var Ct = g(/^!?\[(label)\]\([ \t\n]*(href)(?:(?:[ \t]+(?:\n[ \t]*)?|\n[ \t]*)(title))?[ \t\n]*\)/).replace("label", ie).replace("href", /<(?:\\.|[^\n<>\\])*>|(?!<)[^ \t\n\x00-\x1f]+|(?=\))/).replace("title", /"(?:\\[\s\S]|[^"\\])*"|'(?:\\[\s\S]|[^'\\])*'|\((?:\\[\s\S]|[^)\\])*\)/).getRegex();
var It = g(/^!?\[(label)\]\[(ref)\]/).replace("label", ie).replace("ref", ge).getRegex();
var At = g(/^!?\[(ref)\](?:\[\])?/).replace("ref", ge).getRegex();
var ye = /(?!\s*\])(?:\\[\s\S]|[^\[\]\\]){1,999}/;
var Et = g(/(?:[^\[\]\\`]*(?:\[(?:brackets|\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+(?!`)[^`]*?`+(?!`)|``+(?=\]))){0,999}?[^\[\]\\`]*?/).replace("brackets", Me).getRegex();
var zt = g("reflink|nolink(?!\\()", "g").replace("reflink", g(/^!?\[(label)\]\[(ref)\]/).replace("label", Et).replace("ref", ye).getRegex()).replace("nolink", g(/^!?\[(ref)\](?:\[\])?/).replace("ref", ye).getRegex()).getRegex();
var Se = /[hH][tT][tT][pP][sS]?|[fF][tT][pP]/;
var Mt = /[A-Za-z0-9._+-]+@[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![\w-])/;
var Bt = g(/(?:mailto:email|xmpp:email(?:\/[A-Za-z0-9@.]+)?)/).replace(/email/g, Mt).getRegex();
var me = {
  _backpedal: q,
  anyPunctuation: yt,
  anyPunctuationOutsideCode: St,
  autolink: _t,
  blockSkip: pt,
  br: Ie,
  code: st,
  del: q,
  delLDelim: q,
  delRDelim: q,
  emStrongLDelim: ct,
  emStrongRDelimAst: kt,
  emStrongRDelimUnd: bt,
  escape: rt,
  link: Ct,
  nolink: At,
  punctuation: ot,
  reflink: It,
  reflinkSearch: zt,
  tag: Lt,
  text: it,
  url: q
};
var Dt = __spreadProps(__spreadValues({}, me), {
  emStrongLDelim: gt,
  emStrongRDelimAst: xt,
  emStrongRDelimUnd: Tt,
  link: g(/^!?\[(label)\]\((.*?)\)/).replace("label", ie).getRegex(),
  reflink: g(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", ie).getRegex()
});
var pe = __spreadProps(__spreadValues({}, me), {
  emStrongRDelimAst: ft,
  emStrongLDelim: ht,
  delLDelim: Ot,
  delRDelim: Pt,
  url: g(/^emailProtocol|^((?:protocol):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/).replace("emailProtocol", Bt).replace("protocol", Se).replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![\w-])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])((?:\\[\s\S]|[^\\])*?(?:\\[\s\S]|[^\s~\\]))\1(?=[^~]|$)/,
  text: g(/^(?:[^a-zA-Z0-9](?=emailProtocol)|(`+|~+|[^`~])(?:(?=[`~])|(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|protocol:\/\/|wwwStart|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9](?=emailProtocol)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@))))/).replace("protocol", Se).replace(/emailProtocol/g, /(?:mailto|xmpp):/).replace("wwwStart", _e ? "(?<![^\\s*_~(])www\\." : "www\\.").getRegex()
});
var qt = __spreadProps(__spreadValues({}, pe), {
  br: g(Ie).replace("{2,}", "*").getRegex(),
  text: g(pe.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
});
var ee = {
  normal: fe,
  gfm: tt,
  pedantic: nt
};
var F = {
  normal: me,
  gfm: pe,
  breaks: qt,
  pedantic: Dt
};
var vt = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
};
var Be = (l3) => vt[l3];
function y(l3, e) {
  if (e) {
    if (O.escapeTest.test(l3)) return l3.replace(O.escapeReplace, Be);
  } else if (O.escapeTestNoEncode.test(l3)) return l3.replace(O.escapeReplaceNoEncode, Be);
  return l3;
}
function De(l3) {
  return O.numericCharacterReference.test(l3) ? l3.replace(O.numericCharacterReferenceOrAmpersand, (e, t, n) => {
    if (t === void 0 && n === void 0) return "&amp;";
    let r = t === void 0 ? Number.parseInt(n, 16) : Number.parseInt(t, 10);
    return r === 0 || r > 1114111 || r >= 55296 && r <= 57343 ? "�" : r === 38 ? "&amp;" : String.fromCodePoint(r);
  }) : l3;
}
function xe(l3) {
  try {
    l3 = encodeURI(l3).replace(O.percentDecode, "%");
  } catch {
    return null;
  }
  return l3;
}
function be(l3, e) {
  let t = l3.replace(O.findPipe, (s, o, i) => {
    let a = false, c = o;
    for (; --c >= 0 && i[c] === "\\"; ) a = !a;
    return a ? "|" : " |";
  }), n = t.split(O.splitPipe), r = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n.at(-1)?.trim() && n.pop(), e) if (n.length > e) n.splice(e);
  else for (; n.length < e; ) n.push("");
  for (; r < n.length; r++) n[r] = n[r].trim().replace(O.slashPipe, "|");
  return n;
}
function C(l3, e, t) {
  let n = l3.length;
  if (n === 0) return "";
  let r = 0;
  for (; r < n; ) {
    let s = l3.charAt(n - r - 1);
    if (s === e && !t) r++;
    else if (s !== e && t) r++;
    else break;
  }
  return l3.slice(0, n - r);
}
function Re(l3) {
  let e = l3.split(`
`), t = e.length - 1;
  for (; t >= 0 && O.blankLine.test(e[t]); ) t--;
  return e.length - t <= 2 ? l3 : e.slice(0, t + 1).join(`
`);
}
function W(l3) {
  return l3.trim().replace(O.multipleSpaceGlobal, " ").toLowerCase().toUpperCase().toLowerCase();
}
function Te(l3, e) {
  if (l3.indexOf(e[0]) === -1 && l3.indexOf(e[1]) === -1) return -1;
  let t = 0;
  for (let n = 0; n < l3.length; n++) if (l3[n] === "\\") n++;
  else if (l3[n] === e[0]) t++;
  else if (l3[n] === e[1] && (t--, t < 0)) return n;
  return t > 0 ? -2 : -1;
}
var Q = /* @__PURE__ */ new WeakMap();
function Oe(l3) {
  let e = {
    "*": -1,
    _: -1
  }, t = -1, n = l3.length;
  for (let r = 0; r < n; r++) {
    let s = l3[r];
    if (s !== "*" && s !== "_" && s !== "~") continue;
    let o = r === 0 ? `
` : l3[r - 1], i = r + 1;
    for (; i < n && l3[i] === s; ) i++;
    o !== " " && o !== "	" && o !== `
` && o !== "\r" && o !== "\f" && (s === "~" ? t = r : e[s] = r), r = i - 1;
  }
  return {
    maskedSrc: l3,
    lastPossibleEmStrongCloserIndex: e,
    lastPossibleDelCloserIndex: t
  };
}
function qe(l3, e) {
  let t = Oe(e), n = Q.get(l3);
  n ? n.push(t) : Q.set(l3, [t]);
}
function ve(l3) {
  let e = Q.get(l3);
  e && (e.pop(), e.length === 0 && Q.delete(l3));
}
function oe(l3, e, t) {
  let n = Q.get(l3)?.at(-1);
  return n && n.maskedSrc === e ? n.lastPossibleEmStrongCloserIndex[t] : Oe(e).lastPossibleEmStrongCloserIndex[t];
}
function ae(l3, e) {
  let t = Q.get(l3)?.at(-1);
  return t && t.maskedSrc === e ? t.lastPossibleDelCloserIndex : Oe(e).lastPossibleDelCloserIndex;
}
function te(l3, e = 0) {
  let t = e, n = "";
  for (let r of l3) if (r === "	") {
    let s = 4 - t % 4;
    n += " ".repeat(s), t += s;
  } else n += r, t++;
  return n;
}
function Ht(l3, e) {
  let t = "";
  for (let n = 0; n < l3.length; n++) {
    if (l3[n] === "`") {
      let r = e.inline.code.exec(l3.slice(n));
      if (r) {
        t += r[0], n += r[0].length - 1;
        continue;
      }
    }
    if (l3[n] === "\\" && (l3[n + 1] === "[" || l3[n + 1] === "]")) {
      t += l3[n + 1], n++;
      continue;
    }
    t += l3[n];
  }
  return t;
}
function He(l3, e, t, n, r) {
  let s = e.href, o = e.title || null, i = Ht(l3[1], r), a = l3[0].charAt(0) === "!", c = n.state.inLink, u = n.state.linkEmitted, d = n.state.inRawBlock;
  n.state.inLink = true, n.state.linkEmitted = false;
  let h = n.inlineTokens(i), p = n.state.linkEmitted;
  if (n.state.linkEmitted = u, n.state.inLink = c, !a) {
    if (p) {
      n.state.inRawBlock = d;
      return;
    }
    n.state.linkEmitted = true;
  }
  return {
    type: a ? "image" : "link",
    raw: t,
    href: s,
    title: o,
    text: i,
    tokens: h
  };
}
function Zt(l3, e, t) {
  let n = l3.match(t.other.indentCodeCompensation);
  if (n === null) return e;
  let r = n[1];
  return e.split(`
`).map((s) => {
    let o = s.match(t.other.beginningSpace);
    if (o === null) return s;
    let [i] = o;
    return s.slice(Math.min(i.length, r.length));
  }).join(`
`);
}
function Ze(l3, e, t, n) {
  if (!e.includes("<")) return false;
  for (let r = 0; r < e.length; r++) {
    if (e[r] === "\\") {
      r++;
      continue;
    }
    if (e[r] === "`") {
      let i = n.inline.code.exec(e.slice(r));
      if (i) {
        r += i[0].length - 1;
        continue;
      }
    }
    if (e[r] !== "<") continue;
    let s = l3.slice(t + r), o = n.inline.tag.exec(s) || n.inline.autolink.exec(s);
    if (o) {
      if (o[0].length > e.length - r) return true;
      r += o[0].length - 1;
    }
  }
  return false;
}
var _ = class {
  options;
  rules;
  lexer;
  constructor(e) {
    this.options = e || S;
  }
  space(e) {
    let t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0) return {
      type: "space",
      raw: t[0]
    };
  }
  code(e) {
    let t = this.rules.block.code.exec(e);
    if (t) {
      let n = this.options.pedantic ? t[0] : Re(t[0]), r = n.replace(this.rules.other.codeRemoveIndent, "");
      return {
        type: "code",
        raw: n,
        codeBlockStyle: "indented",
        text: r
      };
    }
  }
  fences(e) {
    let t = this.rules.block.fences.exec(e);
    if (t) {
      let n = t[0], r = Zt(n, t[3] || "", this.rules);
      return t[3] !== void 0 && (r === "" || r.endsWith(`
`)) && (r += `
`), {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: r
      };
    }
  }
  heading(e) {
    let t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (this.rules.other.endingHash.test(n)) {
        let r = C(n, "#");
        (this.options.pedantic || !r || this.rules.other.endingSpaceTabChar.test(r)) && (n = r.trim());
      }
      return {
        type: "heading",
        raw: C(t[0], `
`),
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    let t = this.rules.block.hr.exec(e);
    if (t) return {
      type: "hr",
      raw: C(t[0], `
`)
    };
  }
  blockquote(e) {
    let t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = C(t[0], `
`).split(`
`), r = "", s = "", o = [];
      for (; n.length > 0; ) {
        let i = false, a = [], c;
        for (c = 0; c < n.length; c++) if (this.rules.other.blockquoteStart.test(n[c])) a.push(n[c]), i = true;
        else if (!i) a.push(n[c]);
        else break;
        n = n.slice(c);
        let u = a.join(`
`), d = u.replace(this.rules.other.blockquoteMarkerWhitespace, (k, m, b) => b.startsWith(" ") ? m + " " + b.slice(1) : m + te(b, m.length)).replace(this.rules.other.blockquoteSetextReplace, `
    $1`).replace(this.rules.other.blockquoteSetextReplace2, "");
        r = r ? `${r}
${u}` : u, s = s ? `${s}
${d}` : d;
        let h = this.lexer.state.top;
        if (this.lexer.state.top = true, this.lexer.blockTokens(d, o, true), this.lexer.state.top = h, n.length === 0) break;
        let p = o.at(-1);
        if (p?.type === "code" || p?.type === "heading" || p?.type === "hr" || p?.type === "html" || p?.type === "table") break;
        if (p?.type === "blockquote") {
          let k = p, m = n.join(`
`), b = k.raw + `
` + m.replace(this.rules.other.blockquoteSetextReplace2, ""), f = this.blockquote(b);
          o[o.length - 1] = f;
          let R = b.substring(f.raw.length).replace(/^\n/, ""), E = R ? R.split(`
`).length : 0, T = E ? n.slice(0, -E) : n;
          if (T.length > 0 && (r = `${r}
${T.join(`
`)}`), s = s.substring(0, s.length - k.text.length) + f.text, n = n.slice(T.length), n.length > 0 && this.rules.other.blockquoteStart.test(n[0])) continue;
          break;
        } else if (p?.type === "list") {
          let k = p, m = k.raw + `
` + n.join(`
`), b = this.list(m);
          o[o.length - 1] = b;
          let f = b.raw.length > k.raw.length ? m.slice(k.raw.length + 1, b.raw.length).split(`
`).length : 0;
          if (f > 0) {
            let R = n.slice(0, f).join(`
`);
            r = `${r}
${R}`, s = `${s}
${R}`;
          }
          if (n = n.slice(f), n.length > 0 && !this.rules.other.blockquoteStart.test(n[0])) break;
          continue;
        }
      }
      return {
        type: "blockquote",
        raw: r,
        tokens: o,
        text: s
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      if (!this.options.pedantic && this.lexer.state.lastToken?.type === "text" && !this.rules.other.listInterruptsParagraph.test(e)) return;
      let n = e, r = () => n.length - e.length, s = t[1].trim(), o = s.length > 1, i = {
        type: "list",
        raw: "",
        ordered: o,
        start: o ? +s.slice(0, -1) : "",
        loose: false,
        items: []
      };
      s = o ? `\\d{1,9}\\${s.slice(-1)}` : `\\${s}`, this.options.pedantic && (s = o ? s : "[*+-]");
      let a = this.rules.other.listItemRegex(s), c = false;
      for (; e; ) {
        let h = false, p = "";
        if (!(t = a.exec(e)) || this.rules.block.hr.test(e)) break;
        let k = r();
        e = e.substring(t[0].length);
        let m = t[2].split(`
`, 1)[0], b = t[1].length, f = this.options.pedantic ? te(m, b) : m.replace(this.rules.other.leadingSpaceTab, (H) => te(H, b)), R = e.split(`
`, 1)[0], E = !f.trim(), T = 0;
        if (this.options.pedantic ? (T = 2, p = f.trimStart()) : E ? T = b + 1 : (T = f.search(this.rules.other.nonSpaceChar), T = T > 4 ? 1 : T, p = f.slice(T), T += b), E && this.rules.other.blankLine.test(R) && (e = e.substring(R.length + 1), h = true), !h) {
          let H = this.rules.other.nextBulletRegex(T), K = this.rules.other.hrRegex(T), re = this.rules.other.fencesBeginRegex(T), B = this.options.pedantic ? this.rules.other.pedanticHeadingBeginRegex(T) : this.rules.other.headingBeginRegex(T), X = this.rules.other.htmlBeginRegex(T), se = this.rules.other.blockquoteBeginRegex(T), le = false;
          for (; e; ) {
            let we = e.split(`
`, 1)[0], Z;
            if (R = we, this.options.pedantic ? (R = R.replace(this.rules.other.listReplaceNesting, "  "), Z = R) : Z = R.replace(this.rules.other.leadingSpaceTab, ($) => te($)), re.test(R) || B.test(R) || X.test(R) || se.test(R) || H.test(R) || K.test(R)) break;
            if (Z.search(this.rules.other.nonSpaceChar) >= T || !R.trim()) p += `
` + Z.slice(T), le = false;
            else {
              if (E) break;
              let $ = f;
              if (!this.options.pedantic && !p.includes(`
`) && !f.includes("	")) {
                let j;
                for (; !K.test($) && (j = this.rules.other.nestedBlockMarker.exec($)); ) $ = $.slice(j[0].length);
                if (!$.trim()) break;
              }
              if ($.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4 || re.test($) || B.test($) || X.test($) || K.test($)) break;
              if (!this.options.pedantic && !le) {
                let j = f.replace(this.rules.other.nestedContainerMarkers, "");
                if (this.rules.block.fences.test(j) || this.rules.block.heading.test(j) || this.rules.block.hr.test(j)) break;
              }
              let je = !this.options.pedantic && /^ {0,3}(?:=+|-+) *$/.test(R) && this.rules.block.lheading.test(`${f}
${R}`) ? `    ${Z.replace(/^ {0,3}/, "")}` : R;
              p += `
` + je, le = true;
            }
            E = !R.trim(), e = e.substring(we.length + 1), f = Z.slice(T);
          }
        }
        let U = n.slice(k, r());
        i.loose || (c ? i.loose = true : this.rules.other.doubleBlankLine.test(U) && (c = true)), i.items.push({
          type: "list_item",
          raw: U,
          task: !!this.options.gfm && this.rules.other.listIsTask.test(p),
          loose: false,
          text: p,
          tokens: []
        });
      }
      let u = i.items.at(-1);
      if (u) u.raw = u.raw.trimEnd(), u.text = u.text.trimEnd();
      else return;
      i.raw = n.slice(0, r()).trimEnd();
      let d = [];
      for (let h of i.items) if (this.lexer.state.top = false, d.push(this.lexer.inlineQueue.length), h.tokens = this.lexer.blockTokens(h.text, []), !i.loose) {
        let p = h.tokens.filter((m) => m.type === "space"), k = p.length > 0 && p.some((m) => this.rules.other.anyLine.test(m.raw));
        i.loose = k;
      }
      for (let h = 0; h < i.items.length; h++) {
        let p = i.items[h], k = p.tokens[0];
        if (p.task && (k?.type === "text" || k?.type === "paragraph")) {
          p.text = p.text.replace(this.rules.other.listReplaceTask, ""), k.raw = k.raw.replace(this.rules.other.listReplaceTask, ""), k.text = k.text.replace(this.rules.other.listReplaceTask, "");
          let m = this.lexer.inlineQueue;
          for (let f = d[h]; f < m.length; f++) if (m[f].tokens === k.tokens) {
            m[f].src = m[f].src.replace(this.rules.other.listReplaceTask, "");
            break;
          }
          let b = this.rules.other.listTaskCheckbox.exec(p.raw);
          if (b) {
            let f = {
              type: "checkbox",
              raw: b[0] + " ",
              checked: b[0] !== "[ ]"
            };
            p.checked = f.checked, i.loose ? p.tokens[0] && ["paragraph", "text"].includes(p.tokens[0].type) && "tokens" in p.tokens[0] && p.tokens[0].tokens ? (p.tokens[0].raw = f.raw + p.tokens[0].raw, p.tokens[0].text = f.raw + p.tokens[0].text, p.tokens[0].tokens.unshift(f)) : p.tokens.unshift({
              type: "paragraph",
              raw: f.raw,
              text: f.raw,
              tokens: [f]
            }) : p.tokens.unshift(f);
          }
        } else p.task && (p.task = false);
      }
      if (i.loose) for (let h of i.items) {
        h.loose = true;
        for (let p of h.tokens) p.type === "text" && (p.type = "paragraph");
      }
      return i;
    }
  }
  html(e) {
    let t = this.rules.block.html.exec(e);
    if (t) {
      if (this.lexer.state.lastToken?.type === "paragraph" && !this.rules.other.htmlBeginRegex(4).test(e)) return;
      let n = Re(t[0]);
      return {
        type: "html",
        block: true,
        raw: n,
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: n
      };
    }
  }
  def(e) {
    let t = this.rules.block.def.exec(e);
    if (t) {
      if (!this.rules.other.startAngleBracket.test(t[2]) && Te(t[2], "()") !== -1) return;
      let n = W(t[1]), r = t[2] ? t[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", s = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: C(t[0], `
`),
        href: r,
        title: s
      };
    }
  }
  table(e) {
    let t = this.rules.block.table.exec(e);
    if (!t || !this.rules.other.tableDelimiter.test(t[2])) return;
    let n = be(t[1]), r = t[2].replace(this.rules.other.tableAlignChars, "").split("|"), s = t[3]?.trim() ? t[3].replace(this.rules.other.tableRowBlankLine, "").split(`
`) : [], o = {
      type: "table",
      raw: C(t[0], `
`),
      header: [],
      align: [],
      rows: []
    };
    if (n.length === r.length) {
      for (let i of r) this.rules.other.tableAlignRight.test(i) ? o.align.push("right") : this.rules.other.tableAlignCenter.test(i) ? o.align.push("center") : this.rules.other.tableAlignLeft.test(i) ? o.align.push("left") : o.align.push(null);
      for (let i = 0; i < n.length; i++) o.header.push({
        text: n[i],
        tokens: this.lexer.inline(n[i]),
        header: true,
        align: o.align[i]
      });
      for (let i of s) o.rows.push(be(i, o.header.length).map((a, c) => ({
        text: a,
        tokens: this.lexer.inline(a),
        header: false,
        align: o.align[c]
      })));
      return o;
    }
  }
  lheading(e) {
    let t = this.rules.block.lheading.exec(e);
    if (t) {
      let n = t[1].trim();
      return {
        type: "heading",
        raw: C(t[0], `
`),
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  paragraph(e) {
    let t = this.rules.block.paragraph.exec(e);
    if (t) {
      let n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    let t = this.rules.block.text.exec(e);
    if (t) return {
      type: "text",
      raw: t[0],
      text: t[0],
      tokens: this.lexer.inline(t[0])
    };
  }
  escape(e) {
    if (e.charCodeAt(0) !== 92) return;
    let t = this.rules.inline.escape.exec(e);
    if (t) return {
      type: "escape",
      raw: t[0],
      text: t[1]
    };
  }
  tag(e) {
    if (e.charCodeAt(0) !== 60) return;
    let t = this.rules.inline.tag.exec(e);
    if (t) return !this.lexer.state.inLink && this.rules.other.startATag.test(t[0]) ? this.lexer.state.inLink = true : this.lexer.state.inLink && this.rules.other.endATag.test(t[0]) && (this.lexer.state.inLink = false), !this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(t[0]) ? this.lexer.state.inRawBlock = true : this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(t[0]) && (this.lexer.state.inRawBlock = false), {
      type: "html",
      raw: t[0],
      inLink: this.lexer.state.inLink,
      inRawBlock: this.lexer.state.inRawBlock,
      block: false,
      text: t[0]
    };
  }
  link(e) {
    if (this.lexer.state.linkParenPossible === false) return;
    let t = e.charCodeAt(0);
    if (t !== 91 && t !== 33) return;
    let n = this.rules.inline.link.exec(e);
    if (n) {
      let r = n[0].charAt(0) === "!" ? 2 : 1;
      if (!this.options.pedantic && Ze(e, n[1], r, this.rules)) return;
      let s = n[2].trim();
      if (!this.options.pedantic && this.rules.other.startAngleBracket.test(s)) {
        if (!this.rules.other.endAngleBracket.test(s)) return;
        let c = C(s.slice(0, -1), "\\");
        if ((s.length - c.length) % 2 === 0) return;
      } else {
        let c = Te(n[2], "()");
        if (c === -2) return;
        if (c > -1) {
          let d = (n[0].indexOf("!") === 0 ? 5 : 4) + n[1].length + c;
          n[2] = n[2].substring(0, c), n[0] = n[0].substring(0, d).trim(), n[3] = "";
        }
      }
      let o = C(n[0].slice(0, -1), "\\");
      if ((n[0].length - o.length) % 2 === 0) return;
      let i = n[2], a = "";
      if (this.options.pedantic) {
        let c = this.rules.other.pedanticHrefTitle.exec(i);
        c && (i = c[1], a = c[3]);
      } else a = n[3] ? n[3].slice(1, -1) : "";
      return i = i.trim(), this.rules.other.startAngleBracket.test(i) && (this.options.pedantic && !this.rules.other.endAngleBracket.test(s) ? i = i.slice(1) : i = i.slice(1, -1)), He(n, {
        href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
        title: a && a.replace(this.rules.inline.anyPunctuation, "$1")
      }, n[0], this.lexer, this.rules);
    }
  }
  reflink(e, t) {
    let n = e.charCodeAt(0);
    if (n !== 91 && n !== 33) return;
    let r;
    if ((r = this.rules.inline.reflink.exec(e)) || (r = this.rules.inline.nolink.exec(e))) {
      let s = r[0].charAt(0) === "!" ? 2 : 1;
      if (!this.options.pedantic && Ze(e, r[1], s, this.rules)) return;
      let o = t[W(r[2] || r[1])];
      if (!o) {
        let i = r[0].charAt(0);
        return {
          type: "text",
          raw: i,
          text: i
        };
      }
      return He(r, o, r[0], this.lexer, this.rules);
    }
  }
  emStrong(e, t, n = "") {
    let r = this.rules.inline.emStrongLDelim.exec(e);
    if (!r || !r[1] && !r[2] && !r[3] && !r[4]) return;
    let s = r[0][0], o = n === s, i = t.length - e.length, a = i;
    for (; !this.options.pedantic && a > 0 && t[a - 1] === s; ) a--;
    let c = [...t.slice(Math.max(0, a - 2), a)].at(-1) ?? "", u = c === "*" || c === "_" || !!this.rules.inline.punctuation.exec(c);
    a < i && (n = c);
    let d = a < i ? u : n === "*" || n === "_" || !!this.rules.inline.punctuation.exec(n);
    if (r[4] && n.match(this.rules.other.unicodeAlphaNumeric)) return;
    let h = r[1] || r[3] || "";
    if (!h || !n || d) {
      let p = [...r[0]].length - 1, k, m, b = p, f = 0, R = i - a + p, E = !this.options.pedantic && !!c.trim() && (!!h || s === "*" && !u);
      if (s !== "*" && s !== "_") return;
      let T = s === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd, U = oe(this, t, s), H = t.length - e.length + p;
      if (U < H) return;
      t = t.slice(-1 * e.length + p);
      let K = U - H;
      for (T.lastIndex = 0; (r = T.exec(t)) !== null && !(r.index > K); ) {
        if (k = r[1] || r[2] || r[3] || r[4] || r[5] || r[6], !k) continue;
        if (m = [...k].length, r[3] || r[4]) {
          b += m;
          continue;
        } else if ((r[5] || r[6] || E) && R % 3 && !((R + m) % 3)) {
          if (o && (r[5] || r[6])) break;
          f += m;
          continue;
        }
        if (b -= m, b > 0) continue;
        m = Math.min(m, m + b + f);
        let re = [...r[0]][0].length, B = e.slice(0, p + r.index + re + m);
        if (Math.min(p, m) % 2) {
          let se = B.slice(1, -1);
          return {
            type: "em",
            raw: B,
            text: se,
            tokens: this.lexer.inlineTokens(se)
          };
        }
        let X = B.slice(2, -2);
        return {
          type: "strong",
          raw: B,
          text: X,
          tokens: this.lexer.inlineTokens(X)
        };
      }
    }
  }
  codespan(e) {
    if (e.charCodeAt(0) !== 96) return;
    let t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(this.rules.other.newLineCharGlobal, " "), r = this.rules.other.nonSpaceChar.test(n), s = this.rules.other.startingSpaceChar.test(n) && this.rules.other.endingSpaceChar.test(n);
      return r && s && (n = n.substring(1, n.length - 1)), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    let t = e.charCodeAt(0);
    if (t !== 32 && t !== 92 && t !== 10) return;
    let n = this.rules.inline.br.exec(e);
    if (n) return {
      type: "br",
      raw: n[0]
    };
  }
  del(e, t, n = "") {
    if (e.charCodeAt(0) !== 126) return;
    let r = this.rules.inline.delLDelim.exec(e);
    if (!r) return;
    if (!(r[1] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      let o = [...r[0]].length - 1, i, a, c = o, u = this.rules.inline.delRDelim, d = ae(this, t), h = t.length - e.length + o;
      if (d < h) return;
      t = t.slice(-1 * e.length + o);
      let p = d - h;
      for (u.lastIndex = 0; (r = u.exec(t)) !== null && !(r.index > p); ) {
        if (i = r[1] || r[2] || r[3] || r[4] || r[5] || r[6], !i || (a = [...i].length, a !== o)) continue;
        if (r[3] || r[4]) {
          c += a;
          continue;
        }
        if (c -= a, c > 0) continue;
        a = Math.min(a, a + c);
        let k = [...r[0]][0].length, m = e.slice(0, o + r.index + k + a), b = m.slice(o, -o);
        return {
          type: "del",
          raw: m,
          text: b,
          tokens: this.lexer.inlineTokens(b)
        };
      }
    }
  }
  autolink(e) {
    if (e.charCodeAt(0) !== 60) return;
    let t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, r;
      return t[2] === "@" ? (n = t[1], r = "mailto:" + n) : (n = t[1], r = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: r,
        autolink: true,
        tokens: [{
          type: "text",
          raw: n,
          text: n
        }]
      };
    }
  }
  url(e) {
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let n, r;
      if (t[2] === "@") n = t[0], r = "mailto:" + n;
      else {
        let s;
        do
          s = t[0], t[0] = this.rules.inline._backpedal.exec(t[0])?.[0] ?? "";
        while (s !== t[0]);
        n = t[0], t[1] === "www." ? r = "http://" + t[0] : r = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: n,
        href: r,
        autolink: true,
        tokens: [{
          type: "text",
          raw: n,
          text: n
        }]
      };
    }
  }
  inlineText(e) {
    let t = this.rules.inline.text.exec(e);
    if (t) {
      let n = this.lexer.state.inRawBlock;
      return {
        type: "text",
        raw: t[0],
        text: n ? t[0] : De(t[0]),
        escaped: n
      };
    }
  }
};
var w = class l {
  tokens;
  options;
  state;
  inlineQueue;
  tokenizer;
  constructor(e) {
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || S, this.options.tokenizer = this.options.tokenizer || new _(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: false,
      inRawBlock: false,
      linkEmitted: false,
      linkParenPossible: true,
      top: true
    };
    let t = {
      other: O,
      block: ee.normal,
      inline: F.normal
    };
    this.options.pedantic ? (t.block = ee.pedantic, t.inline = F.pedantic) : this.options.gfm && (t.block = ee.gfm, this.options.breaks ? t.inline = F.breaks : t.inline = F.gfm), this.tokenizer.rules = t;
  }
  static get rules() {
    return {
      block: ee,
      inline: F
    };
  }
  static lex(e, t) {
    return new l(t).lex(e);
  }
  static lexInline(e, t) {
    return new l(t).inlineTokens(e);
  }
  lex(e) {
    e = e.replace(O.carriageReturn, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      let n = this.inlineQueue[t];
      this.state.inRawBlock = false, this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = [], n = false) {
    this.tokenizer.lexer = this;
    let r = this.state.lastToken;
    this.options.pedantic && (e = e.replace(O.tabCharGlobal, "    ").replace(O.spaceLine, ""));
    let s = 1 / 0, o, i = this.options.gfm && !this.options.pedantic && this.tokenizer.paragraph === _.prototype.paragraph;
    for (; e; ) {
      if (e.length < s) s = e.length;
      else {
        this.infiniteLoopError(e.charCodeAt(0));
        break;
      }
      this.state.lastToken = t.at(-1);
      let a;
      if (this.options.extensions?.block?.some((u) => (a = u.call({
        lexer: this
      }, e, t)) ? (e = e.substring(a.raw.length), t.push(a), true) : false)) continue;
      if (a = this.tokenizer.space(e)) {
        e = e.substring(a.raw.length);
        let u = t.at(-1);
        a.raw.length === 1 && u !== void 0 ? u.raw += `
` : t.push(a);
        continue;
      }
      if (a = this.tokenizer.code(e)) {
        e = e.substring(a.raw.length);
        let u = t.at(-1);
        u?.type === "paragraph" || u?.type === "text" ? (u.raw += (u.raw.endsWith(`
`) ? "" : `
`) + a.raw, u.text += `
` + a.text, this.inlineQueue.at(-1).src = u.text) : t.push(a);
        continue;
      }
      if (a = this.tokenizer.fences(e)) {
        e = e.substring(a.raw.length), t.push(a);
        continue;
      }
      if (a = this.tokenizer.heading(e)) {
        e = e.substring(a.raw.length), t.push(a);
        continue;
      }
      if (a = this.tokenizer.hr(e)) {
        e = e.substring(a.raw.length), t.push(a);
        continue;
      }
      if (a = this.tokenizer.blockquote(e)) {
        e = e.substring(a.raw.length), t.push(a);
        continue;
      }
      if (a = this.tokenizer.list(e)) {
        e = e.substring(a.raw.length), t.push(a);
        continue;
      }
      if (a = this.tokenizer.html(e)) {
        e = e.substring(a.raw.length), t.push(a);
        continue;
      }
      if (a = this.tokenizer.def(e)) {
        e = e.substring(a.raw.length);
        let u = t.at(-1);
        u?.type === "paragraph" || u?.type === "text" ? (u.raw += (u.raw.endsWith(`
`) ? "" : `
`) + a.raw, u.text += `
` + a.raw, this.inlineQueue.at(-1).src = u.text) : (this.tokens.links[a.tag] || (this.tokens.links[a.tag] = {
          href: a.href,
          title: a.title
        }), t.push(a));
        continue;
      }
      if (a = this.tokenizer.table(e)) {
        e = e.substring(a.raw.length), t.push(a);
        continue;
      }
      if (a = this.tokenizer.lheading(e)) {
        e = e.substring(a.raw.length), t.push(a);
        continue;
      }
      let c = e;
      if (this.options.extensions?.startBlock) {
        let u = 1 / 0, d = e.slice(1), h;
        this.options.extensions.startBlock.forEach((p) => {
          h = p.call({
            lexer: this
          }, d), typeof h == "number" && h >= 0 && (u = Math.min(u, h));
        }), u < 1 / 0 && u >= 0 && (c = e.substring(0, u + 1));
      }
      if (this.state.top && (a = this.tokenizer.paragraph(c))) {
        let u = t.at(-1);
        (n || u === o && i) && u?.type === "paragraph" ? (u.raw += (u.raw.endsWith(`
`) ? "" : `
`) + a.raw, u.text += `
` + a.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = u.text, o = u) : (t.push(a), o = a), n = c.length !== e.length, e = e.substring(a.raw.length);
        continue;
      }
      if (a = this.tokenizer.text(e)) {
        e = e.substring(a.raw.length);
        let u = t.at(-1);
        u?.type === "text" ? (u.raw += (u.raw.endsWith(`
`) ? "" : `
`) + a.raw, u.text += `
` + a.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = u.text) : t.push(a);
        continue;
      }
      if (e) {
        this.infiniteLoopError(e.charCodeAt(0));
        break;
      }
    }
    return this.state.top = true, this.state.lastToken = r, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({
      src: e,
      tokens: t
    }), t;
  }
  linkInText(e) {
    if (!e.includes("[")) return false;
    let t = this.tokenizer.rules.inline.link;
    for (let n of e.matchAll(this.tokenizer.rules.inline.blockSkip)) if (t.test(n[0]) && e.charAt(n.index - 1) !== "!") return true;
    for (let n of e.matchAll(this.tokenizer.rules.inline.reflinkSearch)) {
      let r = n[0], s = r.lastIndexOf("[");
      if (!(r.charAt(0) === "!" || !Object.hasOwn(this.tokens.links, W(r.slice(s + 1, -1)))) && !(s > 1 && this.linkInText(r.slice(1, s - 1)))) return true;
    }
    return false;
  }
  inlineTokens(e, t = []) {
    this.tokenizer.lexer = this;
    let n = this.state.linkParenPossible;
    this.state.linkParenPossible = e.includes(")");
    try {
      return this.#t(e, t);
    } finally {
      this.state.linkParenPossible = n;
    }
  }
  #t(e, t) {
    let n = e.includes("*") || e.includes("_") || e.includes("~"), r = n || this.options.hooks?.emStrongMask || this.tokenizer.emStrong !== _.prototype.emStrong || this.tokenizer.del !== _.prototype.del ? this.#r(e) : e;
    if (!n) return this.#e(e, r, t);
    qe(this.tokenizer, r);
    try {
      return this.#e(e, r, t);
    } finally {
      ve(this.tokenizer);
    }
  }
  #e(e, t, n) {
    let r = false, s = "", o = 1 / 0;
    for (; e; ) {
      if (e.length < o) o = e.length;
      else {
        this.infiniteLoopError(e.charCodeAt(0));
        break;
      }
      r || (s = ""), r = false;
      let i;
      if (this.options.extensions?.inline?.some((u) => (i = u.call({
        lexer: this
      }, e, n)) ? (e = e.substring(i.raw.length), n.push(i), true) : false)) continue;
      if (i = this.tokenizer.escape(e)) {
        e = e.substring(i.raw.length), n.push(i);
        continue;
      }
      if (i = this.tokenizer.tag(e)) {
        e = e.substring(i.raw.length), n.push(i);
        continue;
      }
      if (i = this.tokenizer.link(e)) {
        e = e.substring(i.raw.length), n.push(i);
        continue;
      }
      if (i = this.tokenizer.reflink(e, this.tokens.links)) {
        e = e.substring(i.raw.length);
        let u = n.at(-1);
        i.type === "text" && u?.type === "text" ? (u.raw += i.raw, u.text += i.text) : n.push(i);
        continue;
      }
      let a = e[0];
      if (a === "*" || a === "_") {
        let u = t.length - e.length;
        if (oe(this.tokenizer, t, a) <= u) {
          let h = 1;
          for (; h < e.length && e.charCodeAt(h) === a.charCodeAt(0); ) h++;
          let p = e.substring(0, h), k = n.at(-1);
          k?.type === "text" && !k.escaped ? (k.raw += p, k.text += p) : n.push({
            type: "text",
            raw: p,
            text: p,
            escaped: false
          }), e = e.substring(h), s = a, r = true;
          continue;
        }
      } else if (a === "~") {
        let u = t.length - e.length;
        if (ae(this.tokenizer, t) <= u) {
          let h = 1;
          for (; h < e.length && e.charCodeAt(h) === 126; ) h++;
          let p = e.substring(0, h), k = n.at(-1);
          k?.type === "text" && !k.escaped ? (k.raw += p, k.text += p) : n.push({
            type: "text",
            raw: p,
            text: p,
            escaped: false
          }), e = e.substring(h), s = a, r = true;
          continue;
        }
      }
      if (i = this.tokenizer.emStrong(e, t, s)) {
        e = e.substring(i.raw.length), n.push(i);
        continue;
      }
      if (i = this.tokenizer.codespan(e)) {
        e = e.substring(i.raw.length), n.push(i);
        continue;
      }
      if (i = this.tokenizer.br(e)) {
        e = e.substring(i.raw.length), n.push(i);
        continue;
      }
      if (i = this.tokenizer.del(e, t, s)) {
        e = e.substring(i.raw.length), n.push(i);
        continue;
      }
      if (i = this.tokenizer.autolink(e)) {
        e = e.substring(i.raw.length), n.push(i);
        continue;
      }
      if (!this.state.inLink && (i = this.tokenizer.url(e))) {
        e = e.substring(i.raw.length), n.push(i);
        continue;
      }
      let c = e;
      if (this.options.extensions?.startInline) {
        let u = 1 / 0, d = e.slice(1), h;
        this.options.extensions.startInline.forEach((p) => {
          h = p.call({
            lexer: this
          }, d), typeof h == "number" && h >= 0 && (u = Math.min(u, h));
        }), u < 1 / 0 && u >= 0 && (c = e.substring(0, u + 1));
      }
      if (i = this.tokenizer.inlineText(c)) {
        e = e.substring(i.raw.length), i.raw.slice(-1) !== "_" && (s = i.raw.slice(-1)), r = true;
        let u = n.at(-1);
        u?.type === "text" ? (u.raw += i.raw, u.text += i.text) : n.push(i);
        continue;
      }
      if (e) {
        this.infiniteLoopError(e.charCodeAt(0));
        break;
      }
    }
    return n;
  }
  #n(e) {
    let {
      blockSkip: t,
      tag: n,
      autolink: r
    } = this.tokenizer.rules.inline, s = "", o = 0, i;
    for (t.lastIndex = 0; i = t.exec(e); ) {
      let a = i.index + (i[2] ? i[2].length : 0), c = i.index + i[0].length;
      if (e.charAt(a) === "<") {
        let u = e.slice(a), d = n.exec(u) || r.exec(u);
        if (!d) {
          t.lastIndex = a + 1;
          continue;
        }
        c = a + d[0].length, t.lastIndex = c;
      }
      s += e.slice(o, a) + "[" + "a".repeat(c - a - 2) + "]", o = c;
    }
    return s + e.slice(o);
  }
  #r(e) {
    let t = e;
    if (this.tokens.links && e.includes("[")) {
      let n = this.tokenizer.rules.inline.reflinkSearch, r = (s) => {
        let o = s.lastIndexOf("[");
        if (!Object.hasOwn(this.tokens.links, W(s.slice(o + 1, -1)))) return s;
        if (o > 1 && s.charAt(0) !== "!") {
          let i = s.slice(1, o - 1);
          if (this.linkInText(i)) return "[" + i.replace(n, r) + "][" + "a".repeat(s.length - o - 2) + "]";
        }
        return "[" + "a".repeat(s.length - 2) + "]";
      };
      t = t.replace(n, r);
    }
    return t = t.replace(this.tokenizer.rules.inline.anyPunctuationOutsideCode, (n, r, s) => s ? "+".repeat(n.length) : r ? r + n.slice(r.length, -r.length).replace(/`/g, "+") + r : n), t = this.#n(t), t = this.options.hooks?.emStrongMask?.call({
      lexer: this
    }, t) ?? t, t;
  }
  infiniteLoopError(e) {
    let t = "Infinite loop on byte: " + e;
    if (this.options.silent) console.error(t);
    else throw new Error(t);
  }
};
var I = class {
  options;
  parser;
  constructor(e) {
    this.options = e || S;
  }
  space(e) {
    return "";
  }
  code({
    text: e,
    lang: t,
    escaped: n
  }) {
    let r = (t || "").match(O.notSpaceStart)?.[0], s = e ? e.replace(O.endingNewline, "") + `
` : "";
    return r ? '<pre><code class="language-' + y(r) + '">' + (n ? s : y(s, true)) + `</code></pre>
` : "<pre><code>" + (n ? s : y(s, true)) + `</code></pre>
`;
  }
  blockquote({
    tokens: e
  }) {
    return `<blockquote>
${this.parser.parse(e)}</blockquote>
`;
  }
  html({
    text: e
  }) {
    return e;
  }
  def(e) {
    return "";
  }
  heading({
    tokens: e,
    depth: t
  }) {
    return `<h${t}>${this.parser.parseInline(e)}</h${t}>
`;
  }
  hr(e) {
    return `<hr>
`;
  }
  list(e) {
    let t = e.ordered, n = e.start, r = "";
    for (let i = 0; i < e.items.length; i++) {
      let a = e.items[i];
      r += this.listitem(a);
    }
    let s = t ? "ol" : "ul", o = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + s + o + `>
` + r + "</" + s + `>
`;
  }
  listitem(e) {
    return `<li>${this.parser.parse(e.tokens)}</li>
`;
  }
  checkbox({
    checked: e
  }) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox"> ';
  }
  paragraph({
    tokens: e
  }) {
    return `<p>${this.parser.parseInline(e)}</p>
`;
  }
  table(e) {
    let t = "", n = "";
    for (let s = 0; s < e.header.length; s++) n += this.tablecell(e.header[s]);
    t += this.tablerow({
      text: n
    });
    let r = "";
    for (let s = 0; s < e.rows.length; s++) {
      let o = e.rows[s];
      n = "";
      for (let i = 0; i < o.length; i++) n += this.tablecell(o[i]);
      r += this.tablerow({
        text: n
      });
    }
    return r && (r = `<tbody>${r}</tbody>`), `<table>
<thead>
` + t + `</thead>
` + r + `</table>
`;
  }
  tablerow({
    text: e
  }) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e) {
    let t = this.parser.parseInline(e.tokens), n = e.header ? "th" : "td";
    return (e.align ? `<${n} align="${e.align}">` : `<${n}>`) + t + `</${n}>
`;
  }
  strong({
    tokens: e
  }) {
    return `<strong>${this.parser.parseInline(e)}</strong>`;
  }
  em({
    tokens: e
  }) {
    return `<em>${this.parser.parseInline(e)}</em>`;
  }
  codespan({
    text: e
  }) {
    return `<code>${y(e, true)}</code>`;
  }
  br(e) {
    return "<br>";
  }
  del({
    tokens: e
  }) {
    return `<del>${this.parser.parseInline(e)}</del>`;
  }
  link({
    href: e,
    title: t,
    text: n,
    tokens: r,
    autolink: s
  }) {
    let o = s ? y(n, true) : this.parser.parseInline(r), i = xe(e);
    if (i === null) return o;
    e = y(i, s);
    let a = '<a href="' + e + '"';
    return t && (a += ' title="' + y(t) + '"'), a += ">" + o + "</a>", a;
  }
  image({
    href: e,
    title: t,
    text: n,
    tokens: r
  }) {
    r && (n = this.parser.parseInline(r, this.parser.textRenderer));
    let s = xe(e);
    if (s === null) return y(n);
    e = s;
    let o = `<img src="${y(e)}" alt="${y(n)}"`;
    return t && (o += ` title="${y(t)}"`), o += ">", o;
  }
  text(e) {
    return "tokens" in e && e.tokens ? this.parser.parseInline(e.tokens) : "escaped" in e && e.escaped ? e.text : y(e.text);
  }
};
var z = class {
  parser;
  strong({
    text: e,
    tokens: t
  }) {
    return t ? this.parser.parseInline(t, this) : e;
  }
  em({
    text: e,
    tokens: t
  }) {
    return t ? this.parser.parseInline(t, this) : e;
  }
  codespan({
    text: e
  }) {
    return e;
  }
  del({
    text: e,
    tokens: t
  }) {
    return t ? this.parser.parseInline(t, this) : e;
  }
  html({
    text: e
  }) {
    return e;
  }
  text({
    text: e
  }) {
    return e;
  }
  link({
    text: e,
    tokens: t
  }) {
    return t ? this.parser.parseInline(t, this) : e;
  }
  image({
    text: e,
    tokens: t
  }) {
    return t ? this.parser.parseInline(t, this) : e;
  }
  br() {
    return `
`;
  }
  checkbox({
    raw: e
  }) {
    return e;
  }
};
var P = class l2 {
  options;
  renderer;
  textRenderer;
  constructor(e) {
    this.options = e || S, this.options.renderer = this.options.renderer || new I(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.renderer.parser = this, this.textRenderer = new z(), this.textRenderer.parser = this;
  }
  static parse(e, t) {
    return new l2(t).parse(e);
  }
  static parseInline(e, t) {
    return new l2(t).parseInline(e);
  }
  parse(e) {
    this.renderer.parser = this;
    let t = "";
    for (let n = 0; n < e.length; n++) {
      let r = e[n];
      if (this.options.extensions?.renderers?.[r.type]) {
        let o = r, i = this.options.extensions.renderers[o.type].call({
          parser: this
        }, o);
        if (i !== false || !["space", "hr", "heading", "code", "table", "blockquote", "list", "checkbox", "html", "def", "paragraph", "text"].includes(o.type)) {
          t += i === false ? "" : i ?? "";
          continue;
        }
      }
      let s = r;
      switch (s.type) {
        case "space": {
          t += this.renderer.space(s);
          break;
        }
        case "hr": {
          t += this.renderer.hr(s);
          break;
        }
        case "heading": {
          t += this.renderer.heading(s);
          break;
        }
        case "code": {
          t += this.renderer.code(s);
          break;
        }
        case "table": {
          t += this.renderer.table(s);
          break;
        }
        case "blockquote": {
          t += this.renderer.blockquote(s);
          break;
        }
        case "list": {
          t += this.renderer.list(s);
          break;
        }
        case "checkbox": {
          t += this.renderer.checkbox(s);
          break;
        }
        case "html": {
          t += this.renderer.html(s);
          break;
        }
        case "def": {
          t += this.renderer.def(s);
          break;
        }
        case "paragraph": {
          t += this.renderer.paragraph(s);
          break;
        }
        case "text": {
          t += this.renderer.text(s);
          break;
        }
        default: {
          let o = 'Token with "' + s.type + '" type was not found.';
          if (this.options.silent) return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return t;
  }
  parseInline(e, t = this.renderer) {
    this.renderer.parser = this;
    let n = "";
    for (let r = 0; r < e.length; r++) {
      let s = e[r];
      if (this.options.extensions?.renderers?.[s.type]) {
        let i = this.options.extensions.renderers[s.type].call({
          parser: this
        }, s);
        if (i !== false || !["escape", "html", "link", "image", "checkbox", "strong", "em", "codespan", "br", "del", "text"].includes(s.type)) {
          n += i === false ? "" : i ?? "";
          continue;
        }
      }
      let o = s;
      switch (o.type) {
        case "escape": {
          n += t.text(o);
          break;
        }
        case "html": {
          n += t.html(o);
          break;
        }
        case "link": {
          n += t.link(o);
          break;
        }
        case "image": {
          n += t.image(o);
          break;
        }
        case "checkbox": {
          n += t.checkbox(o);
          break;
        }
        case "strong": {
          n += t.strong(o);
          break;
        }
        case "em": {
          n += t.em(o);
          break;
        }
        case "codespan": {
          n += t.codespan(o);
          break;
        }
        case "br": {
          n += t.br(o);
          break;
        }
        case "del": {
          n += t.del(o);
          break;
        }
        case "text": {
          n += t.text(o);
          break;
        }
        default: {
          let i = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent) return console.error(i), "";
          throw new Error(i);
        }
      }
    }
    return n;
  }
};
var A = class {
  options;
  block;
  constructor(e) {
    this.options = e || S;
  }
  static passThroughHooks = /* @__PURE__ */ new Set(["preprocess", "postprocess", "processAllTokens", "emStrongMask"]);
  static passThroughHooksRespectAsync = /* @__PURE__ */ new Set(["preprocess", "postprocess", "processAllTokens"]);
  preprocess(e) {
    return e;
  }
  postprocess(e) {
    return e;
  }
  processAllTokens(e) {
    return e;
  }
  emStrongMask(e) {
    return e;
  }
  provideLexer(e = this.block) {
    return e ? w.lex : w.lexInline;
  }
  provideParser(e = this.block) {
    return e ? P.parse : P.parseInline;
  }
};
function M(l3, e) {
  if (Array.isArray(e)) for (let t = 0; t < e.length; t++) l3.push(e[t]);
  else l3.push(e);
}
var ne = class {
  defaults = G();
  options = this.setOptions;
  parse = this.parseMarkdown(true);
  parseInline = this.parseMarkdown(false);
  Parser = P;
  Renderer = I;
  TextRenderer = z;
  Lexer = w;
  Tokenizer = _;
  Hooks = A;
  constructor(...e) {
    this.use(...e);
  }
  walkTokens(e, t) {
    let n = [];
    for (let r of e) switch (M(n, t.call(this, r)), r.type) {
      case "table": {
        let s = r;
        for (let o of s.header) M(n, this.walkTokens(o.tokens, t));
        for (let o of s.rows) for (let i of o) M(n, this.walkTokens(i.tokens, t));
        break;
      }
      case "list": {
        let s = r;
        M(n, this.walkTokens(s.items, t));
        break;
      }
      default: {
        let s = r;
        this.defaults.extensions?.childTokens?.[s.type] ? this.defaults.extensions.childTokens[s.type].forEach((o) => {
          let i = s[o].flat(1 / 0);
          M(n, this.walkTokens(i, t));
        }) : s.tokens && M(n, this.walkTokens(s.tokens, t));
      }
    }
    return n;
  }
  use(...e) {
    let t = this.defaults.extensions || {
      renderers: /* @__PURE__ */ Object.create(null),
      childTokens: /* @__PURE__ */ Object.create(null)
    };
    return e.forEach((n) => {
      let r = __spreadValues({}, n);
      if (r.async = this.defaults.async || r.async || false, n.extensions && (n.extensions.forEach((s) => {
        if (!s.name) throw new Error("extension name required");
        if ("renderer" in s) {
          let o = t.renderers[s.name];
          o ? t.renderers[s.name] = function(...i) {
            let a = s.renderer.apply(this, i);
            return a === false && (a = o.apply(this, i)), a;
          } : t.renderers[s.name] = s.renderer;
        }
        if ("tokenizer" in s) {
          if (!s.level || s.level !== "block" && s.level !== "inline") throw new Error("extension level must be 'block' or 'inline'");
          let o = t[s.level];
          o ? o.unshift(s.tokenizer) : t[s.level] = [s.tokenizer], s.start && (s.level === "block" ? t.startBlock ? t.startBlock.push(s.start) : t.startBlock = [s.start] : s.level === "inline" && (t.startInline ? t.startInline.push(s.start) : t.startInline = [s.start]));
        }
        "childTokens" in s && s.childTokens && (t.childTokens[s.name] = s.childTokens);
      }), r.extensions = t), n.renderer) {
        let s = this.defaults.renderer || new I(this.defaults);
        for (let o in n.renderer) {
          if (!(o in s)) throw new Error(`renderer '${o}' does not exist`);
          if (["options", "parser"].includes(o)) continue;
          let i = o, a = n.renderer[i], c = s[i];
          s[i] = (...u) => {
            let d = a.apply(s, u);
            return d === false && (d = c.apply(s, u)), d === false ? "" : d ?? "";
          };
        }
        r.renderer = s;
      }
      if (n.tokenizer) {
        let s = this.defaults.tokenizer || new _(this.defaults);
        for (let o in n.tokenizer) {
          if (!(o in s)) throw new Error(`tokenizer '${o}' does not exist`);
          if (["options", "rules", "lexer"].includes(o)) continue;
          let i = o, a = n.tokenizer[i], c = s[i];
          s[i] = (...u) => {
            let d = a.apply(s, u);
            return d === false && (d = c.apply(s, u)), d;
          };
        }
        r.tokenizer = s;
      }
      if (n.hooks) {
        let s = this.defaults.hooks || new A();
        for (let o in n.hooks) {
          if (!(o in s)) throw new Error(`hook '${o}' does not exist`);
          if (["options", "block"].includes(o)) continue;
          let i = o, a = n.hooks[i], c = s[i];
          A.passThroughHooks.has(o) ? s[i] = (u) => {
            if (s.options.async && A.passThroughHooksRespectAsync.has(o)) return (() => __async(this, null, function* () {
              let h = yield a.call(s, u);
              return c.call(s, h);
            }))();
            let d = a.call(s, u);
            return c.call(s, d);
          } : s[i] = (...u) => {
            if (s.options.async) return (() => __async(this, null, function* () {
              let h = yield a.apply(s, u);
              return h === false && (h = yield c.apply(s, u)), h;
            }))();
            let d = a.apply(s, u);
            return d === false && (d = c.apply(s, u)), d;
          };
        }
        r.hooks = s;
      }
      if (n.walkTokens) {
        let s = this.defaults.walkTokens, o = n.walkTokens;
        r.walkTokens = function(i) {
          let a = [];
          return M(a, o.call(this, i)), s && M(a, s.call(this, i)), a;
        };
      }
      this.defaults = __spreadValues(__spreadValues({}, this.defaults), r);
    }), this;
  }
  setOptions(e) {
    return this.defaults = __spreadValues(__spreadValues({}, this.defaults), e), this;
  }
  lexer(e, t) {
    return w.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return P.parse(e, t ?? this.defaults);
  }
  parseMarkdown(e) {
    return (n, r) => {
      let s = __spreadValues({}, r), o = __spreadValues(__spreadValues({}, this.defaults), s), i = this.onError(!!o.silent, !!o.async);
      if (this.defaults.async === true && s.async === false) return i(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
      if (typeof n > "u" || n === null) return i(new Error("marked(): input parameter is undefined or null"));
      if (typeof n != "string") return i(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
      if (o.hooks && (o.hooks.options = o, o.hooks.block = e), o.async) return (() => __async(this, null, function* () {
        let a = o.hooks ? yield o.hooks.preprocess(n) : n, u = yield (o.hooks ? yield o.hooks.provideLexer(e) : e ? w.lex : w.lexInline)(a, o), d = o.hooks ? yield o.hooks.processAllTokens(u) : u;
        o.walkTokens && (yield Promise.all(this.walkTokens(d, o.walkTokens)));
        let p = yield (o.hooks ? yield o.hooks.provideParser(e) : e ? P.parse : P.parseInline)(d, o);
        return o.hooks ? yield o.hooks.postprocess(p) : p;
      }))().catch(i);
      try {
        o.hooks && (n = o.hooks.preprocess(n));
        let c = (o.hooks ? o.hooks.provideLexer(e) : e ? w.lex : w.lexInline)(n, o);
        o.hooks && (c = o.hooks.processAllTokens(c)), o.walkTokens && this.walkTokens(c, o.walkTokens);
        let d = (o.hooks ? o.hooks.provideParser(e) : e ? P.parse : P.parseInline)(c, o);
        return o.hooks && (d = o.hooks.postprocess(d)), d;
      } catch (a) {
        return i(a);
      }
    };
  }
  onError(e, t) {
    return (n) => {
      if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
        let r = "<p>An error occurred:</p><pre>" + y(n.message + "", true) + "</pre>";
        return t ? Promise.resolve(r) : r;
      }
      if (t) return Promise.reject(n);
      throw n;
    };
  }
};
var v = new ne();
function x(l3, e) {
  return v.parse(l3, e);
}
x.options = x.setOptions = function(l3) {
  return v.setOptions(l3), x.defaults = v.defaults, ue(x.defaults), x;
};
x.getDefaults = G;
x.defaults = S;
function jt(...l3) {
  return v.use(...l3), x.defaults = v.defaults, ue(x.defaults), x;
}
x.use = jt;
x.walkTokens = function(l3, e) {
  return v.walkTokens(l3, e);
};
x.parseInline = v.parseInline;
x.Parser = P;
x.parser = P.parse;
x.Renderer = I;
x.TextRenderer = z;
x.Lexer = w;
x.lexer = w.lex;
x.Tokenizer = _;
x.Hooks = A;
x.parse = x;
var En = x.options;
var zn = x.setOptions;
var Mn = x.walkTokens;
var Bn = x.parseInline;
var Dn = x;
var qn = P.parse;
var vn = w.lex;
export {
  A as Hooks,
  w as Lexer,
  ne as Marked,
  P as Parser,
  I as Renderer,
  z as TextRenderer,
  _ as Tokenizer,
  S as defaults,
  G as getDefaults,
  vn as lexer,
  x as marked,
  En as options,
  Dn as parse,
  Bn as parseInline,
  qn as parser,
  zn as setOptions,
  jt as use,
  Mn as walkTokens
};
//# sourceMappingURL=marked.js.map
