import { Component, HostListener, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SidebarComponent } from './layout/sidebar/sidebar.component';
import { HeaderComponent } from './layout/header/header.component';
import { ChatWindowComponent } from './features/chat/chat-window/chat-window.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, SidebarComponent, HeaderComponent, ChatWindowComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
  host: {
    'class': 'block h-full w-full'
  }
})
export class AppComponent {
  readonly isSidebarOpen = signal<boolean>(false);

  public toggleSidebar(): void {
    this.isSidebarOpen.update(v => !v);
  }

  public closeSidebar(): void {
    this.isSidebarOpen.set(false);
  }

  @HostListener('window:keydown.escape')
  public onEscape(): void {
    if (this.isSidebarOpen()) {
      this.closeSidebar();
    }
  }
}
