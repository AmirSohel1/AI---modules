import { Injectable, computed, inject, signal } from '@angular/core';
import { StorageService } from './storage.service';
import { Conversation } from '../models/conversation.model';
import { ChatMessage } from '../models/message.model';
import { environment } from '../../../environments/environment';

export interface ConversationGroup {
  label: string;
  items: Conversation[];
}

@Injectable({
  providedIn: 'root'
})
export class ChatService {
  private storageService = inject(StorageService);

  readonly currentConversationId = signal<string | null>(null);
  readonly isGenerating = signal<boolean>(false);
  readonly errorMessage = signal<string | null>(null);
  readonly searchQuery = signal<string>('');

  private abortController: AbortController | null = null;

  readonly conversations = this.storageService.conversations;

  readonly currentConversation = computed<Conversation | null>(() => {
    const id = this.currentConversationId();
    if (!id) return null;
    return this.conversations().find(c => c.id === id) || null;
  });

  readonly groupedConversations = computed<ConversationGroup[]>(() => {
    const query = this.searchQuery().trim().toLowerCase();
    const list = this.conversations().filter(c =>
      !query || c.title.toLowerCase().includes(query)
    );

    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const startOfYesterday = startOfToday - 86400000;
    const startOfWeek = startOfToday - 7 * 86400000;

    const today: Conversation[] = [];
    const yesterday: Conversation[] = [];
    const thisWeek: Conversation[] = [];
    const older: Conversation[] = [];

    for (const c of list) {
      if (c.updatedAt >= startOfToday) {
        today.push(c);
      } else if (c.updatedAt >= startOfYesterday) {
        yesterday.push(c);
      } else if (c.updatedAt >= startOfWeek) {
        thisWeek.push(c);
      } else {
        older.push(c);
      }
    }

    const groups: ConversationGroup[] = [];
    if (today.length) groups.push({ label: 'Today', items: today });
    if (yesterday.length) groups.push({ label: 'Yesterday', items: yesterday });
    if (thisWeek.length) groups.push({ label: 'Previous 7 Days', items: thisWeek });
    if (older.length) groups.push({ label: 'Older', items: older });

    return groups;
  });

  constructor() {
    const list = this.conversations();
    if (list.length > 0) {
      this.currentConversationId.set(list[0].id);
    }
  }

  public startNewChat(): void {
    this.stopGenerating();
    this.currentConversationId.set(null);
    this.errorMessage.set(null);
  }

  public selectConversation(id: string): void {
    if (this.currentConversationId() === id) return;
    this.stopGenerating();
    this.currentConversationId.set(id);
    this.errorMessage.set(null);
  }

  public renameConversation(id: string, newTitle: string): void {
    const trimmed = newTitle.trim();
    if (!trimmed) return;
    const conversation = this.conversations().find(c => c.id === id);
    if (conversation) {
      const updated: Conversation = {
        ...conversation,
        title: trimmed,
        updatedAt: Date.now()
      };
      this.storageService.upsertConversation(updated);
    }
  }

  public deleteConversation(id: string): void {
    this.storageService.removeConversation(id);
    if (this.currentConversationId() === id) {
      const remaining = this.conversations();
      if (remaining.length > 0) {
        this.currentConversationId.set(remaining[0].id);
      } else {
        this.currentConversationId.set(null);
      }
    }
  }

  public clearAllConversations(): void {
    this.stopGenerating();
    this.storageService.clearAllConversations();
    this.currentConversationId.set(null);
    this.errorMessage.set(null);
  }

  public deleteMessage(messageId: string): void {
    const conversation = this.currentConversation();
    if (!conversation) return;

    const filtered = conversation.messages.filter(m => m.id !== messageId);
    const updated: Conversation = {
      ...conversation,
      updatedAt: Date.now(),
      messages: filtered
    };
    this.storageService.upsertConversation(updated);
  }

  public exportCurrentChat(): void {
    const conversation = this.currentConversation();
    if (!conversation || conversation.messages.length === 0) return;

    let md = `# ${conversation.title}\n`;
    md += `*Exported from AeroGPT on ${new Date().toLocaleString()}*\n\n---\n\n`;

    for (const msg of conversation.messages) {
      const roleName = msg.role === 'user' ? '👤 User' : '⚡ AeroGPT';
      const time = new Date(msg.timestamp).toLocaleTimeString();
      md += `### ${roleName} (${time})\n\n${msg.content}\n\n---\n\n`;
    }

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${conversation.title.replace(/[^a-zA-Z0-9_-]/g, '_')}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  public stopGenerating(): void {
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }
    this.isGenerating.set(false);

    // Finalize any in-progress assistant streaming flag
    const current = this.currentConversation();
    if (current && current.messages.length > 0) {
      const lastMsg = current.messages[current.messages.length - 1];
      if (lastMsg.role === 'assistant' && lastMsg.isStreaming) {
        lastMsg.isStreaming = false;
        this.storageService.upsertConversation({ ...current, updatedAt: Date.now() });
      }
    }
  }

  public async sendMessage(content: string): Promise<void> {
    const userText = content.trim();
    if (!userText || this.isGenerating()) return;

    this.errorMessage.set(null);

    let conversation = this.currentConversation();
    const now = Date.now();

    if (!conversation) {
      // Create new conversation; title is first user message (truncated)
      const title = userText.length > 40 ? `${userText.slice(0, 37)}...` : userText;
      conversation = {
        id: `conv_${now}_${Math.random().toString(36).substring(2, 7)}`,
        title,
        createdAt: now,
        updatedAt: now,
        messages: []
      };
      this.currentConversationId.set(conversation.id);
    }

    const userMessage: ChatMessage = {
      id: `msg_${now}_user`,
      role: 'user',
      content: userText,
      timestamp: now
    };

    const assistantMessageId = `msg_${now + 1}_assistant`;
    const assistantMessage: ChatMessage = {
      id: assistantMessageId,
      role: 'assistant',
      content: '',
      timestamp: now + 1,
      isStreaming: true
    };

    // Update conversation state with user message + streaming placeholder
    const updatedMessages = [...conversation.messages, userMessage, assistantMessage];
    const updatedConversation: Conversation = {
      ...conversation,
      updatedAt: now,
      messages: updatedMessages
    };
    this.storageService.upsertConversation(updatedConversation);

    // Prepare full history for the stateless backend
    const apiPayload = {
      messages: updatedMessages
        .filter(m => m.id !== assistantMessageId)
        .map(m => ({ role: m.role, content: m.content }))
    };

    this.isGenerating.set(true);
    this.abortController = new AbortController();

    try {
      const response = await fetch(`${environment.apiUrl}/api/chat/stream`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(apiPayload),
        signal: this.abortController.signal
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Server returned HTTP ${response.status}: ${errorText || response.statusText}`);
      }

      if (!response.body) {
        throw new Error('Streaming response body is unavailable');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let buffer = '';
      let accumulatedText = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        // Keep the last incomplete fragment in the buffer
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmedLine = line.trim();
          if (!trimmedLine || !trimmedLine.startsWith('data:')) continue;

          const dataStr = trimmedLine.replace(/^data:\s*/, '');
          if (dataStr === '[DONE]') {
            break;
          }

          try {
            const parsed = JSON.parse(dataStr);
            if (parsed.error) {
              throw new Error(parsed.error);
            }
            if (parsed.content) {
              accumulatedText += parsed.content;
              this.updateAssistantContent(assistantMessageId, accumulatedText, true);
            }
          } catch (e: any) {
            if (e.message && e.message !== dataStr) {
              throw e;
            }
          }
        }
      }

      // Finalize assistant message
      this.updateAssistantContent(assistantMessageId, accumulatedText, false);
    } catch (err: any) {
      if (err.name === 'AbortError') {
        // User voluntarily stopped generation; retain partial response
        const curr = this.currentConversation();
        const msg = curr?.messages.find(m => m.id === assistantMessageId);
        const finalContent = msg?.content || '';
        this.updateAssistantContent(assistantMessageId, finalContent, false);
      } else {
        console.error('Error during chat stream:', err);
        const errMsg = err.message || 'Failed to communicate with the chatbot backend.';
        this.errorMessage.set(errMsg);
        this.markAssistantError(assistantMessageId, errMsg);
      }
    } finally {
      this.isGenerating.set(false);
      this.abortController = null;
    }
  }

  public retryLastMessage(): void {
    const conversation = this.currentConversation();
    if (!conversation || conversation.messages.length === 0) return;

    // Find the last user message
    const msgs = [...conversation.messages];
    const lastMsg = msgs[msgs.length - 1];

    let userPrompt = '';
    if (lastMsg.role === 'assistant') {
      // Remove failed assistant message
      msgs.pop();
      const prevMsg = msgs[msgs.length - 1];
      if (prevMsg && prevMsg.role === 'user') {
        userPrompt = prevMsg.content;
        msgs.pop(); // Remove user message to re-send
      }
    } else if (lastMsg.role === 'user') {
      userPrompt = lastMsg.content;
      msgs.pop();
    }

    if (userPrompt) {
      const cleanedConv: Conversation = {
        ...conversation,
        messages: msgs
      };
      this.storageService.upsertConversation(cleanedConv);
      this.sendMessage(userPrompt);
    }
  }

  private updateAssistantContent(messageId: string, content: string, isStreaming: boolean): void {
    const conversation = this.currentConversation();
    if (!conversation) return;

    const updatedMessages = conversation.messages.map(m => {
      if (m.id === messageId) {
        return {
          ...m,
          content,
          isStreaming
        };
      }
      return m;
    });

    const updatedConversation: Conversation = {
      ...conversation,
      updatedAt: Date.now(),
      messages: updatedMessages
    };

    this.storageService.upsertConversation(updatedConversation);
  }

  private markAssistantError(messageId: string, errorDetail: string): void {
    const conversation = this.currentConversation();
    if (!conversation) return;

    const updatedMessages = conversation.messages.map(m => {
      if (m.id === messageId) {
        return {
          ...m,
          content: m.content || `An error occurred: ${errorDetail}`,
          isStreaming: false,
          error: true
        };
      }
      return m;
    });

    const updatedConversation: Conversation = {
      ...conversation,
      updatedAt: Date.now(),
      messages: updatedMessages
    };

    this.storageService.upsertConversation(updatedConversation);
  }
}
