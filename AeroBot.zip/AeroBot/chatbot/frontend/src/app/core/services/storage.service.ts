import { Injectable, signal } from '@angular/core';
import { Conversation } from '../models/conversation.model';

const STORAGE_KEY_CONVERSATIONS = 'claude_conversations';
const STORAGE_KEY_THEME = 'claude_theme';

@Injectable({
  providedIn: 'root'
})
export class StorageService {
  readonly conversations = signal<Conversation[]>([]);
  readonly theme = signal<'light' | 'dark'>('light');

  constructor() {
    this.initTheme();
    this.loadConversations();
  }

  private initTheme(): void {
    try {
      const savedTheme = localStorage.getItem(STORAGE_KEY_THEME) as 'light' | 'dark' | null;
      const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      const initialTheme = savedTheme || (prefersDark ? 'dark' : 'light');
      this.setTheme(initialTheme);
    } catch {
      this.setTheme('light');
    }
  }

  public setTheme(theme: 'light' | 'dark'): void {
    this.theme.set(theme);
    try {
      localStorage.setItem(STORAGE_KEY_THEME, theme);
    } catch {
      // LocalStorage might be disabled or full
    }
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }

  public toggleTheme(): void {
    const next = this.theme() === 'dark' ? 'light' : 'dark';
    this.setTheme(next);
  }

  public loadConversations(): Conversation[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_CONVERSATIONS);
      if (raw) {
        const parsed = JSON.parse(raw) as Conversation[];
        if (Array.isArray(parsed)) {
          this.conversations.set(parsed);
          return parsed;
        }
      }
    } catch (e) {
      console.error('Failed to load conversations from localStorage', e);
    }
    this.conversations.set([]);
    return [];
  }

  public saveConversations(conversations: Conversation[]): void {
    this.conversations.set(conversations);
    try {
      localStorage.setItem(STORAGE_KEY_CONVERSATIONS, JSON.stringify(conversations));
    } catch (e) {
      console.error('Failed to persist conversations in localStorage', e);
    }
  }

  public upsertConversation(conversation: Conversation): void {
    const list = this.conversations();
    const index = list.findIndex(c => c.id === conversation.id);
    let updated: Conversation[];
    if (index >= 0) {
      updated = [...list];
      updated[index] = conversation;
    } else {
      updated = [conversation, ...list];
    }
    // Sort with most recent updated first
    updated.sort((a, b) => b.updatedAt - a.updatedAt);
    this.saveConversations(updated);
  }

  public removeConversation(id: string): void {
    const updated = this.conversations().filter(c => c.id !== id);
    this.saveConversations(updated);
  }

  public clearAllConversations(): void {
    this.saveConversations([]);
  }
}
