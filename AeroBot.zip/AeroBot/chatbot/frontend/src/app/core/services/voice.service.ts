import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class VoiceService {
  readonly isListening = signal<boolean>(false);
  readonly isSpeaking = signal<boolean>(false);
  readonly speakingMessageId = signal<string | null>(null);
  readonly isRecognitionSupported = signal<boolean>(false);
  readonly isSynthesisSupported = signal<boolean>(false);

  private recognition: any = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;

  constructor() {
    this.checkSupport();
  }

  private checkSupport(): void {
    if (typeof window !== 'undefined') {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      this.isRecognitionSupported.set(!!SpeechRecognition);
      this.isSynthesisSupported.set('speechSynthesis' in window);
    }
  }

  public startListening(
    onResult: (text: string, isFinal: boolean) => void,
    onError?: (error: string) => void
  ): void {
    if (typeof window === 'undefined') return;

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      if (onError) onError('Speech recognition is not supported in this browser.');
      return;
    }

    try {
      if (this.recognition) {
        this.recognition.abort();
      }

      this.recognition = new SpeechRecognition();
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.lang = navigator.language || 'en-US';

      this.recognition.onstart = () => {
        this.isListening.set(true);
      };

      this.recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }

        const combined = final || interim;
        if (combined) {
          onResult(combined, !!final);
        }
      };

      this.recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        this.isListening.set(false);
        if (onError && event.error !== 'no-speech' && event.error !== 'aborted') {
          onError(`Microphone error: ${event.error}`);
        }
      };

      this.recognition.onend = () => {
        this.isListening.set(false);
      };

      this.recognition.start();
    } catch (err: any) {
      this.isListening.set(false);
      console.error('Failed to start speech recognition:', err);
      if (onError) onError(err.message || 'Unable to access microphone.');
    }
  }

  public stopListening(): void {
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch {
        // Ignored if already stopped
      }
      this.isListening.set(false);
    }
  }

  public toggleListening(
    onResult: (text: string, isFinal: boolean) => void,
    onError?: (error: string) => void
  ): void {
    if (this.isListening()) {
      this.stopListening();
    } else {
      this.startListening(onResult, onError);
    }
  }

  public speak(text: string, messageId: string): void {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    // If already speaking this message, toggle pause/stop
    if (this.isSpeaking() && this.speakingMessageId() === messageId) {
      this.stopSpeaking();
      return;
    }

    this.stopSpeaking();

    // Clean markdown syntax for natural speech
    const cleanText = text
      .replace(/```[\s\S]*?```/g, ' [code snippet omitted] ')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      .replace(/[#*_~>]/g, '')
      .replace(/\n+/g, ' ')
      .trim();

    if (!cleanText) return;

    this.currentUtterance = new SpeechSynthesisUtterance(cleanText);
    this.currentUtterance.rate = 1.0;
    this.currentUtterance.pitch = 1.0;

    this.currentUtterance.onstart = () => {
      this.isSpeaking.set(true);
      this.speakingMessageId.set(messageId);
    };

    this.currentUtterance.onend = () => {
      this.isSpeaking.set(false);
      this.speakingMessageId.set(null);
    };

    this.currentUtterance.onerror = (e) => {
      if (e.error !== 'interrupted' && e.error !== 'canceled') {
        console.warn('Speech synthesis error:', e);
      }
      this.isSpeaking.set(false);
      this.speakingMessageId.set(null);
    };

    window.speechSynthesis.speak(this.currentUtterance);
  }

  public stopSpeaking(): void {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    this.isSpeaking.set(false);
    this.speakingMessageId.set(null);
  }
}
