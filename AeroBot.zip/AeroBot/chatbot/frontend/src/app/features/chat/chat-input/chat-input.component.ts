import { Component, ElementRef, ViewChild, inject, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VoiceService } from '../../../core/services/voice.service';

@Component({
  selector: 'app-chat-input',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="w-full relative">
      <!-- Live Voice Listening Banner -->
      @if (voiceService.isListening()) {
        <div class="absolute -top-10 left-0 right-0 flex items-center justify-center pointer-events-none z-10">
          <div class="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-claude-accent text-white text-xs font-medium shadow-md">
            <span class="flex h-2 w-2 relative">
              <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
              <span class="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
            </span>
            <span>Listening... speak clearly</span>
          </div>
        </div>
      }

      <div
        class="relative flex flex-col w-full rounded-2xl bg-white dark:bg-[#252320] border transition-all duration-150 p-2 sm:p-2.5 shadow-xs"
        [ngClass]="voiceService.isListening()
          ? 'border-claude-accent ring-2 ring-claude-accent/30'
          : 'border-claude-border dark:border-claude-borderDark focus-within:border-claude-accent/60 focus-within:ring-2 focus-within:ring-claude-accent/20'"
      >
        <!-- Auto-growing Textarea -->
        <textarea
          #textareaRef
          [(ngModel)]="textValue"
          (input)="adjustHeight()"
          (keydown)="onKeydown($event)"
          rows="1"
          placeholder="Message AeroGPT, or use voice command..."
          class="w-full resize-none border-0 bg-transparent py-1 px-2 text-base sm:text-[0.95rem]
                 text-claude-text dark:text-claude-textDark
                 placeholder-claude-muted/60 dark:placeholder-claude-mutedDark/60
                 focus:outline-none focus:ring-0 max-h-48 leading-relaxed"
          aria-label="Message prompt input"
        ></textarea>

        <!-- Bottom bar of the input box: helpers + Action buttons -->
        <div class="flex items-center justify-between pt-1 px-1">
          <!-- Left helper hints & clear button -->
          <div class="flex items-center gap-2">
            @if (hasContent()) {
              <button
                type="button"
                (click)="clearText()"
                class="inline-flex items-center gap-1 text-[11px] text-claude-muted hover:text-claude-text dark:hover:text-claude-textDark transition-colors px-1 py-0.5 rounded cursor-pointer"
                title="Clear input"
              >
                <svg xmlns="http://www.w3.org/2000/svg" class="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                  <line x1="18" y1="6" x2="6" y2="18"></line>
                  <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
                <span>Clear</span>
              </button>
            }

            <span class="text-[11px] text-claude-muted/70 dark:text-claude-mutedDark/70 hidden sm:inline select-none">
              Press <kbd class="px-1 py-0.5 rounded bg-black/5 dark:bg-white/10 text-[10px] font-mono">Enter</kbd> to send, <kbd class="px-1 py-0.5 rounded bg-black/5 dark:bg-white/10 text-[10px] font-mono">Shift+Enter</kbd> for newline
            </span>
          </div>

          <!-- Right Action Buttons (Voice Command, Stop, Send) -->
          <div class="flex items-center gap-1.5 shrink-0">
            <!-- Voice Command Microphone Button -->
            @if (voiceService.isRecognitionSupported()) {
              <button
                type="button"
                (click)="toggleVoice()"
                [ngClass]="voiceService.isListening()
                  ? 'bg-claude-accent text-white animate-pulse'
                  : 'text-claude-muted dark:text-claude-mutedDark hover:text-claude-accent hover:bg-black/5 dark:hover:bg-white/5'"
                class="p-2 min-h-[42px] min-w-[42px] rounded-xl flex items-center justify-center
                       transition-all duration-150 focus:outline-none focus:ring-2 focus:ring-claude-accent/30 cursor-pointer"
                [attr.aria-label]="voiceService.isListening() ? 'Stop voice recognition' : 'Start voice recognition'"
                [title]="voiceService.isListening() ? 'Listening... click to stop' : 'Voice command (Click to speak)'"
              >
                <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/>
                  <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
                  <line x1="12" y1="19" x2="12" y2="22"/>
                </svg>
              </button>
            }

            <!-- Stop Generating Button (during streaming) -->
            @if (isGenerating()) {
              <button
                type="button"
                (click)="generationStopped.emit()"
                class="inline-flex items-center gap-1.5 px-3 py-1.5 min-h-[42px] rounded-xl
                       bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400
                       border border-rose-200 dark:border-rose-900/50
                       hover:bg-rose-100 dark:hover:bg-rose-900/60
                       transition-colors duration-150 font-medium text-xs focus:outline-none focus:ring-2 focus:ring-rose-400 cursor-pointer"
                aria-label="Stop generating response"
              >
                <div class="w-2.5 h-2.5 rounded-xs bg-rose-600 dark:bg-rose-400"></div>
                <span>Stop</span>
              </button>
            } @else {
              <!-- Send Button -->
              <button
                type="button"
                (click)="submit()"
                [disabled]="!hasContent()"
                [ngClass]="hasContent()
                  ? 'bg-gradient-to-r from-claude-accent to-claude-accentHover text-white shadow-xs hover:shadow-sm cursor-pointer'
                  : 'bg-black/5 dark:bg-white/5 text-claude-muted/40 cursor-not-allowed'"
                class="p-2 min-h-[42px] min-w-[42px] rounded-xl flex items-center justify-center
                       transition-all duration-150 focus:outline-none focus:ring-2 focus:ring-claude-accent/40"
                aria-label="Send message"
              >
                <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                  <line x1="12" y1="19" x2="12" y2="5"></line>
                  <polyline points="5 12 12 5 19 12"></polyline>
                </svg>
              </button>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class ChatInputComponent {
  readonly isGenerating = input<boolean>(false);
  readonly messageSent = output<string>();
  readonly generationStopped = output<void>();

  readonly voiceService = inject(VoiceService);

  @ViewChild('textareaRef') textareaRef?: ElementRef<HTMLTextAreaElement>;

  textValue = '';

  public hasContent(): boolean {
    return this.textValue.trim().length > 0;
  }

  public clearText(): void {
    this.textValue = '';
    if (this.textareaRef) {
      this.textareaRef.nativeElement.style.height = 'auto';
      this.textareaRef.nativeElement.focus();
    }
  }

  public setContent(text: string): void {
    this.textValue = text;
    setTimeout(() => {
      this.adjustHeight();
      this.textareaRef?.nativeElement.focus();
    }, 20);
  }

  public adjustHeight(): void {
    if (!this.textareaRef) return;
    const el = this.textareaRef.nativeElement;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 180)}px`;
  }

  public onKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.submit();
    }
  }

  public toggleVoice(): void {
    if (this.voiceService.isListening()) {
      this.voiceService.stopListening();
    } else {
      this.voiceService.startListening((transcript, isFinal) => {
        if (this.textValue.trim()) {
          this.textValue = `${this.textValue} ${transcript}`.trim();
        } else {
          this.textValue = transcript;
        }
        this.adjustHeight();

        if (isFinal && (transcript.toLowerCase().trim() === 'send' || transcript.toLowerCase().trim() === 'send message')) {
          this.textValue = this.textValue.replace(/\b(send|send message)\b/gi, '').trim();
          this.voiceService.stopListening();
          if (this.hasContent()) {
            this.submit();
          }
        }
      });
    }
  }

  public submit(): void {
    const trimmed = this.textValue.trim();
    if (!trimmed || this.isGenerating()) return;

    if (this.voiceService.isListening()) {
      this.voiceService.stopListening();
    }

    this.messageSent.emit(trimmed);
    this.textValue = '';

    if (this.textareaRef) {
      this.textareaRef.nativeElement.style.height = 'auto';
    }
  }
}
