import { Component, ViewChild, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChatService } from '../../../core/services/chat.service';
import { WelcomeScreenComponent } from '../welcome-screen/welcome-screen.component';
import { MessageListComponent } from '../message-list/message-list.component';
import { ChatInputComponent } from '../chat-input/chat-input.component';

@Component({
  selector: 'app-chat-window',
  standalone: true,
  imports: [CommonModule, WelcomeScreenComponent, MessageListComponent, ChatInputComponent],
  host: {
    'class': 'flex-1 flex flex-col min-h-0 overflow-hidden w-full relative'
  },
  template: `
    <main class="flex-1 flex flex-col min-h-0 overflow-hidden w-full relative" role="main">
      <!-- Main Content Area: Welcome Screen or Message List -->
      <div class="flex-1 flex flex-col min-h-0 overflow-hidden w-full">
        @if (!hasMessages()) {
          <app-welcome-screen
            (suggestionSelected)="onSuggestionSelected($event)"
          ></app-welcome-screen>
        } @else {
          <app-message-list
            [messages]="currentMessages()"
            [isGenerating]="chatService.isGenerating()"
            (retry)="onRetry()"
          ></app-message-list>
        }
      </div>

      <!-- Bottom Pinned Input Area: Responsive with safe-area spacing -->
      <div class="shrink-0 w-full px-3 sm:px-6 pb-2 sm:pb-3.5 pt-1.5 bg-gradient-to-t from-claude-bg via-claude-bg to-transparent dark:from-claude-bgDark dark:via-claude-bgDark z-20">
        <div class="max-w-3xl mx-auto w-full flex flex-col items-center">
          <app-chat-input
            #chatInput
            [isGenerating]="chatService.isGenerating()"
            (messageSent)="onSendMessage($event)"
            (generationStopped)="onStopGeneration()"
          ></app-chat-input>

          <p class="mt-1.5 text-[11px] text-claude-muted/70 dark:text-claude-mutedDark/70 text-center select-none px-2">
            AeroGPT is a local AI assistant. Please verify important information.
          </p>
        </div>
      </div>
    </main>
  `
})
export class ChatWindowComponent {
  readonly chatService = inject(ChatService);

  @ViewChild('chatInput') chatInput?: ChatInputComponent;

  public hasMessages(): boolean {
    const active = this.chatService.currentConversation();
    return !!active && active.messages.length > 0;
  }

  public currentMessages() {
    return this.chatService.currentConversation()?.messages || [];
  }

  public onSuggestionSelected(prompt: string): void {
    this.chatInput?.setContent(prompt);
  }

  public onSendMessage(content: string): void {
    this.chatService.sendMessage(content);
  }

  public onStopGeneration(): void {
    this.chatService.stopGenerating();
  }

  public onRetry(): void {
    this.chatService.retryLastMessage();
  }
}
