import { Component, HostListener, inject, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChatMessage } from '../../../core/models/message.model';
import { MarkdownPipe } from '../../../shared/markdown.pipe';
import { CopyButtonComponent } from '../../../shared/copy-button/copy-button.component';
import { VoiceService } from '../../../core/services/voice.service';

@Component({
  selector: 'app-message-bubble',
  standalone: true,
  imports: [CommonModule, MarkdownPipe, CopyButtonComponent],
  template: `
    @if (message().role === 'user') {
      <!-- User Message: Soft rounded bubble aligned right with timestamp -->
      <div class="flex flex-col items-end w-full group">
        <div class="max-w-[88%] sm:max-w-[78%] rounded-2xl rounded-br-xs px-4 sm:px-5 py-2.5 sm:py-3.5
                    bg-claude-bubble dark:bg-claude-bubbleDark
                    text-claude-text dark:text-claude-textDark
                    border border-claude-border/40 dark:border-claude-borderDark/40
                    shadow-xs text-sm sm:text-[0.95rem] leading-relaxed whitespace-pre-wrap break-words">
          {{ message().content }}
        </div>
        <span class="text-[10px] text-claude-muted/60 dark:text-claude-mutedDark/60 mt-1 mr-1.5 select-none opacity-0 group-hover:opacity-100 transition-opacity">
          {{ formatTime(message().timestamp) }}
        </span>
      </div>
    } @else {
      <!-- Assistant Message: Natural flowing markdown with AeroGPT delta avatar -->
      <div class="flex items-start gap-2.5 sm:gap-3.5 w-full min-w-0 group">
        <!-- AeroGPT Avatar Icon -->
        <div class="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-gradient-to-br from-claude-accent to-claude-accentHover flex items-center justify-center text-white shrink-0 mt-0.5 shadow-xs">
          <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 sm:w-4.5 sm:h-4.5" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2L1 21h4.5l6.5-6 6.5 6H23L12 2zm0 4.8l4.8 11.2-4.8-4.4-4.8 4.4L12 6.8z"/>
          </svg>
        </div>

        <!-- Content Body -->
        <div class="flex-1 min-w-0 overflow-hidden">
          <!-- Header with Model & Time -->
          <div class="flex items-center gap-2 mb-1 select-none">
            <span class="text-xs font-semibold text-claude-text dark:text-claude-textDark">AeroGPT</span>
            <span class="text-[10px] text-claude-muted/60 dark:text-claude-mutedDark/60">
              {{ formatTime(message().timestamp) }}
            </span>
          </div>

          <!-- Text / Markdown -->
          @if (message().content) {
            <div
              class="markdown-body text-claude-text dark:text-claude-textDark text-sm sm:text-[0.95rem] leading-relaxed break-words"
              [innerHTML]="message().content | markdown"
            ></div>
          }

          <!-- Typing Indicator when streaming with no text yet -->
          @if (message().isStreaming && !message().content) {
            <div class="flex items-center gap-1.5 py-2.5 px-1 text-claude-accent" aria-label="AeroGPT is computing...">
              <span class="typing-dot"></span>
              <span class="typing-dot"></span>
              <span class="typing-dot"></span>
            </div>
          }

          <!-- In-progress streaming cursor -->
          @if (message().isStreaming && message().content) {
            <span class="inline-block w-2 h-4 ml-0.5 bg-claude-accent/70 animate-pulse align-middle" aria-hidden="true"></span>
          }

          <!-- Error Alert with Retry button -->
          @if (message().error) {
            <div class="mt-3 p-3.5 rounded-xl border border-rose-200 dark:border-rose-900/40 bg-rose-50/70 dark:bg-rose-950/20 text-rose-800 dark:text-rose-300 text-xs flex flex-wrap items-center justify-between gap-2.5">
              <div class="flex items-center gap-2 min-w-0 flex-1">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 shrink-0 text-rose-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
                </svg>
                <span class="break-words">{{ message().content }}</span>
              </div>
              <button
                type="button"
                (click)="retry.emit()"
                class="inline-flex items-center gap-1.5 px-3 py-1.5 min-h-[40px] rounded-lg font-medium text-xs bg-rose-600 hover:bg-rose-700 text-white transition-colors focus:outline-none focus:ring-2 focus:ring-rose-400 shrink-0 cursor-pointer"
                aria-label="Retry generation"
              >
                <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15 6.7L3 16"/><path d="M3 21v-5h5"/>
                </svg>
                <span>Retry</span>
              </button>
            </div>
          }

          <!-- User-friendly Action Toolbar: Copy, Voice Read Aloud, Retry -->
          @if (!message().isStreaming && message().content && !message().error) {
            <div class="mt-2.5 flex items-center gap-1.5 opacity-80 group-hover:opacity-100 transition-opacity select-none">
              <!-- Copy full response button -->
              <app-copy-button
                [text]="message().content"
                ariaLabel="Copy full response"
                [showText]="true"
              ></app-copy-button>

              <!-- Voice Read Aloud Button -->
              @if (voiceService.isSynthesisSupported()) {
                <button
                  type="button"
                  (click)="toggleSpeak()"
                  class="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md
                         text-claude-muted dark:text-claude-mutedDark
                         hover:text-claude-text dark:hover:text-claude-textDark
                         hover:bg-black/5 dark:hover:bg-white/5
                         transition-colors duration-150 min-h-[32px] cursor-pointer"
                  [class.text-claude-accent]="isSpeakingThis()"
                  [class.font-semibold]="isSpeakingThis()"
                  [attr.aria-label]="isSpeakingThis() ? 'Stop reading' : 'Read aloud'"
                  [title]="isSpeakingThis() ? 'Stop speaking' : 'Read aloud with local voice'"
                >
                  @if (isSpeakingThis()) {
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5 text-claude-accent animate-pulse" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                      <rect width="4" height="16" x="6" y="4"/>
                      <rect width="4" height="16" x="14" y="4"/>
                    </svg>
                    <span class="text-claude-accent text-[11px]">Stop audio</span>
                  } @else {
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
                      <path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>
                      <path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>
                    </svg>
                    <span class="text-[11px]">Read</span>
                  }
                </button>
              }

              <!-- Retry / Regenerate button -->
              <button
                type="button"
                (click)="retry.emit()"
                class="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md
                       text-claude-muted dark:text-claude-mutedDark
                       hover:text-claude-text dark:hover:text-claude-textDark
                       hover:bg-black/5 dark:hover:bg-white/5
                       transition-colors duration-150 min-h-[32px] cursor-pointer"
                aria-label="Regenerate response"
                title="Regenerate response"
              >
                <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15 6.7L3 16"/><path d="M3 21v-5h5"/>
                </svg>
                <span class="text-[11px]">Retry</span>
              </button>
            </div>
          }
        </div>
      </div>
    }
  `
})
export class MessageBubbleComponent {
  readonly message = input.required<ChatMessage>();
  readonly retry = output<void>();

  readonly voiceService = inject(VoiceService);

  public formatTime(timestamp: number): string {
    if (!timestamp) return '';
    return new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  public isSpeakingThis(): boolean {
    return this.voiceService.isSpeaking() && this.voiceService.speakingMessageId() === this.message().id;
  }

  public toggleSpeak(): void {
    this.voiceService.speak(this.message().content, this.message().id);
  }

  // Intercept click on code block copy buttons generated by MarkdownPipe
  @HostListener('click', ['$event'])
  onHostClick(event: MouseEvent): void {
    const target = (event.target as HTMLElement).closest('.code-copy-btn') as HTMLButtonElement | null;
    if (!target) return;

    event.preventDefault();
    event.stopPropagation();

    const rawCode = target.getAttribute('data-code');
    if (!rawCode) return;

    const decoded = decodeURIComponent(rawCode);
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(decoded).then(() => this.indicateCodeCopied(target));
    } else {
      const textarea = document.createElement('textarea');
      textarea.value = decoded;
      textarea.style.position = 'fixed';
      textarea.style.left = '-999999px';
      document.body.appendChild(textarea);
      textarea.focus();
      textarea.select();
      document.execCommand('copy');
      textarea.remove();
      this.indicateCodeCopied(target);
    }
  }

  private indicateCodeCopied(button: HTMLButtonElement): void {
    const originalHtml = button.innerHTML;
    button.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="text-emerald-400"><polyline points="20 6 9 17 4 12"/></svg>
      <span class="text-emerald-400">Copied!</span>
    `;
    button.style.backgroundColor = 'rgba(16, 185, 129, 0.2)';

    setTimeout(() => {
      button.innerHTML = originalHtml;
      button.style.backgroundColor = '';
    }, 2000);
  }
}
