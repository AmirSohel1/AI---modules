import { AfterViewChecked, Component, ElementRef, ViewChild, input, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChatMessage } from '../../../core/models/message.model';
import { MessageBubbleComponent } from '../message-bubble/message-bubble.component';

@Component({
  selector: 'app-message-list',
  standalone: true,
  imports: [CommonModule, MessageBubbleComponent],
  host: {
    'class': 'flex-1 flex flex-col min-h-0 w-full overflow-hidden relative'
  },
  template: `
    <div
      #scrollContainer
      (scroll)="onScroll()"
      class="flex-1 overflow-y-auto px-3 sm:px-6 py-4 sm:py-6 space-y-4 sm:space-y-6 w-full max-w-3xl mx-auto min-h-0 relative"
      aria-label="Conversation messages"
    >
      @for (message of messages(); track message.id) {
        <app-message-bubble
          [message]="message"
          (retry)="retry.emit()"
        ></app-message-bubble>
      }

      <!-- Floating Scroll-to-Bottom button when user has scrolled up -->
      @if (userScrolledUp()) {
        <div class="sticky bottom-2 flex justify-center w-full pointer-events-none z-10">
          <button
            type="button"
            (click)="scrollToBottom(true)"
            class="pointer-events-auto flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] rounded-full
                   bg-white dark:bg-[#2A2825] text-claude-text dark:text-claude-textDark
                   border border-claude-border dark:border-claude-borderDark
                   shadow-md hover:shadow-lg transition-all duration-150 text-xs font-medium cursor-pointer"
            aria-label="Scroll to newest message"
          >
            <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-claude-accent animate-bounce" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <line x1="12" y1="5" x2="12" y2="19"></line>
              <polyline points="19 12 12 19 5 12"></polyline>
            </svg>
            <span>New messages below</span>
          </button>
        </div>
      }
    </div>
  `
})
export class MessageListComponent implements AfterViewChecked {
  readonly messages = input<ChatMessage[]>([]);
  readonly isGenerating = input<boolean>(false);
  readonly retry = output<void>();

  @ViewChild('scrollContainer') private scrollContainer?: ElementRef<HTMLDivElement>;

  readonly userScrolledUp = signal<boolean>(false);
  private shouldScrollToBottom = true;

  ngAfterViewChecked(): void {
    if (this.shouldScrollToBottom && !this.userScrolledUp()) {
      this.scrollToBottom(false);
    }
  }

  public onScroll(): void {
    if (!this.scrollContainer) return;
    const el = this.scrollContainer.nativeElement;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;

    if (distanceFromBottom > 140) {
      this.userScrolledUp.set(true);
      this.shouldScrollToBottom = false;
    } else {
      this.userScrolledUp.set(false);
      this.shouldScrollToBottom = true;
    }
  }

  public scrollToBottom(smooth = false): void {
    if (!this.scrollContainer) return;
    const el = this.scrollContainer.nativeElement;
    if (smooth) {
      el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
    } else {
      el.scrollTop = el.scrollHeight;
    }
    this.userScrolledUp.set(false);
    this.shouldScrollToBottom = true;
  }
}
