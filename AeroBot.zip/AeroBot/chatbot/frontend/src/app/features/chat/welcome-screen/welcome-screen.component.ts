import { Component, output } from '@angular/core';
import { CommonModule } from '@angular/common';

interface SuggestionCard {
  title: string;
  description: string;
  prompt: string;
  category: string;
  icon: string;
}

@Component({
  selector: 'app-welcome-screen',
  standalone: true,
  imports: [CommonModule],
  host: {
    'class': 'flex-1 flex flex-col min-h-0 overflow-y-auto w-full'
  },
  template: `
    <div class="my-auto flex flex-col items-center justify-center px-4 py-6 sm:py-8 max-w-2xl mx-auto w-full text-center">
      <!-- AeroGPT Hero Logo and Title -->
      <div class="mb-5 sm:mb-6 flex flex-col items-center">
        <!-- Supersonic Aero Delta Logo -->
        <div class="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-br from-claude-accent via-claude-accent to-claude-accentHover flex items-center justify-center text-white mb-4 sm:mb-5 shadow-lg shadow-claude-accent/20 ring-4 ring-claude-accent/15">
          <svg xmlns="http://www.w3.org/2000/svg" class="w-9 h-9 sm:w-11 sm:h-11 drop-shadow-md" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2L1 21h4.5l6.5-6 6.5 6H23L12 2zm0 4.8l4.8 11.2-4.8-4.4-4.8 4.4L12 6.8z"/>
          </svg>
        </div>

        <h1 class="font-serif text-2xl sm:text-4xl font-semibold tracking-tight text-claude-text dark:text-claude-textDark mb-2 sm:mb-2.5">
          {{ greeting }}, how can AeroGPT help?
        </h1>
        <p class="text-xs sm:text-sm text-claude-muted dark:text-claude-mutedDark max-w-md px-2 leading-relaxed">
          Your private, high-performance local AI. Fast reasoning, code generation, analysis, and speech interaction.
        </p>

        <!-- Feature Capabilities Badges -->
        <div class="flex flex-wrap items-center justify-center gap-1.5 sm:gap-2 mt-4 select-none">
          <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-medium bg-claude-accent/10 text-claude-accent border border-claude-accent/20">
            <span>🎙️</span>
            <span>Voice Ready</span>
          </span>
          <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-medium bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
            <span>⚡</span>
            <span>Live Streaming</span>
          </span>
          <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-medium bg-sky-500/10 text-sky-600 dark:text-sky-400 border border-sky-500/20">
            <span>🔒</span>
            <span>100% Private</span>
          </span>
        </div>
      </div>

      <!-- 4 Clickable Suggestion Cards -->
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3 w-full text-left">
        @for (card of suggestions; track card.title) {
          <button
            type="button"
            (click)="suggestionSelected.emit(card.prompt)"
            class="group p-3.5 sm:p-4 rounded-xl border border-claude-border dark:border-claude-borderDark
                   bg-white dark:bg-[#252320] hover:border-claude-accent/60 dark:hover:border-claude-accentDark/60
                   hover:shadow-md transition-all duration-150 focus:outline-none focus:ring-2 focus:ring-claude-accent/30
                   flex flex-col justify-between min-h-[84px] sm:min-h-[96px] cursor-pointer"
            [attr.aria-label]="card.title"
          >
            <div>
              <div class="flex items-center justify-between mb-1">
                <span class="text-[10px] sm:text-[11px] font-semibold tracking-wider uppercase text-claude-accent dark:text-claude-accentDark">
                  {{ card.category }}
                </span>
                <span class="text-sm opacity-70 group-hover:opacity-100 transition-opacity">{{ card.icon }}</span>
              </div>
              <h2 class="text-xs sm:text-sm font-medium text-claude-text dark:text-claude-textDark group-hover:text-claude-accent transition-colors leading-snug">
                {{ card.title }}
              </h2>
            </div>
            <p class="text-[11px] sm:text-xs text-claude-muted dark:text-claude-mutedDark line-clamp-1 mt-1.5 sm:mt-2">
              {{ card.description }}
            </p>
          </button>
        }
      </div>
    </div>
  `
})
export class WelcomeScreenComponent {
  readonly suggestionSelected = output<string>();

  readonly greeting: string = this.computeGreeting();

  readonly suggestions: SuggestionCard[] = [
    {
      category: 'Science & Concept',
      icon: '⚛️',
      title: 'Explain quantum computing simply',
      description: 'Using intuitive everyday analogies',
      prompt: 'Explain quantum computing in simple everyday analogies for someone with no physics background.'
    },
    {
      category: 'Coding & Scripts',
      icon: '🐍',
      title: 'Python CSV parser & analyzer',
      description: 'Parse, summarize, and format metrics',
      prompt: 'Write a clean Python script using standard libraries to parse a CSV file, calculate column statistics, and output a formatted table.'
    },
    {
      category: 'Writing & Email',
      icon: '✍️',
      title: 'Draft a polite follow-up email',
      description: 'Concise tone seeking project feedback',
      prompt: 'Draft a warm, concise, and professional email to follow up on a project proposal with our engineering team.'
    },
    {
      category: 'System Architecture',
      icon: '🏗️',
      title: 'REST vs GraphQL vs gRPC',
      description: 'Tradeoffs and comparison table',
      prompt: 'Compare REST, GraphQL, and gRPC with key pros, cons, performance tradeoffs, and a clear comparison table.'
    }
  ];

  private computeGreeting(): string {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  }
}
