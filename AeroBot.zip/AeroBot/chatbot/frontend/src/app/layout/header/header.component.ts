import { Component, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChatService } from '../../core/services/chat.service';
import { StorageService } from '../../core/services/storage.service';
import { VoiceService } from '../../core/services/voice.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  template: `
    <header class="h-14 border-b border-claude-border/80 dark:border-claude-borderDark/80
                   bg-claude-bg/85 dark:bg-claude-bgDark/85 backdrop-blur-md
                   px-3 sm:px-4 flex items-center justify-between shrink-0 sticky top-0 z-30 w-full select-none">
      <div class="flex items-center gap-2 sm:gap-3 min-w-0">
        <!-- Hamburger Menu Button (Mobile / Tablet) -->
        <button
          type="button"
          (click)="toggleSidebar.emit()"
          class="lg:hidden p-2 min-h-[44px] min-w-[44px] rounded-xl text-claude-muted dark:text-claude-mutedDark hover:text-claude-text dark:hover:text-claude-textDark hover:bg-black/5 dark:hover:bg-white/5 transition-colors focus:outline-none focus:ring-2 focus:ring-claude-accent/30 flex items-center justify-center shrink-0 cursor-pointer"
          aria-label="Open conversation sidebar"
        >
          <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="3" y1="12" x2="21" y2="12"></line>
            <line x1="3" y1="6" x2="21" y2="6"></line>
            <line x1="3" y1="18" x2="21" y2="18"></line>
          </svg>
        </button>

        <!-- AeroGPT Title & Status -->
        <div class="flex items-center gap-2 min-w-0">
          <div class="w-6 h-6 rounded-md bg-claude-accent flex items-center justify-center text-white shrink-0 sm:hidden">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2L1 21h4.5l6.5-6 6.5 6H23L12 2zm0 4.8l4.8 11.2-4.8-4.4-4.8 4.4L12 6.8z"/>
            </svg>
          </div>
          <span class="font-medium text-sm text-claude-text dark:text-claude-textDark truncate max-w-[130px] xs:max-w-[200px] sm:max-w-xs md:max-w-md">
            {{ chatTitle() }}
          </span>
          <span class="hidden xs:inline-block px-2 py-0.5 text-[10px] rounded-full bg-claude-accent/15 text-claude-accent font-semibold tracking-wide shrink-0">
            AeroGPT
          </span>
        </div>
      </div>

      <!-- Right Action Tools -->
      <div class="flex items-center gap-1 shrink-0">
        <!-- Voice Speaking Indicator / Quick Stop Audio -->
        @if (voiceService.isSpeaking()) {
          <button
            type="button"
            (click)="voiceService.stopSpeaking()"
            class="flex items-center gap-1.5 px-2.5 py-1 min-h-[36px] rounded-lg bg-claude-accent/15 text-claude-accent hover:bg-claude-accent/25 transition-colors text-xs font-medium cursor-pointer"
            title="Stop audio playback"
          >
            <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5 animate-pulse" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
              <path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>
            </svg>
            <span class="hidden sm:inline">Speaking</span>
            <span class="text-[10px] opacity-75">✕</span>
          </button>
        }

        <!-- Export active chat as Markdown -->
        @if (chatService.currentConversation() && chatService.currentConversation()!.messages.length > 0) {
          <button
            type="button"
            (click)="chatService.exportCurrentChat()"
            class="p-2 min-h-[44px] min-w-[44px] rounded-xl text-claude-muted dark:text-claude-mutedDark hover:text-claude-text dark:hover:text-claude-textDark hover:bg-black/5 dark:hover:bg-white/5 transition-colors focus:outline-none flex items-center justify-center cursor-pointer"
            aria-label="Export conversation"
            title="Export chat as Markdown file"
          >
            <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
          </button>
        }

        <!-- New Chat quick button -->
        <button
          type="button"
          (click)="onNewChat()"
          class="p-2 min-h-[44px] min-w-[44px] rounded-xl text-claude-muted dark:text-claude-mutedDark hover:text-claude-text dark:hover:text-claude-textDark hover:bg-black/5 dark:hover:bg-white/5 transition-colors focus:outline-none flex items-center justify-center cursor-pointer"
          aria-label="New chat"
          title="Start new chat"
        >
          <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-claude-accent" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <line x1="5" y1="12" x2="19" y2="12"></line>
          </svg>
        </button>

        <!-- Theme Toggle -->
        <button
          type="button"
          (click)="storageService.toggleTheme()"
          class="p-2 min-h-[44px] min-w-[44px] rounded-xl text-claude-muted dark:text-claude-mutedDark hover:text-claude-text dark:hover:text-claude-textDark hover:bg-black/5 dark:hover:bg-white/5 transition-colors focus:outline-none flex items-center justify-center cursor-pointer"
          [attr.aria-label]="storageService.theme() === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'"
          title="Toggle light/dark theme"
        >
          @if (storageService.theme() === 'dark') {
            <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-amber-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="5"/>
              <line x1="12" y1="1" x2="12" y2="3"/>
              <line x1="12" y1="21" x2="12" y2="23"/>
              <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/>
              <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
              <line x1="1" y1="12" x2="3" y2="12"/>
              <line x1="21" y1="12" x2="23" y2="12"/>
              <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/>
              <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
            </svg>
          } @else {
            <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-claude-muted" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
            </svg>
          }
        </button>
      </div>
    </header>
  `
})
export class HeaderComponent {
  readonly toggleSidebar = output<void>();
  readonly newChatClicked = output<void>();

  readonly chatService = inject(ChatService);
  readonly storageService = inject(StorageService);
  readonly voiceService = inject(VoiceService);

  public chatTitle(): string {
    const active = this.chatService.currentConversation();
    return active ? active.title : 'AeroGPT';
  }

  public onNewChat(): void {
    this.chatService.startNewChat();
    this.newChatClicked.emit();
  }
}
