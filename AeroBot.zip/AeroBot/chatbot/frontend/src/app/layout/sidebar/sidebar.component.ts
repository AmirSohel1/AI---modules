import { Component, ElementRef, ViewChild, inject, input, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ChatService } from '../../core/services/chat.service';
import { StorageService } from '../../core/services/storage.service';
import { Conversation } from '../../core/models/conversation.model';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <!-- Mobile Backdrop Overlay -->
    @if (isOpen()) {
      <div
        (click)="closeSidebar.emit()"
        class="fixed inset-0 z-40 bg-black/50 backdrop-blur-xs lg:hidden transition-opacity duration-200"
        aria-hidden="true"
      ></div>
    }

    <!-- Sidebar Container -->
    <aside
      [class.translate-x-0]="isOpen()"
      [class.-translate-x-full]="!isOpen()"
      class="fixed inset-y-0 left-0 z-50 w-72 max-w-[85vw] flex flex-col
             bg-claude-sidebar dark:bg-claude-sidebarDark
             border-r border-claude-border dark:border-claude-borderDark
             transition-transform duration-300 ease-in-out
             lg:static lg:translate-x-0 lg:z-auto h-[100dvh] shrink-0 select-none"
      aria-label="AeroGPT conversation sidebar"
    >
      <!-- Top Section: AeroGPT Brand & Actions -->
      <div class="p-3 border-b border-claude-border/60 dark:border-claude-borderDark/60 flex flex-col gap-2.5 shrink-0">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2.5 px-1">
            <!-- AeroGPT Supersonic Delta Logo -->
            <div class="w-7 h-7 rounded-lg bg-gradient-to-br from-claude-accent to-claude-accentHover flex items-center justify-center text-white shadow-xs">
              <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 drop-shadow-xs" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2L1 21h4.5l6.5-6 6.5 6H23L12 2zm0 4.8l4.8 11.2-4.8-4.4-4.8 4.4L12 6.8z"/>
              </svg>
            </div>
            <div class="flex flex-col">
              <span class="font-serif font-bold text-base tracking-tight text-claude-text dark:text-claude-textDark leading-none">
                AeroGPT
              </span>
              <span class="text-[9px] tracking-widest uppercase font-semibold text-claude-accent mt-0.5">
                Local AI Intelligence
              </span>
            </div>
          </div>

          <!-- Close button on mobile -->
          <button
            type="button"
            (click)="closeSidebar.emit()"
            class="lg:hidden p-2 min-h-[44px] min-w-[44px] rounded-lg text-claude-muted dark:text-claude-mutedDark hover:bg-black/5 dark:hover:bg-white/5 focus:outline-none flex items-center justify-center cursor-pointer"
            aria-label="Close sidebar"
          >
            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>

        <!-- New Chat Button -->
        <button
          type="button"
          (click)="onNewChat()"
          class="w-full flex items-center justify-center gap-2 px-4 py-2 min-h-[42px] rounded-xl
                 bg-white dark:bg-[#252320] text-claude-text dark:text-claude-textDark
                 border border-claude-border dark:border-claude-borderDark
                 hover:border-claude-accent/40 dark:hover:border-claude-accentDark/40
                 shadow-xs hover:shadow-sm
                 transition-all duration-150 font-medium text-sm focus:outline-none focus:ring-2 focus:ring-claude-accent/30 cursor-pointer"
          aria-label="Start a new chat"
        >
          <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-claude-accent" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <line x1="5" y1="12" x2="19" y2="12"></line>
          </svg>
          <span>Start new chat</span>
        </button>

        <!-- Search Bar for Past Conversations -->
        @if (chatService.conversations().length > 2) {
          <div class="relative w-full">
            <input
              type="text"
              [ngModel]="chatService.searchQuery()"
              (ngModelChange)="chatService.searchQuery.set($event)"
              placeholder="Search chats..."
              class="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg
                     bg-white/80 dark:bg-[#201F1D]
                     border border-claude-border/70 dark:border-claude-borderDark/70
                     text-claude-text dark:text-claude-textDark
                     placeholder-claude-muted/60 dark:placeholder-claude-mutedDark/60
                     focus:outline-none focus:ring-1 focus:ring-claude-accent/50"
            />
            <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-claude-muted/60" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>
            </svg>
            @if (chatService.searchQuery()) {
              <button
                type="button"
                (click)="chatService.searchQuery.set('')"
                class="absolute right-2 top-2 text-claude-muted hover:text-claude-text p-0.5 cursor-pointer"
              >
                <svg xmlns="http://www.w3.org/2000/svg" class="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            }
          </div>
        }
      </div>

      <!-- Middle Section: Grouped Conversation List -->
      <div class="flex-1 overflow-y-auto px-2 py-2 space-y-3 min-h-0">
        @if (chatService.conversations().length === 0) {
          <div class="px-3 py-8 text-center text-xs text-claude-muted dark:text-claude-mutedDark">
            <div class="w-8 h-8 rounded-full bg-black/5 dark:bg-white/5 flex items-center justify-center mx-auto mb-2 text-claude-muted">
              <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
              </svg>
            </div>
            No conversations yet.<br>Start typing or speaking!
          </div>
        }

        @for (group of chatService.groupedConversations(); track group.label) {
          <div class="space-y-1">
            <div class="px-2 pt-1 pb-1 text-[10px] font-bold uppercase tracking-wider text-claude-muted/75 dark:text-claude-mutedDark/75 select-none">
              {{ group.label }}
            </div>

            @for (conv of group.items; track conv.id) {
              <div
                (click)="onSelect(conv.id)"
                [ngClass]="chatService.currentConversationId() === conv.id
                  ? 'bg-white dark:bg-[#252320] shadow-xs border-claude-accent/40 text-claude-text dark:text-claude-textDark font-medium'
                  : 'border-transparent text-claude-muted dark:text-claude-mutedDark hover:text-claude-text dark:hover:text-claude-textDark hover:bg-black/5 dark:hover:bg-white/5'"
                class="group relative flex items-center justify-between px-2.5 py-2 min-h-[40px] rounded-xl
                       cursor-pointer border transition-all duration-150 text-xs sm:text-sm"
              >
                <!-- Title or Edit Input -->
                @if (editingId() === conv.id) {
                  <div class="flex items-center gap-1.5 w-full" (click)="$event.stopPropagation()">
                    <input
                      #editInput
                      type="text"
                      [(ngModel)]="editTitle"
                      (keydown.enter)="saveRename(conv.id)"
                      (keydown.escape)="cancelRename()"
                      class="flex-1 px-2 py-1 text-xs rounded bg-white dark:bg-[#1A1918] border border-claude-accent text-claude-text dark:text-claude-textDark focus:outline-none"
                      aria-label="Edit conversation title"
                    />
                    <button
                      type="button"
                      (click)="saveRename(conv.id)"
                      class="p-1 min-h-[30px] min-w-[30px] text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 rounded flex items-center justify-center cursor-pointer"
                      aria-label="Save title"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                    </button>
                    <button
                      type="button"
                      (click)="cancelRename()"
                      class="p-1 min-h-[30px] min-w-[30px] text-claude-muted hover:bg-black/5 rounded flex items-center justify-center cursor-pointer"
                      aria-label="Cancel rename"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                    </button>
                  </div>
                } @else {
                  <div class="flex items-center gap-2 truncate mr-1 flex-1 min-w-0">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5 shrink-0 opacity-70" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                    </svg>
                    <span class="truncate">
                      {{ conv.title }}
                    </span>
                  </div>

                  <!-- Hover Quick Actions: Export, Rename, Delete -->
                  <div class="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity" (click)="$event.stopPropagation()">
                    <button
                      type="button"
                      (click)="startRenaming(conv, $event)"
                      class="p-1 min-h-[30px] min-w-[30px] rounded text-claude-muted dark:text-claude-mutedDark hover:text-claude-text dark:hover:text-claude-textDark hover:bg-black/5 dark:hover:bg-white/10 flex items-center justify-center cursor-pointer"
                      aria-label="Rename conversation"
                      title="Rename chat"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" class="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>
                      </svg>
                    </button>
                    <button
                      type="button"
                      (click)="onDelete(conv.id, $event)"
                      class="p-1 min-h-[30px] min-w-[30px] rounded text-claude-muted dark:text-claude-mutedDark hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/20 flex items-center justify-center cursor-pointer"
                      aria-label="Delete conversation"
                      title="Delete chat"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" class="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M3 6h18"/>
                        <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
                        <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>
                      </svg>
                    </button>
                  </div>
                }
              </div>
            }
          </div>
        }
      </div>

      <!-- Bottom User / Theme / Options Bar -->
      <div class="p-2.5 border-t border-claude-border/60 dark:border-claude-borderDark/60 flex flex-col gap-2 shrink-0 bg-black/[0.02] dark:bg-white/[0.02]">
        <div class="flex items-center justify-between text-xs text-claude-muted dark:text-claude-mutedDark">
          <div class="flex items-center gap-1.5">
            <div class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
            <span class="text-[11px] font-medium">AeroGPT Local</span>
          </div>

          <div class="flex items-center gap-1">
            <!-- Export active chat as Markdown -->
            @if (chatService.currentConversation()) {
              <button
                type="button"
                (click)="chatService.exportCurrentChat()"
                class="p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition-colors cursor-pointer text-claude-muted hover:text-claude-text"
                title="Export chat as Markdown"
                aria-label="Export chat"
              >
                <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                  <polyline points="7 10 12 15 17 10"/>
                  <line x1="12" y1="15" x2="12" y2="3"/>
                </svg>
              </button>
            }

            <!-- Theme Toggle -->
            <button
              type="button"
              (click)="storageService.toggleTheme()"
              class="p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition-colors cursor-pointer"
              [attr.aria-label]="storageService.theme() === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'"
              title="Toggle theme"
            >
              @if (storageService.theme() === 'dark') {
                <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5 text-amber-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <circle cx="12" cy="12" r="5"/>
                  <line x1="12" y1="1" x2="12" y2="3"/>
                  <line x1="12" y1="21" x2="12" y2="23"/>
                </svg>
              } @else {
                <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5 text-claude-muted" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
                </svg>
              }
            </button>
          </div>
        </div>

        @if (chatService.conversations().length > 0) {
          <button
            type="button"
            (click)="onClearAll()"
            class="text-[11px] text-claude-muted hover:text-rose-600 transition-colors text-left px-1 py-0.5 cursor-pointer flex items-center gap-1 opacity-70 hover:opacity-100"
          >
            <svg xmlns="http://www.w3.org/2000/svg" class="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
            </svg>
            <span>Clear all conversations</span>
          </button>
        }
      </div>
    </aside>
  `
})
export class SidebarComponent {
  readonly isOpen = input<boolean>(false);
  readonly closeSidebar = output<void>();

  readonly chatService = inject(ChatService);
  readonly storageService = inject(StorageService);

  readonly editingId = signal<string | null>(null);
  editTitle = '';

  @ViewChild('editInput') editInputElement?: ElementRef<HTMLInputElement>;

  public onNewChat(): void {
    this.chatService.startNewChat();
    this.closeSidebar.emit();
  }

  public onSelect(id: string): void {
    if (this.editingId()) return;
    this.chatService.selectConversation(id);
    this.closeSidebar.emit();
  }

  public startRenaming(conv: Conversation, event: Event): void {
    event.stopPropagation();
    this.editingId.set(conv.id);
    this.editTitle = conv.title;
    setTimeout(() => {
      this.editInputElement?.nativeElement.focus();
      this.editInputElement?.nativeElement.select();
    }, 50);
  }

  public saveRename(id: string): void {
    if (this.editTitle.trim()) {
      this.chatService.renameConversation(id, this.editTitle.trim());
    }
    this.cancelRename();
  }

  public cancelRename(): void {
    this.editingId.set(null);
    this.editTitle = '';
  }

  public onDelete(id: string, event: Event): void {
    event.stopPropagation();
    this.chatService.deleteConversation(id);
  }

  public onClearAll(): void {
    if (confirm('Are you sure you want to clear all conversations? This cannot be undone.')) {
      this.chatService.clearAllConversations();
    }
  }
}
