import { Component, input, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-copy-button',
  standalone: true,
  imports: [CommonModule],
  template: `
    <button
      type="button"
      (click)="copy()"
      [attr.aria-label]="copied() ? 'Copied to clipboard' : ariaLabel()"
      [title]="copied() ? 'Copied!' : 'Copy to clipboard'"
      class="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md
             text-claude-muted dark:text-claude-mutedDark
             hover:text-claude-text dark:hover:text-claude-textDark
             hover:bg-black/5 dark:hover:bg-white/5
             focus:outline-none focus:ring-2 focus:ring-claude-accent/40
             transition-colors duration-150 min-h-[32px] min-w-[32px]"
    >
      @if (copied()) {
        <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="20 6 9 17 4 12"/>
        </svg>
        <span class="text-emerald-600 dark:text-emerald-400 text-[11px] font-medium">Copied!</span>
      } @else {
        <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <rect width="14" height="14" x="8" y="8" rx="2" ry="2"/>
          <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>
        </svg>
        @if (showText()) {
          <span class="text-[11px]">Copy</span>
        }
      }
    </button>
  `
})
export class CopyButtonComponent {
  readonly text = input.required<string>();
  readonly ariaLabel = input<string>('Copy to clipboard');
  readonly showText = input<boolean>(true);

  readonly copied = signal<boolean>(false);

  public async copy(): Promise<void> {
    const content = this.text();
    if (!content) return;

    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(content);
      } else {
        // Fallback for non-secure context
        const textArea = document.createElement('textarea');
        textArea.value = content;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        textArea.remove();
      }
      this.copied.set(true);
      setTimeout(() => this.copied.set(false), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  }
}
