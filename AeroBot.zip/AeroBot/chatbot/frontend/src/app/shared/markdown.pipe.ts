import { Pipe, PipeTransform, inject } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { marked } from 'marked';
import hljs from 'highlight.js';

@Pipe({
  name: 'markdown',
  standalone: true
})
export class MarkdownPipe implements PipeTransform {
  private sanitizer = inject(DomSanitizer);

  constructor() {
    const renderer = new marked.Renderer();

    // Custom code block renderer with language label and copy button
    renderer.code = ({ text, lang }: { text: string; lang?: string }) => {
      const language = lang && hljs.getLanguage(lang) ? lang : 'plaintext';
      let highlighted = text;
      try {
        if (lang && hljs.getLanguage(lang)) {
          highlighted = hljs.highlight(text, { language: lang, ignoreIllegals: true }).value;
        } else {
          highlighted = hljs.highlightAuto(text).value;
        }
      } catch {
        highlighted = text;
      }

      const encodedCode = encodeURIComponent(text);
      return `
        <div class="code-block-wrapper my-3">
          <div class="code-block-header">
            <span>${language}</span>
            <button type="button" class="code-copy-btn" data-code="${encodedCode}" aria-label="Copy ${language} code">
              <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
              <span>Copy</span>
            </button>
          </div>
          <pre><code class="hljs language-${language}">${highlighted}</code></pre>
        </div>
      `;
    };

    // Open links safely in new tab
    renderer.link = ({ href, title, text }: { href: string; title?: string | null; text: string }) => {
      const titleAttr = title ? ` title="${title}"` : '';
      return `<a href="${href}" target="_blank" rel="noopener noreferrer"${titleAttr}>${text}</a>`;
    };

    marked.setOptions({
      renderer,
      gfm: true,
      breaks: true
    });
  }

  transform(content: string | null | undefined): SafeHtml {
    if (!content) return '';
    try {
      const parsed = marked.parse(content) as string;
      return this.sanitizer.bypassSecurityTrustHtml(parsed);
    } catch {
      return this.sanitizer.bypassSecurityTrustHtml(content);
    }
  }
}
