/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: [
    "./src/**/*.{html,ts}",
  ],
  theme: {
    extend: {
      colors: {
        claude: {
          bg: '#FAF8F5',
          bgDark: '#1F1E1B',
          sidebar: '#F3EFEA',
          sidebarDark: '#181715',
          bubble: '#F0EBE1',
          bubbleDark: '#2C2A26',
          border: '#E8E3DA',
          borderDark: '#36342F',
          text: '#2D2B28',
          textDark: '#ECE8E1',
          muted: '#7A746C',
          mutedDark: '#A39D93',
          accent: '#D97757',
          accentHover: '#C46545',
          accentDark: '#E07A5F',
        }
      },
      fontFamily: {
        sans: ['Inter', 'Segoe UI', '-apple-system', 'BlinkMacSystemFont', 'Roboto', 'sans-serif'],
        serif: ['Georgia', 'Cambria', '"Times New Roman"', 'Times', 'serif'],
      }
    },
  },
  plugins: [],
};
