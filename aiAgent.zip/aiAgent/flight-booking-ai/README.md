# FlightAI: AI-Powered Intelligent Flight Booking & Passenger Assistance System
### Single-Agent and LangGraph Multi-Agent Architecture

[![Java](https://img.shields.io/badge/Java-21-orange.svg)](https://www.oracle.com/java/)
[![Spring Boot](https://img.shields.io/badge/Spring%20Boot-3.3.5-brightgreen.svg)](https://spring.io/projects/spring-boot)
[![Python](https://img.shields.io/badge/Python-3.13-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.115-teal.svg)](https://fastapi.tiangolo.com/)
[![LangGraph](https://img.shields.io/badge/LangGraph-Multi--Agent-purple.svg)](https://www.langchain.com/langgraph)
[![React](https://img.shields.io/badge/React-18.3-cyan.svg)](https://react.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.5-blue.svg)](https://www.typescriptlang.org/)
[![MySQL](https://img.shields.io/badge/MySQL-8.0-blue.svg)](https://www.mysql.com/)

FlightAI is a complete, production-grade flight booking management platform and AI cognitive system built for academic presentation and viva demonstration. It features real transactional seat reservations, single-agent and multi-agent AI execution comparison, real-time flight disruption management, RAG policy assistance, and role-based access control.

---

## Key Capabilities & Highlights

1. **Dual AI Architecture**:
   - **Single-Agent Mode**: Autonomous "Smart Flight Assistant" with direct tool dispatch.
   - **Multi-Agent Mode**: LangGraph supervisor architecture coordinating 8 specialized agents:
     - `FlightSearchAgent` (Database querying)
     - `SmartRecommendationAgent` (Deterministic multi-criteria scoring)
     - `BookingManagementAgent` (Verification & rule enforcement)
     - `FlightDisruptionAgent` (Simulated delays, cancellations & passenger rebooking)
     - `SmartBaggageAgent` (Allowance calculator & case tracking)
     - `SentimentAgent` (Feedback polarity & urgency classification)
     - `RAGRetrievalAgent` (Document vector similarity search)
     - `AccessibilityAgent` (Wheelchair & special passenger assistance)
2. **Live Agent Activity Panel**: Inspect real-time multi-agent execution steps, intent classification, subtask delegation, and execution timing.
3. **Transactional Core**: Java 21 + Spring Boot 3.3.5 with JPA optimistic seat locking, Flyway migrations (25 tables), and OpenPDF ticket generation.
4. **Offline Demo Mode**: Runs 100% deterministically with real MySQL querying even when no external OpenAI API key is supplied!

---

## Technology Stack

| Layer | Technologies |
|---|---|
| **Frontend** | React 18, TypeScript, Vite, Tailwind CSS, Recharts, Lucide React, Axios, TanStack Query |
| **Backend Core** | Java 21, Spring Boot 3.3.5, Spring Security 6, JJWT 0.12.6, OpenPDF, Flyway 10, Maven |
| **AI Backend** | Python 3.13, FastAPI, LangGraph, Pydantic, ChromaDB / TF-IDF Vector Store, OpenAI SDK |
| **Database** | MySQL 8.0 (25 tables initialized via Flyway migrations) |

---

## One-Click Quick Start (Windows)

### Prerequisites:
- Java 21 LTS installed
- Maven installed
- Python 3.11+ installed
- Node.js 18+ & npm installed
- MySQL 8.0 running locally on port 3306

### Step 1: Database Setup
Ensure the MySQL database `flight_booking_ai` exists:
```sql
CREATE DATABASE IF NOT EXISTS flight_booking_ai;
```
*(Database password in `backend/src/main/resources/application.properties` is configured as `Amir1121@`)*.

### Step 2: Launch All Services
Double-click `scripts/start-all.bat` or run:
```bat
cd flight-booking-ai\scripts
start-all.bat
```
This automatically launches:
1. **Spring Boot Backend**: `http://localhost:8080` (Swagger UI: `http://localhost:8080/swagger-ui/index.html`)
2. **Python AI Service**: `http://localhost:8000` (Docs: `http://localhost:8000/docs`)
3. **React Frontend**: `http://localhost:5173`

---

## One-Click Demo Credentials (For Viva Examiners)

On the Login screen, click any of the 3 prominent **One-Click Demo Role** buttons:

| Role | Email | Password | Features Accessible |
|---|---|---|---|
| **PASSENGER** | `passenger@flightai.local` | `Passenger@123` | Search flights, select seats, download PDF tickets, cancel/reschedule, track baggage, AI chat |
| **STAFF** | `staff@flightai.local` | `Staff@123` | Passenger lookup, disruption management, simulate delays/cancellations, baggage cases, accessibility queue |
| **ADMIN** | `admin@flightai.local` | `Admin@123` | Recharts financial analytics, fleet management, AI agent telemetry logs, RAG knowledge base ingestion |

---

## Step-by-Step Viva Demonstration Script

1. **Explore the Public Search & Architecture**:
   - Open `http://localhost:5173`
   - Select departure airport (`BOM - Mumbai`) and arrival airport (`DEL - New Delhi`). Click **Search Flights**.
   - Notice the comparative AI cards highlighting Single-Agent vs Multi-Agent architecture.
2. **Test Passenger Booking & Concurrency**:
   - Click "Select Seats" on flight `AI-101`.
   - View the interactive aircraft cabin map. Select seat `1A` (Business Class, 1.5x fare) or `12B` (Economy).
   - Enter passenger details and complete the simulated booking.
   - On the confirmation screen, click **Download Official E-Ticket (PDF)** to view the generated PDF boarding pass!
3. **Demonstrate the AI Chat & Live Agent Activity Panel**:
   - Navigate to `/ai-chat`.
   - Click the prompt chip: *"Find cheapest flights from Mumbai to Delhi"*.
   - Watch the **Live Agent Activity Panel** on the right side:
     - `FlightOrchestratorAgent`: Decomposes intent and delegates tasks.
     - `FlightSearchAgent`: Queries MySQL via Spring Boot API.
     - `SmartRecommendationAgent`: Computes multi-criteria score ranking `AI-101` as #1.
   - Switch the toggle at the top to **Single-Agent Mode** and ask: *"What is the domestic baggage policy?"*.
   - Notice the direct single-agent tool dispatch with lower latency.
4. **Demonstrate Flight Disruption & Alternative Routing**:
   - Switch to the **Staff** account (via user dropdown or quick login).
   - Navigate to **Disruption Control** (`/staff/disruptions`).
   - Change flight `AI-101` status to `DELAYED` (+60 minutes) with reason *"Inclement weather at BOM"*.
   - Click **Inspect Passengers** to see the manifest of affected travelers and trigger notifications.
5. **Demonstrate Admin Analytics & RAG Knowledge Base**:
   - Switch to the **Admin** account.
   - Navigate to **Analytics** (`/admin`) to view Recharts visualizations for gross revenue, popular routes, and sentiment breakdown.
   - Navigate to **RAG Knowledge Base** (`/admin/knowledge-base`). Use the **Live RAG Similarity Tester** to search policy chunks with similarity scores!

---

## Comprehensive Project Documentation

All academic documentation is organized inside `flight-booking-ai/documentation/`:
- [`architecture.md`](./documentation/architecture.md) — System architecture, sequence diagrams & communication boundaries.
- [`database-design.md`](./documentation/database-design.md) — ER diagrams, 25-table schema & Flyway migrations.
- [`api-documentation.md`](./documentation/api-documentation.md) — Spring Boot REST & FastAPI endpoints.
- [`single-agent-architecture.md`](./documentation/single-agent-architecture.md) — Smart Flight Assistant direct tool-calling design.
- [`multi-agent-architecture.md`](./documentation/multi-agent-architecture.md) — LangGraph supervisor state graph & 8 specialist agents.
- [`rag-architecture.md`](./documentation/rag-architecture.md) — Document ingestion, vector chunking & cosine similarity retrieval.
- [`use-cases.md`](./documentation/use-cases.md) — Passenger, Staff, and Admin operational scenarios.
- [`test-report.md`](./documentation/test-report.md) — Backend JUnit, Pytest, and Frontend build test execution logs.
- [`project-report.md`](./documentation/project-report.md) — Full academic college project report structure.
- [`viva-questions.md`](./documentation/viva-questions.md) — 30+ viva examination questions with detailed technical answers.
