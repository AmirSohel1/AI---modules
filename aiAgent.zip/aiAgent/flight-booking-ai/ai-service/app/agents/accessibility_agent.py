from typing import Dict, Any
from app.tools.accessibility_tools import tool_explain_accessibility_services

class AccessibilityAgent:
    """Specialized agent that assists passengers needing wheelchair or special airport support."""

    def __init__(self):
        self.name = "Passenger Accessibility Assistant Agent"

    def handle_accessibility(self, query: str) -> Dict[str, Any]:
        info = tool_explain_accessibility_services()
        msg = "### 🦽 Airport Accessibility & Special Assistance\n\n"
        msg += "We provide complimentary wheelchair support across 3 standard categories:\n\n"
        for cat in info["categories"]:
            msg += f"1. **{cat['name']} ({cat['code']}):** {cat['description']}\n"
        msg += "\n**How to reserve:**\n"
        msg += "You can request this directly when booking or anytime under your passenger dashboard. "
        msg += "Our special assistance coordinator will meet you at the terminal entrance."

        return {"message": msg, "categories": info["categories"]}

accessibility_agent = AccessibilityAgent()
