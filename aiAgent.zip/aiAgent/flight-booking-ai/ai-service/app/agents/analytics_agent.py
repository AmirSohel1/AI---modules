from typing import Dict, Any
from app.tools.analytics_tools import tool_get_analytics_overview, tool_get_popular_routes, tool_get_cancellation_stats

class AdminAnalyticsAgent:
    """Specialized agent that translates natural language admin queries into SQL-backed metrics."""

    def __init__(self):
        self.name = "Admin Analytics Agent"

    async def answer_analytics_query(self, query: str) -> Dict[str, Any]:
        overview = await tool_get_analytics_overview()
        routes = await tool_get_popular_routes()
        cancels = await tool_get_cancellation_stats()

        rev = overview.get("totalRevenue", 0)
        bookings = overview.get("totalBookings", 0)
        c_rate = cancels.get("cancellationRatePercent", 0)

        msg = "### 📊 Executive Analytics & Operations Intelligence\n\n"
        msg += f"- **Gross Realized Revenue:** ₹{rev:,.2f}\n"
        msg += f"- **Total System Bookings:** {bookings:,}\n"
        msg += f"- **System-Wide Cancellation Rate:** {c_rate}%\n"
        msg += f"- **Active Scheduled Flights:** {overview.get('activeFlights', 0)}\n\n"

        msg += "**Top-Performing Flight Routes (by Volume):**\n"
        for idx, r in enumerate(routes[:4], 1):
            msg += f"{idx}. **{r.get('route')}** ({r.get('sourceCity')} ➔ {r.get('destCity')}): "
            msg += f"**{r.get('bookingCount')} bookings** | ₹{r.get('totalRevenue', 0):,}\n"

        return {
            "message": msg,
            "metrics": {
                "revenue": rev,
                "bookings": bookings,
                "cancellationRate": c_rate
            }
        }

analytics_agent = AdminAnalyticsAgent()
