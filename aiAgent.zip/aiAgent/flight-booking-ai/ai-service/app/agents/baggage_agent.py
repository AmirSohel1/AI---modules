from typing import Dict, Any
from app.tools.baggage_tools import tool_get_baggage_status
import re

class SmartBaggageAgent:
    """Specialized agent assisting with baggage allowances, excess fees, and lost baggage cases."""

    def __init__(self):
        self.name = "Smart Baggage Assistant Agent"

    async def handle_baggage(self, query: str) -> Dict[str, Any]:
        ref_match = re.search(r'\b(BAG-[A-Z]{3}-\d{4})\b', query.upper())
        if ref_match:
            ref = ref_match.group(1)
            case = await tool_get_baggage_status(ref)
            if case:
                msg = f"### Baggage Tracking Status: {ref}\n\n"
                msg += f"- **Status:** `{case.get('status')}`\n"
                msg += f"- **Case Type:** {case.get('caseType')}\n"
                msg += f"- **Flight:** {case.get('flightNumber')}\n"
                msg += f"- **Tag Number:** {case.get('tagNumber')}\n"
                msg += f"- **Latest Update:** {case.get('internalNotes', 'Being handled by ramp staff')}\n"
                return {"message": msg, "case": case}

        msg = "### 🧳 Smart Baggage Assistance\n\n"
        msg += "**Domestic Baggage Rules:**\n"
        msg += "- **Cabin Baggage:** 1 piece up to 7 kg.\n"
        msg += "- **Check-in Baggage:** Economy: 15 kg (1 piece) | Business: 30 kg (2 pieces).\n"
        msg += "- **Excess Baggage:** ₹450/kg online or ₹550/kg at airport counter.\n\n"
        msg += "**Did your bag not arrive?**\n"
        msg += "You can track your existing case using your Property Irregularity Report (e.g. `BAG-BOM-1001`), "
        msg += "or create a new delayed baggage report under **Baggage Assistance**."

        return {"message": msg, "case": None}

baggage_agent = SmartBaggageAgent()
