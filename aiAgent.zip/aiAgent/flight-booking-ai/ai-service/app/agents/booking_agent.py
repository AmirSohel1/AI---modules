import re
from typing import Dict, Any, Optional
from app.tools.booking_tools import tool_get_booking_by_pnr

class BookingManagementAgent:
    """Specialized agent assisting with bookings, PNR status, and rule validations."""

    def __init__(self):
        self.name = "Booking Management Agent"

    async def handle_booking_query(self, query: str, user_context: Dict[str, Any]) -> Dict[str, Any]:
        pnr_match = re.search(r'\b([A-Z0-9]{2}-[0-9]{6})\b', query.upper())
        if pnr_match:
            pnr = pnr_match.group(1)
            booking = await tool_get_booking_by_pnr(pnr)
            if booking:
                msg = f"### Booking Details for PNR: {pnr}\n\n"
                msg += f"- **Flight:** {booking.get('flight', {}).get('flightNumber')}\n"
                msg += f"- **Route:** {booking.get('flight', {}).get('sourceAirport', {}).get('city')} ➔ {booking.get('flight', {}).get('destinationAirport', {}).get('city')}\n"
                msg += f"- **Travel Date:** {booking.get('travelDate')}\n"
                msg += f"- **Status:** `{booking.get('status')}`\n"
                msg += f"- **Total Fare:** ₹{booking.get('totalAmount')}\n\n"
                msg += "**Passengers:**\n"
                for p in booking.get("passengers", []):
                    msg += f"- {p.get('fullName')} (Seat: {p.get('seatNumber')}, Ticket: {p.get('ticketNumber')})\n"
                return {
                    "message": msg,
                    "booking": booking
                }

        msg = "### Booking Management & Assistance\n\n"
        msg += "I can assist you with your flight reservations.\n"
        msg += "To check your status, please provide your **6-digit PNR reference** (e.g., `AI-829101`).\n\n"
        msg += "> *Policy Note: Final booking transactions, cancellations, and seat changes require your explicit confirmation on the checkout page.*"
        return {"message": msg, "booking": None}

booking_agent = BookingManagementAgent()
