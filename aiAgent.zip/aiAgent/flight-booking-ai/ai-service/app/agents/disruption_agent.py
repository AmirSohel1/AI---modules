from typing import Dict, Any, List
from app.tools.disruption_tools import tool_get_disruption_alternatives
from app.tools.flight_tools import tool_search_flights

class FlightDisruptionAgent:
    """Specialized agent managing flight delays, cancellations, and alternative recommendations."""

    def __init__(self):
        self.name = "Flight Disruption Management Agent"

    async def handle_disruption(self, query: str) -> Dict[str, Any]:
        q = query.lower()
        is_cancelled = "cancel" in q or "cancelled" in q

        # Fetch alternative flights from BOM to DEL as primary simulated scenario
        alternatives = await tool_get_disruption_alternatives(2)
        if not alternatives:
            alternatives = await tool_search_flights("Mumbai", "Delhi")

        alt_cards = []
        for f in alternatives[:3]:
            alt_cards.append({
                "flightId": f.get("id"),
                "flightNumber": f.get("flightNumber"),
                "airlineName": f.get("airline", {}).get("name", "Airline"),
                "airlineCode": f.get("airline", {}).get("code", "AI"),
                "source": f.get("sourceAirport", {}).get("city", "Mumbai"),
                "destination": f.get("destinationAirport", {}).get("city", "Delhi"),
                "departureTime": str(f.get("departureTime", "")),
                "arrivalTime": str(f.get("arrivalTime", "")),
                "durationMinutes": f.get("durationMinutes", 135),
                "basePrice": float(f.get("basePrice", 5000.0)),
                "stops": f.get("stops", 0)
            })

        msg = "### ⚠️ Flight Disruption Support & Alternative Options\n\n"
        if is_cancelled:
            msg += "We sincerely apologize for the flight cancellation. Under our Passenger Protection Charter:\n"
            msg += "1. **Free Rescheduling:** You can select any replacement flight below with **zero change fee** and **no fare difference**.\n"
            msg += "2. **100% Full Refund:** If you prefer not to travel, you can claim an instant full refund.\n\n"
        else:
            msg += "If your scheduled flight is delayed by more than 2 hours, free rescheduling and complimentary refreshments are provided.\n\n"

        msg += f"Here are **{len(alt_cards)} replacement flights** immediately available for rebooking:"

        return {
            "message": msg,
            "flight_cards": alt_cards,
            "policy": "100% Full Refund or Free Reschedule for airline disruptions"
        }

disruption_agent = FlightDisruptionAgent()
