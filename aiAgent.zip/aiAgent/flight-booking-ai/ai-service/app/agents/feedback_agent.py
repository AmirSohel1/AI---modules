from typing import Dict, Any

class PassengerFeedbackAgent:
    """Specialized agent that analyzes feedback sentiment, categorizes complaints, and tracks urgency."""

    def __init__(self):
        self.name = "Passenger Feedback & Sentiment Agent"

    def analyze_feedback(self, comment: str, rating: int) -> Dict[str, Any]:
        q = comment.lower()

        # Sentiment
        if rating >= 4:
            sentiment = "POSITIVE"
        elif rating == 3:
            sentiment = "NEUTRAL"
        else:
            sentiment = "NEGATIVE"

        # Category
        if any(w in q for w in ["delay", "late", "waiting", "schedule", "cancelled"]):
            category = "FLIGHT_DELAY"
        elif any(w in q for w in ["bag", "luggage", "damaged", "lost"]):
            category = "BAGGAGE_PROBLEM"
        elif any(w in q for w in ["staff", "crew", "airhostess", "pilot", "rude", "polite"]):
            category = "STAFF_BEHAVIOR"
        elif any(w in q for w in ["refund", "money", "charged", "deduct"]):
            category = "REFUND_PROBLEM"
        elif any(w in q for w in ["dirty", "clean", "food", "meal", "water"]):
            category = "CLEANLINESS"
        else:
            category = "OTHER"

        urgency = 8 if sentiment == "NEGATIVE" else (5 if sentiment == "NEUTRAL" else 2)

        return {
            "sentiment": sentiment,
            "category": category,
            "urgency_score": urgency,
            "summary": f"Detected {sentiment} sentiment concerning {category.replace('_', ' ').lower()}."
        }

feedback_agent = PassengerFeedbackAgent()
