import re
from typing import Dict, Any, List, Optional
from app.tools.flight_tools import tool_search_flights

class FlightSearchAgent:
    """Specialized agent responsible for flight search against the MySQL database."""

    def __init__(self):
        self.name = "Flight Search Agent"

    async def search(self, query: str) -> List[Dict[str, Any]]:
        q = query.lower()

        # Extract source and destination
        cities = {
            "mumbai": "Mumbai", "bom": "Mumbai",
            "delhi": "Delhi", "del": "Delhi",
            "bengaluru": "Bengaluru", "blr": "Bengaluru", "bangalore": "Bengaluru",
            "chennai": "Chennai", "maa": "Chennai",
            "hyderabad": "Hyderabad", "hyd": "Hyderabad",
            "kolkata": "Kolkata", "ccu": "Kolkata",
            "pune": "Pune", "pnq": "Pune",
            "goa": "Goa", "goi": "Goa"
        }

        found_cities = []
        for key, val in cities.items():
            if re.search(r'\b' + re.escape(key) + r'\b', q) and val not in found_cities:
                found_cities.append(val)

        src = found_cities[0] if len(found_cities) > 0 else "Mumbai"
        dst = found_cities[1] if len(found_cities) > 1 else ("Delhi" if src != "Delhi" else "Bengaluru")

        # Extract budget if mentioned (e.g. 6000 or ₹6000)
        budget_match = re.search(r'(?:₹|rs\.?|inr|under|below|budget\s*(?:is|of)?)\s*(\d{4,5})', q)
        max_budget = float(budget_match.group(1)) if budget_match else None

        # Extract time preference
        time_pref = None
        if "morning" in q: time_pref = "MORNING"
        elif "afternoon" in q: time_pref = "AFTERNOON"
        elif "evening" in q: time_pref = "EVENING"
        elif "night" in q: time_pref = "NIGHT"

        flights = await tool_search_flights(source=src, destination=dst, max_budget=max_budget, time_of_day=time_pref)
        if not flights:
            # Fallback to general route without budget filter
            flights = await tool_search_flights(source=src, destination=dst)
        if not flights:
            flights = await tool_search_flights()

        return flights

flight_search_agent = FlightSearchAgent()
