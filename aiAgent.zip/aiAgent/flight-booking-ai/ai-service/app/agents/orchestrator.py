class FlightOrchestratorAgent:
    """Supervisor agent that classifies passenger intent and coordinates specialized agents."""

    def __init__(self):
        self.name = "Flight Orchestrator Agent"

    def classify_intent(self, query: str) -> str:
        q = query.lower()
        if any(term in q for term in ["policy", "rule", "faq", "terms", "guideline"]):
            return "KNOWLEDGE_RAG"
        elif any(term in q for term in ["cancel", "cancelled", "delay", "delayed", "disrupt", "alternative"]):
            return "DISRUPTION_AND_CANCELLATION"
        elif any(term in q for term in ["bag", "luggage", "suitcase", "pir", "allowance"]):
            return "BAGGAGE_ASSISTANCE"
        elif any(term in q for term in ["wheelchair", "special", "disabled", "elderly", "accessibility", "stretcher"]):
            return "ACCESSIBILITY_ASSISTANCE"
        elif any(term in q for term in ["pnr", "ticket", "my booking", "reservation"]):
            return "BOOKING_MANAGEMENT"
        elif any(term in q for term in ["flight", "search", "book", "fly", "mumbai", "delhi", "bengaluru", "chennai", "goa", "pune", "cheap", "fast"]):
            return "FLIGHT_SEARCH_AND_RECOMMENDATION"
        elif any(term in q for term in ["complain", "feedback", "rating", "rude", "dirty", "bad service"]):
            return "FEEDBACK_AND_SENTIMENT"
        elif any(term in q for term in ["revenue", "statistic", "analytics", "routes", "performance", "admin"]):
            return "ADMIN_ANALYTICS"
        return "GENERAL_COMPANION"

orchestrator_agent = FlightOrchestratorAgent()
