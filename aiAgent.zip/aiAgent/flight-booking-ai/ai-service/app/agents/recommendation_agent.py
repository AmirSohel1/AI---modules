from typing import Dict, Any, List

class RecommendationAgent:
    """Specialized agent that uses deterministic multi-criteria scoring to rank flights."""

    def __init__(self):
        self.name = "Smart Recommendation Agent"

    def rank_and_explain(self, flights: List[Dict[str, Any]], query: str) -> Dict[str, Any]:
        if not flights:
            return {"ranked": [], "reasoning": "No flights matched the requested criteria."}

        q = query.lower()
        prefer_cheapest = "cheap" in q or "budget" in q or "lowest" in q
        prefer_fastest = "fast" in q or "quick" in q or "shortest" in q
        prefer_morning = "morning" in q

        def score_flight(f):
            price = float(f.get("basePrice", 5000))
            duration = int(f.get("durationMinutes", 135))
            stops = int(f.get("stops", 0))

            # Base score: lower is better
            score = (price * 0.5) + (duration * 10) + (stops * 1500)
            if prefer_cheapest:
                score = (price * 0.8) + (duration * 5)
            elif prefer_fastest:
                score = (price * 0.2) + (duration * 25)

            return score

        sorted_flights = sorted(flights, key=score_flight)
        top_3 = sorted_flights[:3]

        # Formulate deterministic explanation
        best = top_3[0]
        reason = f"Ranked **{best.get('flightNumber')} ({best.get('airline', {}).get('name')})** as top recommendation: "
        if prefer_cheapest:
            reason += f"Lowest available fare of ₹{best.get('basePrice')} with {best.get('durationMinutes')} mins flight duration."
        elif prefer_fastest:
            reason += f"Fastest flight time of {best.get('durationMinutes')} mins with {best.get('stops', 0)} stops."
        else:
            reason += f"Optimal balance of price (₹{best.get('basePrice')}) and duration ({best.get('durationMinutes')} mins)."

        return {
            "ranked": top_3,
            "reasoning": reason
        }

recommendation_agent = RecommendationAgent()
