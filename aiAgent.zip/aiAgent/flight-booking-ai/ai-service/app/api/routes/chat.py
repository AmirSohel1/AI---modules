from fastapi import APIRouter, Depends
from app.schemas.requests import ChatRequest
from app.schemas.responses import ChatResponse
from app.core.security import verify_ai_token
from app.core.config import settings
from app.agents.single_agent import single_agent
from app.graph.workflow import multi_agent_workflow
import time

router = APIRouter(prefix="/api", tags=["Chat"])

@router.post("/chat", response_model=ChatResponse, dependencies=[Depends(verify_ai_token)])
async def chat_endpoint(request: ChatRequest):
    user_context = {
        "user_id": request.user_id,
        "user_role": request.user_role,
        "user_name": request.user_name,
        "user_email": request.user_email
    }

    mode_upper = request.mode.upper() if request.mode else "MULTI_AGENT"

    if mode_upper == "SINGLE_AGENT":
        res = await single_agent.execute(request.message, user_context)
    else:
        res = await multi_agent_workflow.run(request.message, user_context)

    return ChatResponse(
        conversation_id=request.conversation_id,
        mode=mode_upper,
        message=res["message"],
        is_demo_mode=settings.is_demo_mode,
        agent_activity=res.get("activity", []),
        flight_cards=res.get("flight_cards"),
        disruption_card=res.get("disruption_card"),
        baggage_card=res.get("baggage_card"),
        source_citations=res.get("citations", []),
        suggested_follow_ups=res.get("follow_ups", [])
    )
