from fastapi import APIRouter
from app.core.config import settings

router = APIRouter(prefix="/api", tags=["Health"])

@router.get("/health")
async def health_check():
    return {
        "status": "UP",
        "service": "Python FastAPI AI Service",
        "demo_mode": settings.is_demo_mode,
        "model": settings.openai_model,
        "single_agent_ready": True,
        "multi_agent_ready": True
    }
