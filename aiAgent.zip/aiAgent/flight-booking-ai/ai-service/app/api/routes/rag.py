from fastapi import APIRouter, Depends
from app.schemas.requests import RagQueryRequest, RagUploadRequest
from app.schemas.responses import RagResponse
from app.services.rag_service import rag_service
from app.core.security import verify_ai_token

router = APIRouter(prefix="/api/rag", tags=["RAG"])

@router.post("/query", response_model=RagResponse, dependencies=[Depends(verify_ai_token)])
async def query_rag(request: RagQueryRequest):
    citations = rag_service.retrieve(request.query, top_k=request.top_k, category=request.category)
    grounded_answer = "Based on our official travel documentation:\n\n"
    for c in citations:
        grounded_answer += f"- **{c.document_title}:** {c.snippet}\n"

    return RagResponse(
        query=request.query,
        grounded_answer=grounded_answer,
        citations=citations
    )

@router.post("/upload", dependencies=[Depends(verify_ai_token)])
async def upload_document(request: RagUploadRequest):
    rag_service.add_document(request.title, request.category, request.filename, request.text)
    return {"status": "success", "message": f"Document '{request.title}' indexed into RAG store"}

@router.get("/documents", dependencies=[Depends(verify_ai_token)])
async def get_documents():
    return [{"title": d["title"], "category": d["category"], "filename": d["filename"]} for d in rag_service.documents]
