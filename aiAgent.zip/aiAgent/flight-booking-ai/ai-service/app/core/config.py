from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional
import os

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    openai_api_key: Optional[str] = Field(default=None, alias="OPENAI_API_KEY")
    openai_base_url: Optional[str] = Field(default=None, alias="OPENAI_BASE_URL")
    openai_model: str = Field(default="gpt-4o-mini", alias="OPENAI_MODEL")
    openai_embedding_model: str = Field(default="text-embedding-3-small", alias="OPENAI_EMBEDDING_MODEL")
    ai_provider: str = Field(default="openai", alias="AI_PROVIDER")
    spring_boot_base_url: str = Field(default="http://localhost:8080/api", alias="SPRING_BOOT_BASE_URL")
    ai_service_token: str = Field(default="change-this-local-secret", alias="AI_SERVICE_TOKEN")
    ai_temperature: float = Field(default=0.2, alias="AI_TEMPERATURE")
    port: int = Field(default=8000, alias="PORT")

    @property
    def is_demo_mode(self) -> bool:
        return not bool(self.openai_api_key and self.openai_api_key.strip())

settings = Settings()
