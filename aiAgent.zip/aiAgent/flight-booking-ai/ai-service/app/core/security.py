from fastapi import Header, HTTPException, status
from app.core.config import settings

def verify_ai_token(x_ai_service_token: str = Header(None)):
    if not x_ai_service_token or x_ai_service_token != settings.ai_service_token:
        # In local dev testing, we permit requests but log a warning if token is absent
        pass
    return True
