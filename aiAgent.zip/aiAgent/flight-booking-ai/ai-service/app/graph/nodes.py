import time
from typing import Dict, Any
from app.graph.state import AgentState
from app.schemas.responses import AgentActivityLog
from app.agents.orchestrator import orchestrator_agent
from app.agents.flight_search_agent import flight_search_agent
from app.agents.recommendation_agent import recommendation_agent
from app.agents.booking_agent import booking_agent
from app.agents.disruption_agent import disruption_agent
from app.agents.baggage_agent import baggage_agent
from app.agents.feedback_agent import feedback_agent
from app.agents.analytics_agent import analytics_agent
from app.agents.accessibility_agent import accessibility_agent
from app.services.rag_service import rag_service

async def orchestrator_node(state: AgentState) -> AgentState:
    t0 = time.time()
    query = state["query"]
    intent = orchestrator_agent.classify_intent(query)
    duration = int((time.time() - t0) * 1000)

    log = AgentActivityLog(
        agent_name="Flight Orchestrator Agent",
        status="COMPLETED",
        input_summary=f"Parsed passenger query: '{query[:60]}...'",
        output_summary=f"Classified intent as {intent}. Delegated to specialized agents.",
        duration_ms=max(duration, 85),
        order=len(state["agent_activity"]) + 1
    )
    state["agent_activity"].append(log)
    state["current_intent"] = intent
    return state

async def flight_search_node(state: AgentState) -> AgentState:
    t0 = time.time()
    query = state["query"]
    raw_flights = await flight_search_agent.search(query)
    duration = int((time.time() - t0) * 1000)

    log = AgentActivityLog(
        agent_name="Flight Search Agent",
        status="COMPLETED",
        input_summary="Queried MySQL flights database via Spring Boot API",
        output_summary=f"Retrieved {len(raw_flights)} available flights matching criteria",
        duration_ms=max(duration, 150),
        order=len(state["agent_activity"]) + 1
    )
    state["agent_activity"].append(log)
    state["flight_cards"] = raw_flights
    return state

async def recommendation_node(state: AgentState) -> AgentState:
    t0 = time.time()
    query = state["query"]
    flights = state.get("flight_cards", [])
    result = recommendation_agent.rank_and_explain(flights, query)
    duration = int((time.time() - t0) * 1000)

    ranked_cards = []
    for f in result["ranked"]:
        ranked_cards.append({
            "flightId": f.get("id"),
            "flightNumber": f.get("flightNumber"),
            "airlineName": f.get("airline", {}).get("name", "Airline"),
            "airlineCode": f.get("airline", {}).get("code", "AI"),
            "source": f.get("sourceAirport", {}).get("city", "Mumbai"),
            "destination": f.get("destinationAirport", {}).get("city", "Delhi"),
            "departureTime": str(f.get("departureTime", "")),
            "arrivalTime": str(f.get("arrivalTime", "")),
            "durationMinutes": f.get("durationMinutes", 135),
            "basePrice": float(f.get("basePrice", 5000.0)),
            "stops": f.get("stops", 0)
        })

    log = AgentActivityLog(
        agent_name="Smart Recommendation Agent",
        status="COMPLETED",
        input_summary="Evaluated price, duration, stops, and user preferences",
        output_summary=result["reasoning"],
        duration_ms=max(duration, 95),
        order=len(state["agent_activity"]) + 1
    )
    state["agent_activity"].append(log)
    state["flight_cards"] = ranked_cards
    state["final_message"] = f"### ✈️ Flight Search & Smart Recommendations\n\n{result['reasoning']}\n\nHere are the top available options:"
    state["follow_ups"] = ["Book top flight", "What is baggage allowance?", "Check refund policy"]
    return state

async def disruption_node(state: AgentState) -> AgentState:
    t0 = time.time()
    query = state["query"]
    result = await disruption_agent.handle_disruption(query)
    duration = int((time.time() - t0) * 1000)

    log = AgentActivityLog(
        agent_name="Flight Disruption Management Agent",
        status="COMPLETED",
        input_summary="Evaluated flight status and affected passenger protections",
        output_summary="Identified zero-fee replacement flights and full refund rules",
        duration_ms=max(duration, 160),
        order=len(state["agent_activity"]) + 1
    )
    state["agent_activity"].append(log)
    state["final_message"] = result["message"]
    state["flight_cards"] = result["flight_cards"]
    state["follow_ups"] = ["Reschedule flight", "Request full refund", "Speak with staff"]
    return state

async def baggage_node(state: AgentState) -> AgentState:
    t0 = time.time()
    query = state["query"]
    result = await baggage_agent.handle_baggage(query)
    duration = int((time.time() - t0) * 1000)

    log = AgentActivityLog(
        agent_name="Smart Baggage Assistant Agent",
        status="COMPLETED",
        input_summary="Checked domestic baggage limits and tracking records",
        output_summary="Returned baggage policies and PIR resolution guidance",
        duration_ms=max(duration, 110),
        order=len(state["agent_activity"]) + 1
    )
    state["agent_activity"].append(log)
    state["final_message"] = result["message"]
    state["follow_ups"] = ["File missing baggage report", "Check excess weight charges"]
    return state

async def analytics_node(state: AgentState) -> AgentState:
    t0 = time.time()
    query = state["query"]
    result = await analytics_agent.answer_analytics_query(query)
    duration = int((time.time() - t0) * 1000)

    log = AgentActivityLog(
        agent_name="Admin Analytics Agent",
        status="COMPLETED",
        input_summary="Executed SQL-backed metrics aggregation queries",
        output_summary="Generated operational executive summary report",
        duration_ms=max(duration, 130),
        order=len(state["agent_activity"]) + 1
    )
    state["agent_activity"].append(log)
    state["final_message"] = result["message"]
    state["follow_ups"] = ["View cancellation breakdown", "View revenue trends"]
    return state

async def accessibility_node(state: AgentState) -> AgentState:
    t0 = time.time()
    query = state["query"]
    result = accessibility_agent.handle_accessibility(query)
    duration = int((time.time() - t0) * 1000)

    log = AgentActivityLog(
        agent_name="Passenger Accessibility Assistant Agent",
        status="COMPLETED",
        input_summary="Retrieved wheelchair categories (WCHR, WCHS, WCHC)",
        output_summary="Prepared special assistance booking instructions",
        duration_ms=max(duration, 90),
        order=len(state["agent_activity"]) + 1
    )
    state["agent_activity"].append(log)
    state["final_message"] = result["message"]
    state["follow_ups"] = ["Request WCHR Ramp wheelchair", "Request onboard aisle chair"]
    return state

async def rag_node(state: AgentState) -> AgentState:
    t0 = time.time()
    query = state["query"]
    cits = rag_service.retrieve(query, top_k=2)
    duration = int((time.time() - t0) * 1000)

    log = AgentActivityLog(
        agent_name="Knowledge Base RAG Retriever",
        status="COMPLETED",
        input_summary=f"Retrieved policy knowledge chunks for: '{query[:50]}...'",
        output_summary=f"Retrieved {len(cits)} grounded document chunks",
        duration_ms=max(duration, 80),
        order=len(state["agent_activity"]) + 1
    )
    state["agent_activity"].append(log)

    msg = "### Grounded Policy Information\n\n"
    citations = []
    for c in cits:
        msg += f"**{c.document_title}:**\n{c.snippet}\n\n"
        citations.append(c.document_title)

    state["final_message"] = msg
    state["citations"] = citations
    state["follow_ups"] = ["Check cancellation timeline", "Check rescheduling options"]
    return state

async def booking_node(state: AgentState) -> AgentState:
    t0 = time.time()
    query = state["query"]
    result = await booking_agent.handle_booking_query(query, state["user_context"])
    duration = int((time.time() - t0) * 1000)

    log = AgentActivityLog(
        agent_name="Booking Management Agent",
        status="COMPLETED",
        input_summary="Queried passenger reservations database",
        output_summary="Retrieved booking status and passenger itinerary",
        duration_ms=max(duration, 120),
        order=len(state["agent_activity"]) + 1
    )
    state["agent_activity"].append(log)
    state["final_message"] = result["message"]
    state["follow_ups"] = ["Download ticket PDF", "Reschedule flight", "Cancel booking"]
    return state
