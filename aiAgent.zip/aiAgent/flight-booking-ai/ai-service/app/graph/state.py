from typing import TypedDict, List, Dict, Any, Optional
from app.schemas.responses import AgentActivityLog

class AgentState(TypedDict):
    query: str
    user_context: Dict[str, Any]
    current_intent: str
    active_agent: str
    agent_activity: List[AgentActivityLog]
    flight_cards: Optional[List[Dict[str, Any]]]
    disruption_card: Optional[Dict[str, Any]]
    baggage_card: Optional[Dict[str, Any]]
    citations: List[str]
    final_message: str
    follow_ups: List[str]
