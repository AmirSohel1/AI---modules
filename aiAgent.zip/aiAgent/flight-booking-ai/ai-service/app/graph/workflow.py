from app.graph.state import AgentState
from app.graph.nodes import (
    orchestrator_node,
    flight_search_node,
    recommendation_node,
    disruption_node,
    baggage_node,
    analytics_node,
    accessibility_node,
    rag_node,
    booking_node
)
from app.schemas.responses import AgentActivityLog
from typing import Dict, Any

class MultiAgentWorkflow:
    """Multi-Agent LangGraph supervisor workflow executor."""

    async def run(self, query: str, user_context: Dict[str, Any]) -> Dict[str, Any]:
        state: AgentState = {
            "query": query,
            "user_context": user_context,
            "current_intent": "",
            "active_agent": "Flight Orchestrator Agent",
            "agent_activity": [],
            "flight_cards": None,
            "disruption_card": None,
            "baggage_card": None,
            "citations": [],
            "final_message": "",
            "follow_ups": []
        }

        # 1. Orchestrator Step
        state = await orchestrator_node(state)
        intent = state["current_intent"]

        # 2. Specialized Agent Delegation
        if intent == "FLIGHT_SEARCH_AND_RECOMMENDATION":
            state = await flight_search_node(state)
            state = await recommendation_node(state)
        elif intent == "DISRUPTION_AND_CANCELLATION":
            state = await disruption_node(state)
        elif intent == "BAGGAGE_ASSISTANCE":
            state = await baggage_node(state)
        elif intent == "ADMIN_ANALYTICS":
            state = await analytics_node(state)
        elif intent == "ACCESSIBILITY_ASSISTANCE":
            state = await accessibility_node(state)
        elif intent == "BOOKING_MANAGEMENT":
            state = await booking_node(state)
        elif intent == "KNOWLEDGE_RAG":
            state = await rag_node(state)
        else:
            # General Companion node
            state["agent_activity"].append(AgentActivityLog(
                agent_name="Personalized Travel Companion",
                status="COMPLETED",
                input_summary="Processed travel companion inquiry",
                output_summary="Generated travel planning tips and journey guidance",
                duration_ms=110,
                order=len(state["agent_activity"]) + 1
            ))
            state["final_message"] = (
                "Hello! I am your **Multi-Agent Flight Assistant**.\n\n"
                "I coordinate across our specialized agents:\n"
                "- 🔍 **Flight Search & Recommendation Agents** for best fares and shortest routes\n"
                "- ⚠️ **Flight Disruption Agent** for delay/cancellation protection\n"
                "- 🧳 **Smart Baggage Assistant** for tracking and baggage policies\n"
                "- 🦽 **Accessibility Assistant** for wheelchair and airport escort services\n"
                "- 📊 **Admin Analytics Agent** for route and revenue statistics\n\n"
                "How can I assist your journey today?"
            )
            state["follow_ups"] = ["Find flights from Mumbai to Delhi", "What is my baggage allowance?", "Check cancellation policy"]

        return {
            "message": state["final_message"],
            "flight_cards": state["flight_cards"],
            "disruption_card": state["disruption_card"],
            "baggage_card": state["baggage_card"],
            "citations": state["citations"],
            "activity": state["agent_activity"],
            "follow_ups": state["follow_ups"]
        }

multi_agent_workflow = MultiAgentWorkflow()
