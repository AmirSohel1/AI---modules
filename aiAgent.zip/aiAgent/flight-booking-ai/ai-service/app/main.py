from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes import chat, rag, health
from app.core.logging import setup_logging, logger
from app.core.config import settings

setup_logging()

app = FastAPI(
    title="Flight AI Agent Service",
    description="Intelligent Multi-Agent and Single-Agent Architecture for Flight Booking & Passenger Assistance",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router)
app.include_router(chat.router)
app.include_router(rag.router)

@app.on_event("startup")
async def startup_event():
    logger.info("Flight AI Agent Service started successfully.")
    logger.info(f"Mode: {'DEMO MODE (Local Deterministic Agents)' if settings.is_demo_mode else 'OPENAI CONNECTED'}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=settings.port, reload=True)
