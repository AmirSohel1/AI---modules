from pydantic import BaseModel, Field
from typing import Optional

class ChatRequest(BaseModel):
    conversation_id: Optional[int] = None
    user_id: Optional[int] = None
    user_role: Optional[str] = "PASSENGER"
    user_name: Optional[str] = "Passenger"
    user_email: Optional[str] = None
    message: str = Field(..., description="Passenger natural language query")
    mode: str = Field(default="MULTI_AGENT", description="SINGLE_AGENT or MULTI_AGENT")

class RagQueryRequest(BaseModel):
    query: str
    top_k: int = 3
    category: Optional[str] = None

class RagUploadRequest(BaseModel):
    title: str
    category: str
    filename: str
    text: str
