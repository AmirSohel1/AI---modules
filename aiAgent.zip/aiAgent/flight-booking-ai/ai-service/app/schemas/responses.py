from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

class AgentActivityLog(BaseModel):
    agent_name: str
    status: str = "COMPLETED" # PENDING, RUNNING, COMPLETED, FAILED
    input_summary: Optional[str] = None
    output_summary: Optional[str] = None
    duration_ms: int = 0
    order: int = 1

class FlightCard(BaseModel):
    flight_id: int
    flight_number: str
    airline_name: str
    airline_code: str
    source: str
    destination: str
    departure_time: str
    arrival_time: str
    duration_minutes: int
    base_price: float
    stops: int = 0

class ChatResponse(BaseModel):
    conversation_id: Optional[int] = None
    mode: str = "MULTI_AGENT"
    message: str
    is_demo_mode: bool = False
    agent_activity: List[AgentActivityLog] = Field(default_factory=list)
    flight_cards: Optional[List[Dict[str, Any]]] = None
    disruption_card: Optional[Dict[str, Any]] = None
    baggage_card: Optional[Dict[str, Any]] = None
    source_citations: List[str] = Field(default_factory=list)
    suggested_follow_ups: List[str] = Field(default_factory=list)

class RagCitation(BaseModel):
    document_title: str
    category: str
    snippet: str
    relevance_score: float

class RagResponse(BaseModel):
    query: str
    grounded_answer: str
    citations: List[RagCitation]
