import json
from typing import Dict, Any, List, Optional
from openai import AsyncOpenAI
from app.core.config import settings
from app.core.logging import logger

class LlmService:
    def __init__(self):
        self.api_key = settings.openai_api_key
        self.base_url = settings.openai_base_url
        self.model = settings.openai_model
        self.temperature = settings.ai_temperature

        if self.api_key and self.api_key.strip():
            client_kwargs = {"api_key": self.api_key}
            if self.base_url and self.base_url.strip():
                client_kwargs["base_url"] = self.base_url
            self.client = AsyncOpenAI(**client_kwargs)
        else:
            self.client = None

    @property
    def is_available(self) -> bool:
        return self.client is not None

    async def generate_chat_completion(self, system_prompt: str, user_prompt: str, response_format_json: bool = False) -> str:
        if not self.is_available:
            raise RuntimeError("OpenAI client not configured")

        kwargs = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "temperature": self.temperature,
            "timeout": 25.0
        }
        if response_format_json:
            kwargs["response_format"] = {"type": "json_object"}

        response = await self.client.chat.completions.create(**kwargs)
        return response.choices[0].message.content or ""

llm_service = LlmService()
