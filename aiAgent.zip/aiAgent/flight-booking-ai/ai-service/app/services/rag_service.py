import re
from typing import List, Dict, Any, Optional
from app.schemas.responses import RagCitation, RagResponse
from app.core.config import settings
from app.core.logging import logger

DEFAULT_KNOWLEDGE_DOCUMENTS = [
    {
        "title": "Airline Flight Booking & Reservation Policy",
        "category": "BOOKING_POLICY",
        "filename": "booking_policy.txt",
        "text": """AIRLINE FLIGHT BOOKING & RESERVATION POLICY
1. General Reservation Rules:
- Bookings can be made up to 365 days in advance.
- Passenger name must exactly match government-issued photo ID (Aadhaar, Passport, Voter ID).
- Minor corrections of up to 3 characters in the passenger name are permitted free of charge up to 24 hours prior to scheduled departure.
2. Fare Types:
- Economy Saver: Standard baggage allowance (15kg check-in, 7kg cabin). Seat selection may attract nominal charges.
- Economy Flexi: Free date change up to 24 hours prior to departure. Free standard seat selection.
- Business Class: 30kg check-in baggage, 10kg cabin baggage, priority boarding, lounge access, and gourmet in-flight meals included.
3. Infants and Children:
- Infants under 2 years travel with an infant ticket without occupying a seat.
- Unaccompanied minors aged 5 to 12 require pre-booking under the Junior Aviator program."""
    },
    {
        "title": "Airline Cancellation & Refund Policy",
        "category": "CANCELLATION_POLICY",
        "filename": "cancellation_policy.txt",
        "text": """AIRLINE CANCELLATION & REFUND POLICY
1. Cancellation Timeline and Charges:
- More than 72 hours before departure: Cancellation fee of ₹2,500 or base fare (whichever is lower).
- Between 24 and 72 hours before departure: Cancellation fee of ₹3,000.
- Less than 24 hours before departure: Cancellation fee of ₹3,500.
- Less than 2 hours before departure (No-Show): Only statutory taxes and User Development Fee (UDF) are refundable.
2. Full Refund Scenarios (Zero Cancellation Fee):
- When a flight is cancelled or delayed by more than 2 hours by the airline, the passenger is entitled to a 100% full refund with zero deduction.
- Free cancellation is permitted within 24 hours of booking if the booking was made at least 7 days prior to flight departure.
3. Refund Processing:
- Simulated refunds are initiated immediately and credited to the original source within 5-7 business days."""
    },
    {
        "title": "Baggage Allowance & Excess Baggage Rules",
        "category": "BAGGAGE_POLICY",
        "filename": "baggage_policy.txt",
        "text": """BAGGAGE ALLOWANCE & EXCESS BAGGAGE RULES
1. Standard Baggage Allowances for Domestic Flights:
- Cabin Baggage: 1 handbag or laptop bag up to 7 kg, maximum dimensions 115 cm (length + width + height).
- Check-in Baggage: Economy class is entitled to 1 piece up to 15 kg. Business class is entitled to 2 pieces up to 30 kg total.
2. Excess Baggage Charges:
- Pre-booked excess baggage via website: ₹450 per additional kg.
- Excess baggage paid at airport check-in counter: ₹550 per additional kg.
- Additional piece charges apply if check-in exceeds 1 piece in Economy class.
3. Delayed or Lost Baggage:
- If your baggage does not appear on the conveyor belt, report immediately to the Airport Baggage Helpdesk before leaving the arrival hall.
- Property Irregularity Report (PIR) reference number will be issued (e.g. BAG-BOM-1001).
- Tracing is conducted through WorldTracer global tracking system.
- Interim relief allowance of ₹3,000 is provided for baggage delayed beyond 24 hours on outbound journeys."""
    },
    {
        "title": "Flight Rescheduling & Change Policy",
        "category": "RESCHEDULING_POLICY",
        "filename": "rescheduling_policy.txt",
        "text": """FLIGHT RESCHEDULING & CHANGE POLICY
1. Date and Time Modifications:
- Rescheduling can be requested up to 2 hours prior to scheduled departure.
- A standard rescheduling change fee of ₹1,500 applies plus any applicable fare difference between old and new flight.
- If the new flight fare is lower, no refund of fare difference is provided; only change fee is charged.
- For Economy Flexi tickets, date change fee is waived (only fare difference applies).
2. Airline Disruption Rescheduling:
- In case of airline-initiated flight delay (>2 hours) or cancellation, passengers may reschedule to any alternative flight within 7 days at ZERO extra fee or fare difference."""
    },
    {
        "title": "Airport Special Assistance & Accessibility Guide",
        "category": "AIRPORT_ASSISTANCE",
        "filename": "accessibility_guide.txt",
        "text": """AIRPORT SPECIAL ASSISTANCE & ACCESSIBILITY GUIDE
1. Wheelchair Assistance:
- Wheelchair support is provided completely free of charge at all airports.
- Categories:
  * WCHR (Ramp): Passenger can climb stairs and walk to seat, needs wheelchair for ramp/gate distance.
  * WCHS (Steps): Passenger cannot climb stairs, can walk to seat inside cabin.
  * WCHC (Cabin): Passenger is completely immobile, requires onboard aisle chair.
- Wheelchair requests should ideally be placed at least 24 hours prior to travel.
2. Medical and Special Needs:
- Stretcher, portable oxygen concentrator (POC), and guide dog travel are accommodated with prior clearance from the Medical Desk at least 48 hours in advance."""
    }
]

class RagService:
    def __init__(self):
        self.documents = list(DEFAULT_KNOWLEDGE_DOCUMENTS)
        self.chunks = self._build_chunks()

    def _build_chunks(self) -> List[Dict[str, Any]]:
        chunks = []
        for doc in self.documents:
            lines = doc["text"].split("\n\n")
            for line in lines:
                cleaned = line.strip()
                if len(cleaned) > 20:
                    chunks.append({
                        "title": doc["title"],
                        "category": doc["category"],
                        "filename": doc["filename"],
                        "content": cleaned
                    })
        return chunks

    def add_document(self, title: str, category: str, filename: str, text: str):
        self.documents.append({
            "title": title,
            "category": category,
            "filename": filename,
            "text": text
        })
        self.chunks = self._build_chunks()

    def retrieve(self, query: str, top_k: int = 3, category: Optional[str] = None) -> List[RagCitation]:
        words = set(re.findall(r'\w+', query.lower()))
        scored_chunks = []

        for chunk in self.chunks:
            if category and chunk["category"].upper() != category.upper():
                continue

            chunk_text = chunk["content"].lower()
            chunk_words = set(re.findall(r'\w+', chunk_text))
            intersection = words.intersection(chunk_words)

            score = len(intersection) / (len(words) + 1.0)
            # Boost score if category matches keywords
            if any(term in query.lower() for term in ["cancel", "refund", "fee"]) and "cancellation" in chunk["filename"]:
                score += 0.5
            if any(term in query.lower() for term in ["bag", "luggage", "weight", "cabin"]) and "baggage" in chunk["filename"]:
                score += 0.5
            if any(term in query.lower() for term in ["wheelchair", "special", "disabled", "assistance"]) and "accessibility" in chunk["filename"]:
                score += 0.5

            if score > 0.05:
                scored_chunks.append((score, chunk))

        scored_chunks.sort(key=lambda x: x[0], reverse=True)
        top = scored_chunks[:top_k]

        return [
            RagCitation(
                document_title=c["title"],
                category=c["category"],
                snippet=c["content"],
                relevance_score=round(s, 3)
            ) for s, c in top
        ]

rag_service = RagService()
