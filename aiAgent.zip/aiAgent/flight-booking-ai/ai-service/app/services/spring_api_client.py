import httpx
from typing import Dict, Any, List, Optional
from app.core.config import settings
from app.core.logging import logger

class SpringApiClient:
    def __init__(self):
        self.base_url = settings.spring_boot_base_url.rstrip("/")
        self.headers = {
            "X-AI-Service-Token": settings.ai_service_token,
            "Content-Type": "application/json"
        }
        self.timeout = 10.0

    async def search_flights(self, source: Optional[str] = None, destination: Optional[str] = None,
                             travel_date: Optional[str] = None, max_budget: Optional[float] = None,
                             airline_code: Optional[str] = None, time_of_day: Optional[str] = None) -> List[Dict[str, Any]]:
        url = f"{self.base_url}/flights/search"
        params = {}
        if source: params["source"] = source
        if destination: params["destination"] = destination
        if travel_date: params["travelDate"] = travel_date
        if max_budget: params["maxBudget"] = max_budget
        if airline_code: params["airlineCode"] = airline_code
        if time_of_day: params["timeOfDay"] = time_of_day

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(url, params=params, headers=self.headers)
                if resp.status_code == 200:
                    data = resp.json()
                    return data.get("data", [])
        except Exception as e:
            logger.warning(f"Error calling search_flights from Spring Boot: {e}")
        return []

    async def get_flight_by_id(self, flight_id: int) -> Optional[Dict[str, Any]]:
        url = f"{self.base_url}/flights/{flight_id}"
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(url, headers=self.headers)
                if resp.status_code == 200:
                    return resp.json().get("data")
        except Exception as e:
            logger.warning(f"Error fetching flight {flight_id}: {e}")
        return None

    async def get_booking_by_reference(self, pnr: str) -> Optional[Dict[str, Any]]:
        url = f"{self.base_url}/bookings/reference/{pnr}"
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(url, headers=self.headers)
                if resp.status_code == 200:
                    return resp.json().get("data")
        except Exception as e:
            logger.warning(f"Error fetching booking reference {pnr}: {e}")
        return None

    async def get_baggage_by_ref(self, ref: str) -> Optional[Dict[str, Any]]:
        url = f"{self.base_url}/baggage/ref/{ref}"
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(url, headers=self.headers)
                if resp.status_code == 200:
                    return resp.json().get("data")
        except Exception as e:
            logger.warning(f"Error fetching baggage ref {ref}: {e}")
        return None

    async def get_disruption_alternatives(self, flight_id: int) -> List[Dict[str, Any]]:
        url = f"{self.base_url}/disruptions/alternatives/{flight_id}"
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(url, headers=self.headers)
                if resp.status_code == 200:
                    return resp.json().get("data", [])
        except Exception as e:
            logger.warning(f"Error fetching disruption alternatives for flight {flight_id}: {e}")
        return []

    async def get_analytics_overview(self) -> Dict[str, Any]:
        url = f"{self.base_url}/admin/analytics/overview"
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(url, headers=self.headers)
                if resp.status_code == 200:
                    return resp.json().get("data", {})
        except Exception as e:
            logger.warning(f"Error fetching analytics overview: {e}")
        return {}

    async def get_popular_routes(self) -> List[Dict[str, Any]]:
        url = f"{self.base_url}/admin/analytics/routes"
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(url, headers=self.headers)
                if resp.status_code == 200:
                    return resp.json().get("data", [])
        except Exception as e:
            logger.warning(f"Error fetching popular routes: {e}")
        return []

    async def get_cancellation_stats(self) -> Dict[str, Any]:
        url = f"{self.base_url}/admin/analytics/cancellations"
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(url, headers=self.headers)
                if resp.status_code == 200:
                    return resp.json().get("data", {})
        except Exception as e:
            logger.warning(f"Error fetching cancellation stats: {e}")
        return {}

spring_client = SpringApiClient()
