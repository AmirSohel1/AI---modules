from typing import Dict, Any

def tool_explain_accessibility_services() -> Dict[str, Any]:
    """Retrieve wheelchair categories and airport accessibility guidelines."""
    return {
        "categories": [
            {"code": "WCHR", "name": "Wheelchair for Ramp", "description": "Can walk to seat, needs help for distance"},
            {"code": "WCHS", "name": "Wheelchair for Steps", "description": "Cannot climb stairs, can walk in cabin"},
            {"code": "WCHC", "name": "Wheelchair for Cabin", "description": "Complete onboard aisle chair assistance"}
        ],
        "cost": "FREE of charge across all airports",
        "noticeRequired": "Minimum 24 hours prior to flight departure"
    }
