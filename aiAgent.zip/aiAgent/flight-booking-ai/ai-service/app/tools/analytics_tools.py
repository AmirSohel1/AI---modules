from typing import Dict, Any, List
from app.services.spring_api_client import spring_client

async def tool_get_analytics_overview() -> Dict[str, Any]:
    """Retrieve verified SQL-backed operational KPIs and metrics."""
    return await spring_client.get_analytics_overview()

async def tool_get_popular_routes() -> List[Dict[str, Any]]:
    """Retrieve top booked flight routes."""
    return await spring_client.get_popular_routes()

async def tool_get_cancellation_stats() -> Dict[str, Any]:
    """Retrieve cancellation statistics."""
    return await spring_client.get_cancellation_stats()
