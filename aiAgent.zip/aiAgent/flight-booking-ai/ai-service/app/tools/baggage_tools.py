from typing import Dict, Any, Optional
from app.services.spring_api_client import spring_client

async def tool_get_baggage_status(case_ref: str) -> Optional[Dict[str, Any]]:
    """Retrieve baggage case tracking status by reference number."""
    return await spring_client.get_baggage_by_ref(case_ref)
