from typing import Dict, Any, Optional
from app.services.spring_api_client import spring_client

async def tool_get_booking_by_pnr(pnr: str) -> Optional[Dict[str, Any]]:
    """Retrieve passenger booking and ticket details by PNR reference."""
    return await spring_client.get_booking_by_reference(pnr)
