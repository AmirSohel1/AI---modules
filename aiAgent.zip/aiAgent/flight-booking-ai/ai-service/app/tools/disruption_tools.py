from typing import Dict, Any, List
from app.services.spring_api_client import spring_client

async def tool_get_disruption_alternatives(flight_id: int) -> List[Dict[str, Any]]:
    """Retrieve verified replacement flights from database for a delayed or cancelled flight."""
    return await spring_client.get_disruption_alternatives(flight_id)
