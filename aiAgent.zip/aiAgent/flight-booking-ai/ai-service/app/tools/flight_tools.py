from typing import Dict, Any, List, Optional
from app.services.spring_api_client import spring_client

async def tool_search_flights(source: Optional[str] = None, destination: Optional[str] = None,
                              travel_date: Optional[str] = None, max_budget: Optional[float] = None,
                              airline_code: Optional[str] = None, time_of_day: Optional[str] = None) -> List[Dict[str, Any]]:
    """Search available flights from MySQL business database via Spring Boot API."""
    return await spring_client.search_flights(source, destination, travel_date, max_budget, airline_code, time_of_day)

async def tool_get_flight_details(flight_id: int) -> Optional[Dict[str, Any]]:
    """Get accurate flight details by flight ID."""
    return await spring_client.get_flight_by_id(flight_id)
