import pytest
from unittest.mock import patch, AsyncMock
from app.agents.orchestrator import orchestrator_agent
from app.agents.recommendation_agent import recommendation_agent
from app.agents.feedback_agent import feedback_agent
from app.agents.single_agent import single_agent
from app.graph.workflow import multi_agent_workflow
from app.core.config import settings

def test_intent_classification():
    assert orchestrator_agent.classify_intent("Find flights from Mumbai to Delhi") == "FLIGHT_SEARCH_AND_RECOMMENDATION"
    assert orchestrator_agent.classify_intent("My flight was cancelled, what should I do?") == "DISRUPTION_AND_CANCELLATION"
    assert orchestrator_agent.classify_intent("My luggage has not arrived") == "BAGGAGE_ASSISTANCE"
    assert orchestrator_agent.classify_intent("I need wheelchair assistance at airport") == "ACCESSIBILITY_ASSISTANCE"
    assert orchestrator_agent.classify_intent("What is the total revenue this month?") == "ADMIN_ANALYTICS"
    assert orchestrator_agent.classify_intent("What is the cancellation refund policy?") == "KNOWLEDGE_RAG"

def test_recommendation_ranking():
    flights = [
        {"flightNumber": "FL-01", "basePrice": 6200, "durationMinutes": 120, "stops": 0, "airline": {"name": "Airline A"}},
        {"flightNumber": "FL-02", "basePrice": 4500, "durationMinutes": 140, "stops": 0, "airline": {"name": "Airline B"}},
        {"flightNumber": "FL-03", "basePrice": 7500, "durationMinutes": 110, "stops": 1, "airline": {"name": "Airline C"}},
    ]

    result = recommendation_agent.rank_and_explain(flights, "Find the cheapest flight")
    assert len(result["ranked"]) == 3
    # Cheapest flight should be ranked first
    assert result["ranked"][0]["flightNumber"] == "FL-02"
    assert "Lowest available fare" in result["reasoning"]

def test_feedback_sentiment_classification():
    pos = feedback_agent.analyze_feedback("Excellent service and on-time flight", 5)
    assert pos["sentiment"] == "POSITIVE"

    neg = feedback_agent.analyze_feedback("Flight was delayed by two hours with rude staff", 1)
    assert neg["sentiment"] == "NEGATIVE"
    assert neg["category"] in ["FLIGHT_DELAY", "STAFF_BEHAVIOR"]
    assert neg["urgency_score"] >= 8

@pytest.mark.asyncio
async def test_single_agent_execution():
    res = await single_agent.execute("What is my baggage allowance?", {"user_id": 1, "user_role": "PASSENGER"})
    assert "Cabin Baggage" in res["message"]
    assert len(res["activity"]) == 1
    assert res["activity"][0].agent_name == "Smart Flight Assistant"

@pytest.mark.asyncio
async def test_multi_agent_workflow():
    res = await multi_agent_workflow.run("I need wheelchair assistance", {"user_id": 1, "user_role": "PASSENGER"})
    assert "Wheelchair" in res["message"]
    activity_names = [a.agent_name for a in res["activity"]]
    assert "Flight Orchestrator Agent" in activity_names
    assert "Passenger Accessibility Assistant Agent" in activity_names

@pytest.mark.asyncio
@patch("app.agents.flight_search_agent.tool_search_flights", new_callable=AsyncMock)
async def test_multi_agent_flight_search(mock_search):
    mock_search.return_value = [
        {"id": 1, "flightNumber": "AI-806", "basePrice": 5400, "durationMinutes": 135, "stops": 0,
         "airline": {"name": "Air India", "code": "AI"},
         "sourceAirport": {"city": "Mumbai", "code": "BOM"},
         "destinationAirport": {"city": "Delhi", "code": "DEL"}}
    ]
    res = await multi_agent_workflow.run("Find flights from Mumbai to Delhi under 6000", {"user_id": 1, "user_role": "PASSENGER"})
    assert res["flight_cards"] is not None
    assert len(res["flight_cards"]) >= 1
    assert res["flight_cards"][0]["flightNumber"] == "AI-806"

def test_demo_mode_active():
    assert settings.is_demo_mode is True
