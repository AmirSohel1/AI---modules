from app.services.rag_service import rag_service

def test_rag_retrieval_cancellation():
    citations = rag_service.retrieve("How much fee is deducted if I cancel flight?", top_k=2)
    assert len(citations) > 0
    assert any("cancellation" in c.document_title.lower() for c in citations)
    assert any("2,500" in c.snippet or "refund" in c.snippet.lower() for c in citations)

def test_rag_retrieval_baggage():
    citations = rag_service.retrieve("What is cabin and check-in baggage weight limit?", top_k=2)
    assert len(citations) > 0
    assert any("baggage" in c.document_title.lower() for c in citations)
    assert any("7 kg" in c.snippet or "15 kg" in c.snippet for c in citations)

def test_rag_custom_document():
    rag_service.add_document("VIP Lounge Access Guidelines", "AIRPORT_SERVICE", "lounge_policy.txt", "Complimentary lounge access is provided for all Business class passengers.")
    citations = rag_service.retrieve("Who gets complimentary lounge access?", top_k=1)
    assert len(citations) > 0
    assert citations[0].document_title == "VIP Lounge Access Guidelines"
