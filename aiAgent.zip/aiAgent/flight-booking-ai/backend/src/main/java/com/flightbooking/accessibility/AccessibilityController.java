package com.flightbooking.accessibility;

import com.flightbooking.common.ApiResponse;
import com.flightbooking.security.UserPrincipal;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/accessibility")
@RequiredArgsConstructor
public class AccessibilityController {

    private final AccessibilityService accessibilityService;

    @PostMapping
    public ResponseEntity<ApiResponse<AccessibilityRequestDto>> createRequest(
            @RequestBody Map<String, Object> body,
            @AuthenticationPrincipal UserPrincipal user) {

        Long bookingId = ((Number) body.get("bookingId")).longValue();
        String serviceType = (String) body.get("serviceType");
        String details = (String) body.get("details");

        AccessibilityRequestDto result = accessibilityService.createRequest(user.getId(), bookingId, serviceType, details);
        return ResponseEntity.ok(ApiResponse.ok("Accessibility request submitted successfully", result));
    }

    @GetMapping("/my")
    public ResponseEntity<ApiResponse<List<AccessibilityRequestDto>>> getMyRequests(@AuthenticationPrincipal UserPrincipal user) {
        return ResponseEntity.ok(ApiResponse.ok(accessibilityService.getMyRequests(user.getId())));
    }

    @GetMapping("/staff/all")
    @PreAuthorize("hasAnyRole('STAFF', 'ADMIN')")
    public ResponseEntity<ApiResponse<List<AccessibilityRequestDto>>> getAllStaffRequests() {
        return ResponseEntity.ok(ApiResponse.ok(accessibilityService.getAllRequests()));
    }

    @PatchMapping("/staff/{id}/status")
    @PreAuthorize("hasAnyRole('STAFF', 'ADMIN')")
    public ResponseEntity<ApiResponse<AccessibilityRequestDto>> updateStatus(
            @PathVariable Long id,
            @RequestBody Map<String, String> body,
            @AuthenticationPrincipal UserPrincipal user) {

        String status = body.get("status");
        Long staffId = body.get("staffId") != null ? Long.parseLong(body.get("staffId")) : user.getId();

        return ResponseEntity.ok(ApiResponse.ok("Status updated", accessibilityService.updateStatus(id, status, staffId)));
    }
}
