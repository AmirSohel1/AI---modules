package com.flightbooking.accessibility;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccessibilityRequestDto {
    private Long id;
    private Long userId;
    private String passengerName;
    private Long bookingId;
    private String bookingReference;
    private String flightNumber;
    private String serviceType;
    private String details;
    private String status;
    private LocalDateTime requestedAt;
    private Long assignedStaffId;
    private String assignedStaffName;
    private LocalDateTime updatedAt;

    public static AccessibilityRequestDto fromEntity(AccessibilityRequest a) {
        return AccessibilityRequestDto.builder()
                .id(a.getId())
                .userId(a.getUser().getId())
                .passengerName(a.getUser().getFullName())
                .bookingId(a.getBooking().getId())
                .bookingReference(a.getBooking().getBookingReference())
                .flightNumber(a.getBooking().getFlight().getFlightNumber())
                .serviceType(a.getServiceType())
                .details(a.getDetails())
                .status(a.getStatus())
                .requestedAt(a.getRequestedAt())
                .assignedStaffId(a.getAssignedStaff() != null ? a.getAssignedStaff().getId() : null)
                .assignedStaffName(a.getAssignedStaff() != null ? a.getAssignedStaff().getFullName() : "Unassigned")
                .updatedAt(a.getUpdatedAt())
                .build();
    }
}
