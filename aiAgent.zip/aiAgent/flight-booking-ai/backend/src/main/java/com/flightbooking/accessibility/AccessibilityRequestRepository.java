package com.flightbooking.accessibility;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AccessibilityRequestRepository extends JpaRepository<AccessibilityRequest, Long> {
    List<AccessibilityRequest> findByUserIdOrderByRequestedAtDesc(Long userId);
    List<AccessibilityRequest> findByStatus(String status);
    long countByStatus(String status);
}
