package com.flightbooking.accessibility;

import com.flightbooking.booking.Booking;
import com.flightbooking.booking.BookingRepository;
import com.flightbooking.exception.ResourceNotFoundException;
import com.flightbooking.notification.NotificationService;
import com.flightbooking.user.User;
import com.flightbooking.user.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class AccessibilityService {

    private final AccessibilityRequestRepository requestRepository;
    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;
    private final NotificationService notificationService;

    @Transactional
    public AccessibilityRequestDto createRequest(Long userId, Long bookingId, String serviceType, String details) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userId));

        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found: " + bookingId));

        AccessibilityRequest request = AccessibilityRequest.builder()
                .user(user)
                .booking(booking)
                .serviceType(serviceType.toUpperCase())
                .details(details)
                .status("PENDING")
                .build();

        AccessibilityRequest saved = requestRepository.save(request);

        notificationService.createNotification(
                userId,
                "Special Assistance Request Submitted",
                "Your request for " + serviceType + " assistance on flight " +
                        booking.getFlight().getFlightNumber() + " has been received. Our team will coordinate your support.",
                "ACCESSIBILITY_REQUEST_UPDATE",
                String.valueOf(saved.getId())
        );

        return AccessibilityRequestDto.fromEntity(saved);
    }

    @Transactional(readOnly = true)
    public List<AccessibilityRequestDto> getMyRequests(Long userId) {
        return requestRepository.findByUserIdOrderByRequestedAtDesc(userId).stream()
                .map(AccessibilityRequestDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<AccessibilityRequestDto> getAllRequests() {
        return requestRepository.findAll().stream()
                .map(AccessibilityRequestDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Transactional
    public AccessibilityRequestDto updateStatus(Long requestId, String status, Long staffId) {
        AccessibilityRequest request = requestRepository.findById(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Request not found: " + requestId));

        request.setStatus(status.toUpperCase());
        if (staffId != null) {
            User staff = userRepository.findById(staffId).orElse(null);
            request.setAssignedStaff(staff);
        }

        AccessibilityRequest saved = requestRepository.save(request);

        notificationService.createNotification(
                request.getUser().getId(),
                "Special Assistance Update",
                "Your request for " + request.getServiceType() + " status is now: " + status,
                "ACCESSIBILITY_REQUEST_UPDATE",
                String.valueOf(saved.getId())
        );

        return AccessibilityRequestDto.fromEntity(saved);
    }
}
