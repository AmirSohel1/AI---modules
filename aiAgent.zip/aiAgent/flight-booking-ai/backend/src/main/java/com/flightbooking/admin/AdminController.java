package com.flightbooking.admin;

import com.flightbooking.common.ApiResponse;
import com.flightbooking.exception.ResourceNotFoundException;
import com.flightbooking.staff.StaffProfile;
import com.flightbooking.staff.StaffRepository;
import com.flightbooking.user.User;
import com.flightbooking.user.UserDto;
import com.flightbooking.user.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminController {

    private final UserRepository userRepository;
    private final StaffRepository staffRepository;
    private final PasswordEncoder passwordEncoder;

    @GetMapping("/users")
    public ResponseEntity<ApiResponse<List<UserDto>>> getAllUsers() {
        List<UserDto> list = userRepository.findAll().stream()
                .map(UserDto::fromEntity)
                .collect(Collectors.toList());
        return ResponseEntity.ok(ApiResponse.ok(list));
    }

    @PatchMapping("/users/{id}/status")
    @Transactional
    public ResponseEntity<ApiResponse<UserDto>> updateUserStatus(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id));

        String newStatus = body.getOrDefault("status", "ACTIVE");
        user.setStatus(newStatus.toUpperCase());
        User saved = userRepository.save(user);

        return ResponseEntity.ok(ApiResponse.ok("User status updated", UserDto.fromEntity(saved)));
    }

    @PostMapping("/staff")
    @Transactional
    public ResponseEntity<ApiResponse<UserDto>> createStaff(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        String email = body.get("email");
        String fullName = body.get("fullName");
        String password = body.getOrDefault("password", "Staff@123");
        String department = body.getOrDefault("department", "Ground Operations");
        String designation = body.getOrDefault("designation", "Operations Officer");

        User user = User.builder()
                .username(username)
                .email(email)
                .passwordHash(passwordEncoder.encode(password))
                .fullName(fullName)
                .role("STAFF")
                .status("ACTIVE")
                .build();
        User savedUser = userRepository.save(user);

        StaffProfile profile = StaffProfile.builder()
                .user(savedUser)
                .employeeId("EMP-" + (2000 + savedUser.getId()))
                .department(department)
                .designation(designation)
                .shift("General")
                .build();
        staffRepository.save(profile);

        return ResponseEntity.ok(ApiResponse.ok("Staff member created successfully", UserDto.fromEntity(savedUser)));
    }

    @GetMapping("/settings")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getSettings() {
        Map<String, Object> map = new HashMap<>();
        map.put("systemName", "AI-Powered Flight Booking & Passenger Assistance Platform");
        map.put("version", "1.0.0");
        map.put("currency", "INR");
        map.put("aiProvider", "OpenAI / Local Deterministic Agent");
        map.put("singleAgentAvailable", true);
        map.put("multiAgentAvailable", true);
        map.put("ragEnabled", true);
        return ResponseEntity.ok(ApiResponse.ok(map));
    }
}
