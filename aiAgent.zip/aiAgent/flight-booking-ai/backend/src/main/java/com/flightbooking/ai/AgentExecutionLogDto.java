package com.flightbooking.ai;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AgentExecutionLogDto {
    private String agentName;
    private String status; // PENDING, RUNNING, COMPLETED, FAILED
    private String inputSummary;
    private String outputSummary;
    private Long durationMs;
    private Integer order;
}
