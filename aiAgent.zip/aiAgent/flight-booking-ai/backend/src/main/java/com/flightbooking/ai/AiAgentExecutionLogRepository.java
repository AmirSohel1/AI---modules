package com.flightbooking.ai;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AiAgentExecutionLogRepository extends JpaRepository<AiAgentExecutionLog, Long> {
    List<AiAgentExecutionLog> findTop50ByOrderByCreatedAtDesc();
    List<AiAgentExecutionLog> findByConversationIdOrderByExecutionOrderAsc(Long conversationId);

    @Query("SELECT l.mode, COUNT(l), AVG(l.executionDurationMs) FROM AiAgentExecutionLog l GROUP BY l.mode")
    List<Object[]> getModeComparisonStats();

    @Query("SELECT l.agentName, COUNT(l), AVG(l.executionDurationMs) FROM AiAgentExecutionLog l GROUP BY l.agentName")
    List<Object[]> getAgentPerformanceStats();
}
