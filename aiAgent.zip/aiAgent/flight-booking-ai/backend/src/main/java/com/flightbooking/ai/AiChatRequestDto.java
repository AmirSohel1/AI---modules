package com.flightbooking.ai;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AiChatRequestDto {
    private Long conversationId;

    @NotBlank(message = "Message content is required")
    private String message;

    @Builder.Default
    private String mode = "MULTI_AGENT"; // SINGLE_AGENT, MULTI_AGENT
}
