package com.flightbooking.ai;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AiChatResponseDto {
    private Long conversationId;
    private String mode;
    private String message;
    private Boolean isDemoMode;
    private List<AgentExecutionLogDto> agentActivity;
    private List<Map<String, Object>> flightCards;
    private Map<String, Object> disruptionCard;
    private Map<String, Object> baggageCard;
    private List<String> sourceCitations;
    private List<String> suggestedFollowUps;
}
