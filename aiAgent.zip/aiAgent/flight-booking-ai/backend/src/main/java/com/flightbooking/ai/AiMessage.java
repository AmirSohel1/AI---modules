package com.flightbooking.ai;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "ai_messages")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AiMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "conversation_id", nullable = false)
    private AiConversation conversation;

    @Column(nullable = false, length = 30)
    private String sender; // USER, ASSISTANT, SYSTEM

    @Column(nullable = false, columnDefinition = "LONGTEXT")
    private String content;

    @Column(name = "message_metadata", columnDefinition = "LONGTEXT")
    private String messageMetadata; // Stores JSON of flight cards, agent traces, citations

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
}
