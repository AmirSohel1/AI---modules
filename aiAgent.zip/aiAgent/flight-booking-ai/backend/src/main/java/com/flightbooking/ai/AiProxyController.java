package com.flightbooking.ai;

import com.flightbooking.common.ApiResponse;
import com.flightbooking.security.UserPrincipal;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/ai")
@RequiredArgsConstructor
public class AiProxyController {

    private final AiService aiService;

    @PostMapping("/chat")
    public ResponseEntity<ApiResponse<AiChatResponseDto>> chat(
            @AuthenticationPrincipal UserPrincipal user,
            @Valid @RequestBody AiChatRequestDto request) {

        AiChatResponseDto response = aiService.processChat(
                user.getId(),
                user.getRole(),
                user.getFullName(),
                user.getEmail(),
                request
        );
        return ResponseEntity.ok(ApiResponse.ok(response));
    }

    @GetMapping("/conversations")
    public ResponseEntity<ApiResponse<List<AiConversation>>> getConversations(@AuthenticationPrincipal UserPrincipal user) {
        return ResponseEntity.ok(ApiResponse.ok(aiService.getUserConversations(user.getId())));
    }

    @GetMapping("/conversations/{id}/messages")
    public ResponseEntity<ApiResponse<List<AiMessage>>> getMessages(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok(aiService.getConversationMessages(id)));
    }

    @DeleteMapping("/conversations/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteConversation(@PathVariable Long id) {
        aiService.deleteConversation(id);
        return ResponseEntity.ok(ApiResponse.ok("Conversation deleted", null));
    }

    @GetMapping("/modes")
    public ResponseEntity<ApiResponse<List<Map<String, String>>>> getAiModes() {
        return ResponseEntity.ok(ApiResponse.ok(List.of(
                Map.of("id", "SINGLE_AGENT", "name", "Single-Agent Mode", "description", "Unified Smart Flight Assistant using direct tool calls"),
                Map.of("id", "MULTI_AGENT", "name", "Multi-Agent Mode", "description", "LangGraph Supervisor Orchestrator delegating across 8 specialized agents")
        )));
    }

    @GetMapping("/admin/agent-logs")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<AiAgentExecutionLog>>> getAgentExecutionLogs() {
        return ResponseEntity.ok(ApiResponse.ok(aiService.getRecentExecutionLogs()));
    }

    @GetMapping("/admin/usage")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getAiUsageAnalytics() {
        return ResponseEntity.ok(ApiResponse.ok(aiService.getAiUsageAnalytics()));
    }

    @GetMapping("/admin/knowledge")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<KnowledgeDocument>>> getKnowledgeDocs() {
        return ResponseEntity.ok(ApiResponse.ok(aiService.getAllKnowledgeDocuments()));
    }

    @PostMapping("/admin/knowledge")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<KnowledgeDocument>> createKnowledgeDoc(@RequestBody Map<String, String> body) {
        String title = body.get("title");
        String category = body.get("category");
        String filename = body.get("filename");
        String text = body.get("text");

        KnowledgeDocument doc = aiService.saveKnowledgeDocument(title, category, filename, text);
        return ResponseEntity.ok(ApiResponse.ok("Document uploaded and saved to knowledge base", doc));
    }

    @DeleteMapping("/admin/knowledge/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<Void>> deleteKnowledgeDoc(@PathVariable Long id) {
        aiService.deleteKnowledgeDocument(id);
        return ResponseEntity.ok(ApiResponse.ok("Document deleted from knowledge base", null));
    }

    @GetMapping("/health")
    public ResponseEntity<ApiResponse<Map<String, String>>> health() {
        return ResponseEntity.ok(ApiResponse.ok(Map.of("status", "UP", "service", "AI Proxy Service")));
    }
}
