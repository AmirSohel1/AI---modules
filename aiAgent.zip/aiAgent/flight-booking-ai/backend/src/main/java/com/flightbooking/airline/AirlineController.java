package com.flightbooking.airline;

import com.flightbooking.common.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/airlines")
@RequiredArgsConstructor
public class AirlineController {

    private final AirlineRepository airlineRepository;

    @GetMapping
    public ResponseEntity<ApiResponse<List<Airline>>> getAllAirlines() {
        return ResponseEntity.ok(ApiResponse.ok(airlineRepository.findAll()));
    }
}
