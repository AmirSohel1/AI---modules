package com.flightbooking.airport;

import com.flightbooking.common.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/airports")
@RequiredArgsConstructor
public class AirportController {

    private final AirportRepository airportRepository;

    @GetMapping
    public ResponseEntity<ApiResponse<List<Airport>>> getAllAirports() {
        return ResponseEntity.ok(ApiResponse.ok(airportRepository.findAll()));
    }
}
