package com.flightbooking.analytics;

import com.flightbooking.common.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin/analytics")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminAnalyticsController {

    private final AdminAnalyticsService analyticsService;

    @GetMapping("/overview")
    public ResponseEntity<ApiResponse<AnalyticsOverviewDto>> getOverview() {
        return ResponseEntity.ok(ApiResponse.ok(analyticsService.getOverview()));
    }

    @GetMapping("/routes")
    public ResponseEntity<ApiResponse<List<RouteBookingDto>>> getPopularRoutes() {
        return ResponseEntity.ok(ApiResponse.ok(analyticsService.getPopularRoutes()));
    }

    @GetMapping("/bookings")
    public ResponseEntity<ApiResponse<List<MonthlyTrendDto>>> getMonthlyTrends() {
        return ResponseEntity.ok(ApiResponse.ok(analyticsService.getMonthlyTrends()));
    }

    @GetMapping("/revenue")
    public ResponseEntity<ApiResponse<List<MonthlyTrendDto>>> getRevenueTrends() {
        return ResponseEntity.ok(ApiResponse.ok(analyticsService.getMonthlyTrends()));
    }

    @GetMapping("/cancellations")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getCancellationStats() {
        return ResponseEntity.ok(ApiResponse.ok(analyticsService.getCancellationStats()));
    }
}
