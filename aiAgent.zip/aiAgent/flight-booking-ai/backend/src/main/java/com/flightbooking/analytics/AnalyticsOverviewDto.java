package com.flightbooking.analytics;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnalyticsOverviewDto {
    private long totalPassengers;
    private long totalFlights;
    private long totalBookings;
    private BigDecimal totalRevenue;
    private long activeFlights;
    private long cancelledFlights;
    private long delayedFlights;
    private long pendingRefundRequests;
    private long pendingComplaints;
    private Double averageRating;
}
