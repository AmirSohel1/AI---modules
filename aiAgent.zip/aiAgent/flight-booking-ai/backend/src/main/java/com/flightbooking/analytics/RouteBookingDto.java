package com.flightbooking.analytics;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RouteBookingDto {
    private String route;
    private String sourceCity;
    private String destCity;
    private long bookingCount;
    private BigDecimal totalRevenue;
}
