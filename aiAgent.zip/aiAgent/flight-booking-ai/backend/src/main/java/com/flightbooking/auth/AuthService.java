package com.flightbooking.auth;

import com.flightbooking.exception.BadRequestException;
import com.flightbooking.passenger.Passenger;
import com.flightbooking.passenger.PassengerPreference;
import com.flightbooking.passenger.PassengerPreferenceRepository;
import com.flightbooking.passenger.PassengerRepository;
import com.flightbooking.security.JwtTokenProvider;
import com.flightbooking.user.Role;
import com.flightbooking.user.RoleRepository;
import com.flightbooking.user.User;
import com.flightbooking.user.UserDto;
import com.flightbooking.user.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PassengerRepository passengerRepository;
    private final PassengerPreferenceRepository preferenceRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider tokenProvider;

    @Transactional
    public AuthResponse login(LoginRequest loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.getUsername(),
                        loginRequest.getPassword()
                )
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = tokenProvider.generateToken(authentication);

        User user = userRepository.findByUsername(loginRequest.getUsername())
                .or(() -> userRepository.findByEmail(loginRequest.getUsername()))
                .orElseThrow(() -> new BadRequestException("User not found"));

        return AuthResponse.builder()
                .token(jwt)
                .user(UserDto.fromEntity(user))
                .build();
    }

    @Transactional
    public AuthResponse register(RegisterRequest registerRequest) {
        if (userRepository.existsByUsername(registerRequest.getUsername())) {
            throw new BadRequestException("Username is already taken");
        }

        if (userRepository.existsByEmail(registerRequest.getEmail())) {
            throw new BadRequestException("Email is already in use");
        }

        String assignedRole = "PASSENGER";
        if (registerRequest.getRole() != null && !registerRequest.getRole().isBlank()) {
            String roleUpper = registerRequest.getRole().toUpperCase();
            if (roleUpper.equals("STAFF") || roleUpper.equals("ADMIN")) {
                assignedRole = roleUpper;
            }
        }

        User user = User.builder()
                .username(registerRequest.getUsername())
                .email(registerRequest.getEmail())
                .passwordHash(passwordEncoder.encode(registerRequest.getPassword()))
                .fullName(registerRequest.getFullName())
                .phone(registerRequest.getPhone())
                .role(assignedRole)
                .status("ACTIVE")
                .build();

        User savedUser = userRepository.save(user);

        // If passenger, create default profile & preferences
        if ("PASSENGER".equalsIgnoreCase(assignedRole)) {
            Passenger passenger = Passenger.builder()
                    .user(savedUser)
                    .nationality("Indian")
                    .build();
            passengerRepository.save(passenger);

            PassengerPreference preference = PassengerPreference.builder()
                    .user(savedUser)
                    .preferredSeatType("AISLE")
                    .preferredClass("ECONOMY")
                    .mealPreference("VEG")
                    .preferredDepartureTime("MORNING")
                    .consentGiven(true)
                    .build();
            preferenceRepository.save(preference);
        }

        String jwt = tokenProvider.generateTokenFromUsername(
                savedUser.getUsername(),
                savedUser.getId(),
                savedUser.getEmail(),
                savedUser.getRole()
        );

        return AuthResponse.builder()
                .token(jwt)
                .user(UserDto.fromEntity(savedUser))
                .build();
    }
}
