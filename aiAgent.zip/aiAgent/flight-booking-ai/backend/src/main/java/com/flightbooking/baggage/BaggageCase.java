package com.flightbooking.baggage;

import com.flightbooking.booking.Booking;
import com.flightbooking.flight.Flight;
import com.flightbooking.passenger.Passenger;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "baggage_cases")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BaggageCase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "booking_id", nullable = false)
    private Booking booking;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "passenger_id")
    private Passenger passenger;

    @Column(name = "case_reference", nullable = false, unique = true, length = 50)
    private String caseReference;

    @Column(name = "case_type", nullable = false, length = 30)
    private String caseType; // MISSING, DELAYED, DAMAGED

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "flight_id", nullable = false)
    private Flight flight;

    @Column(name = "tag_number", nullable = false, length = 50)
    private String tagNumber;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(nullable = false, length = 30)
    @Builder.Default
    private String status = "REPORTED"; // REPORTED, INVESTIGATING, LOCATED, IN_TRANSIT, DELIVERED, CLOSED

    @CreationTimestamp
    @Column(name = "reported_at", updatable = false)
    private LocalDateTime reportedAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "internal_notes", columnDefinition = "TEXT")
    private String internalNotes;
}
