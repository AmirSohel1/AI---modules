package com.flightbooking.baggage;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BaggageCaseDto {
    private Long id;
    private Long bookingId;
    private String bookingReference;
    private String caseReference;
    private String caseType;
    private Long flightId;
    private String flightNumber;
    private String tagNumber;
    private String description;
    private String status;
    private LocalDateTime reportedAt;
    private LocalDateTime updatedAt;
    private String internalNotes;

    public static BaggageCaseDto fromEntity(BaggageCase b) {
        return BaggageCaseDto.builder()
                .id(b.getId())
                .bookingId(b.getBooking().getId())
                .bookingReference(b.getBooking().getBookingReference())
                .caseReference(b.getCaseReference())
                .caseType(b.getCaseType())
                .flightId(b.getFlight().getId())
                .flightNumber(b.getFlight().getFlightNumber())
                .tagNumber(b.getTagNumber())
                .description(b.getDescription())
                .status(b.getStatus())
                .reportedAt(b.getReportedAt())
                .updatedAt(b.getUpdatedAt())
                .internalNotes(b.getInternalNotes())
                .build();
    }
}
