package com.flightbooking.baggage;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BaggageCaseRepository extends JpaRepository<BaggageCase, Long> {
    Optional<BaggageCase> findByCaseReference(String caseReference);
    List<BaggageCase> findByBookingUserId(Long userId);
    List<BaggageCase> findByStatus(String status);
    long countByStatus(String status);
}
