package com.flightbooking.baggage;

import com.flightbooking.common.ApiResponse;
import com.flightbooking.security.UserPrincipal;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/baggage")
@RequiredArgsConstructor
public class BaggageController {

    private final BaggageService baggageService;

    @PostMapping
    public ResponseEntity<ApiResponse<BaggageCaseDto>> createBaggageCase(
            @RequestBody Map<String, Object> body,
            @AuthenticationPrincipal UserPrincipal user) {

        Long bookingId = ((Number) body.get("bookingId")).longValue();
        String caseType = (String) body.getOrDefault("caseType", "DELAYED");
        String tagNumber = (String) body.get("tagNumber");
        String description = (String) body.get("description");

        BaggageCaseDto result = baggageService.createBaggageCase(bookingId, caseType, tagNumber, description);
        return ResponseEntity.ok(ApiResponse.ok("Baggage case registered successfully", result));
    }

    @GetMapping("/my")
    public ResponseEntity<ApiResponse<List<BaggageCaseDto>>> getMyBaggage(@AuthenticationPrincipal UserPrincipal user) {
        return ResponseEntity.ok(ApiResponse.ok(baggageService.getMyBaggageCases(user.getId())));
    }

    @GetMapping("/ref/{ref}")
    public ResponseEntity<ApiResponse<BaggageCaseDto>> getByReference(@PathVariable String ref) {
        return ResponseEntity.ok(ApiResponse.ok(baggageService.getBaggageByReference(ref)));
    }

    @GetMapping("/all")
    @PreAuthorize("hasAnyRole('STAFF', 'ADMIN')")
    public ResponseEntity<ApiResponse<List<BaggageCaseDto>>> getAllBaggage() {
        return ResponseEntity.ok(ApiResponse.ok(baggageService.getAllBaggageCases()));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('STAFF', 'ADMIN')")
    public ResponseEntity<ApiResponse<BaggageCaseDto>> updateStatus(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {
        String status = body.get("status");
        String notes = body.get("internalNotes");
        return ResponseEntity.ok(ApiResponse.ok("Status updated", baggageService.updateStatus(id, status, notes)));
    }
}
