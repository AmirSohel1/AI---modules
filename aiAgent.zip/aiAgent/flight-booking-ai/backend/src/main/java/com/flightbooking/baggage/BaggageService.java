package com.flightbooking.baggage;

import com.flightbooking.booking.Booking;
import com.flightbooking.booking.BookingRepository;
import com.flightbooking.exception.ResourceNotFoundException;
import com.flightbooking.notification.NotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BaggageService {

    private final BaggageCaseRepository baggageRepository;
    private final BookingRepository bookingRepository;
    private final NotificationService notificationService;

    private final Random random = new Random();

    @Transactional
    public BaggageCaseDto createBaggageCase(Long bookingId, String caseType, String tagNumber, String description) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found: " + bookingId));

        String airportCode = booking.getFlight().getSourceAirport().getCode();
        String ref = "BAG-" + airportCode + "-" + (1000 + random.nextInt(9000));

        BaggageCase bc = BaggageCase.builder()
                .booking(booking)
                .caseReference(ref)
                .caseType(caseType.toUpperCase())
                .flight(booking.getFlight())
                .tagNumber(tagNumber != null && !tagNumber.isBlank() ? tagNumber : "TAG-" + (10000 + random.nextInt(90000)))
                .description(description)
                .status("REPORTED")
                .internalNotes("Case opened via passenger assistance system")
                .build();

        BaggageCase saved = baggageRepository.save(bc);

        notificationService.createNotification(
                booking.getUser().getId(),
                "Baggage Case Opened: " + ref,
                "Your " + caseType.toLowerCase() + " baggage report has been registered. Reference: " + ref + ". Our ground staff is investigating.",
                "BAGGAGE_UPDATE",
                ref
        );

        return BaggageCaseDto.fromEntity(saved);
    }

    @Transactional(readOnly = true)
    public List<BaggageCaseDto> getMyBaggageCases(Long userId) {
        return baggageRepository.findByBookingUserId(userId).stream()
                .map(BaggageCaseDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public BaggageCaseDto getBaggageByReference(String ref) {
        BaggageCase bc = baggageRepository.findByCaseReference(ref)
                .orElseThrow(() -> new ResourceNotFoundException("Baggage case not found: " + ref));
        return BaggageCaseDto.fromEntity(bc);
    }

    @Transactional(readOnly = true)
    public List<BaggageCaseDto> getAllBaggageCases() {
        return baggageRepository.findAll().stream()
                .map(BaggageCaseDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Transactional
    public BaggageCaseDto updateStatus(Long id, String status, String internalNotes) {
        BaggageCase bc = baggageRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Baggage case not found: " + id));

        bc.setStatus(status.toUpperCase());
        if (internalNotes != null) {
            bc.setInternalNotes(internalNotes);
        }
        BaggageCase saved = baggageRepository.save(bc);

        notificationService.createNotification(
                bc.getBooking().getUser().getId(),
                "Baggage Case Update: " + bc.getCaseReference(),
                "Status updated to: " + bc.getStatus() + (internalNotes != null ? " - " + internalNotes : ""),
                "BAGGAGE_UPDATE",
                bc.getCaseReference()
        );

        return BaggageCaseDto.fromEntity(saved);
    }
}
