package com.flightbooking.booking;

import com.flightbooking.common.ApiResponse;
import com.flightbooking.security.UserPrincipal;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;

    @PostMapping
    public ResponseEntity<ApiResponse<BookingResponseDto>> createBooking(
            @AuthenticationPrincipal UserPrincipal user,
            @Valid @RequestBody BookingRequestDto request) {
        BookingResponseDto response = bookingService.createBooking(user.getId(), request);
        return ResponseEntity.ok(ApiResponse.ok("Booking confirmed successfully", response));
    }

    @GetMapping("/my")
    public ResponseEntity<ApiResponse<List<BookingResponseDto>>> getMyBookings(@AuthenticationPrincipal UserPrincipal user) {
        return ResponseEntity.ok(ApiResponse.ok(bookingService.getMyBookings(user.getId())));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<BookingResponseDto>> getBookingById(
            @PathVariable Long id,
            @AuthenticationPrincipal UserPrincipal user) {
        return ResponseEntity.ok(ApiResponse.ok(bookingService.getBookingById(id, user.getId(), user.getRole())));
    }

    @GetMapping("/reference/{pnr}")
    public ResponseEntity<ApiResponse<BookingResponseDto>> getBookingByReference(@PathVariable String pnr) {
        return ResponseEntity.ok(ApiResponse.ok(bookingService.getBookingByReference(pnr)));
    }

    @GetMapping("/{id}/ticket")
    public ResponseEntity<byte[]> downloadTicket(
            @PathVariable Long id,
            @AuthenticationPrincipal UserPrincipal user) {
        byte[] pdfBytes = bookingService.generateTicketPdf(id, user.getId(), user.getRole());

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Ticket-" + id + ".pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdfBytes);
    }

    @GetMapping("/all")
    @PreAuthorize("hasAnyRole('STAFF', 'ADMIN')")
    public ResponseEntity<ApiResponse<List<BookingResponseDto>>> getAllBookings() {
        return ResponseEntity.ok(ApiResponse.ok(bookingService.getAllBookings()));
    }
}
