package com.flightbooking.booking;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    Optional<Booking> findByBookingReference(String bookingReference);
    List<Booking> findByUserIdOrderByCreatedAtDesc(Long userId);
    List<Booking> findByFlightId(Long flightId);
    long countByStatus(String status);

    @Query("SELECT b FROM Booking b WHERE b.flight.id = :flightId AND b.status = 'CONFIRMED'")
    List<Booking> findConfirmedBookingsByFlightId(@Param("flightId") Long flightId);

    @Query("SELECT COUNT(b) FROM Booking b WHERE b.createdAt >= :since")
    long countBookingsSince(@Param("since") LocalDateTime since);

    @Query("SELECT SUM(b.totalAmount) FROM Booking b WHERE b.status = 'CONFIRMED'")
    Double sumTotalRevenue();
}
