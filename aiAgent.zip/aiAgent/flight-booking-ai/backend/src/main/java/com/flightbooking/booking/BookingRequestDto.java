package com.flightbooking.booking;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BookingRequestDto {

    @NotNull(message = "Flight ID is required")
    private Long flightId;

    @NotNull(message = "Travel date is required")
    private LocalDate travelDate;

    @NotBlank(message = "Contact email is required")
    @Email(message = "Must be a valid email")
    private String contactEmail;

    @NotBlank(message = "Contact phone is required")
    private String contactPhone;

    @NotEmpty(message = "At least one passenger is required")
    private List<PassengerDetailDto> passengers;

    private String paymentMethod; // UPI, CARD, NETBANKING

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PassengerDetailDto {
        @NotBlank(message = "Passenger name is required")
        private String fullName;

        @NotNull(message = "Age is required")
        private Integer age;

        @NotBlank(message = "Gender is required")
        private String gender;

        @NotBlank(message = "Seat number is required")
        private String seatNumber;
    }
}
