package com.flightbooking.booking;

import com.flightbooking.flight.FlightDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BookingResponseDto {
    private Long id;
    private String bookingReference;
    private Long userId;
    private String userName;
    private FlightDto flight;
    private LocalDateTime bookingDate;
    private LocalDate travelDate;
    private BigDecimal totalAmount;
    private String status;
    private String contactEmail;
    private String contactPhone;
    private List<PassengerItemDto> passengers;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PassengerItemDto {
        private Long id;
        private String fullName;
        private Integer age;
        private String gender;
        private String seatNumber;
        private String ticketNumber;
    }

    public static BookingResponseDto fromEntity(Booking b) {
        return BookingResponseDto.builder()
                .id(b.getId())
                .bookingReference(b.getBookingReference())
                .userId(b.getUser() != null ? b.getUser().getId() : null)
                .userName(b.getUser() != null ? b.getUser().getFullName() : null)
                .flight(b.getFlight() != null ? FlightDto.fromEntity(b.getFlight(), null) : null)
                .bookingDate(b.getBookingDate())
                .travelDate(b.getTravelDate())
                .totalAmount(b.getTotalAmount())
                .status(b.getStatus())
                .contactEmail(b.getContactEmail())
                .contactPhone(b.getContactPhone())
                .passengers(b.getPassengers() != null ? b.getPassengers().stream()
                        .map(p -> PassengerItemDto.builder()
                                .id(p.getId())
                                .fullName(p.getFullName())
                                .age(p.getAge())
                                .gender(p.getGender())
                                .seatNumber(p.getSeatNumber())
                                .ticketNumber(p.getTicketNumber())
                                .build())
                        .collect(Collectors.toList()) : List.of())
                .build();
    }
}
