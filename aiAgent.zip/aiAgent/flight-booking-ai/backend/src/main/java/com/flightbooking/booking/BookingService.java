package com.flightbooking.booking;

import com.flightbooking.exception.BadRequestException;
import com.flightbooking.exception.ResourceNotFoundException;
import com.flightbooking.exception.UnauthorizedException;
import com.flightbooking.flight.Flight;
import com.flightbooking.flight.FlightRepository;
import com.flightbooking.notification.NotificationService;
import com.flightbooking.payment.Payment;
import com.flightbooking.payment.PaymentRepository;
import com.flightbooking.seat.FlightSeat;
import com.flightbooking.seat.FlightSeatRepository;
import com.flightbooking.user.User;
import com.flightbooking.user.UserRepository;
import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BookingService {

    private final BookingRepository bookingRepository;
    private final BookingPassengerRepository passengerRepository;
    private final FlightRepository flightRepository;
    private final FlightSeatRepository seatRepository;
    private final UserRepository userRepository;
    private final PaymentRepository paymentRepository;
    private final NotificationService notificationService;

    private final Random random = new Random();

    @Transactional(isolation = Isolation.SERIALIZABLE)
    public BookingResponseDto createBooking(Long userId, BookingRequestDto request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userId));

        Flight flight = flightRepository.findById(request.getFlightId())
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found: " + request.getFlightId()));

        if ("CANCELLED".equalsIgnoreCase(flight.getStatus())) {
            throw new BadRequestException("Cannot book seats on a cancelled flight");
        }

        BigDecimal totalAmount = BigDecimal.ZERO;
        List<FlightSeat> allocatedSeats = new ArrayList<>();

        // Validate and lock seats to prevent double-booking
        for (BookingRequestDto.PassengerDetailDto pDto : request.getPassengers()) {
            FlightSeat seat = seatRepository.findByFlightIdAndSeatNumber(flight.getId(), pDto.getSeatNumber().toUpperCase())
                    .orElseThrow(() -> new BadRequestException("Seat " + pDto.getSeatNumber() + " does not exist on this flight"));

            if (!Boolean.TRUE.equals(seat.getIsAvailable())) {
                throw new BadRequestException("Seat " + seat.getSeatNumber() + " is already booked. Please select another seat.");
            }

            // Reserve seat
            seat.setIsAvailable(false);
            seatRepository.save(seat);
            allocatedSeats.add(seat);

            BigDecimal seatPrice = flight.getBasePrice().multiply(seat.getPriceMultiplier());
            totalAmount = totalAmount.add(seatPrice);
        }

        // Generate unique PNR
        String airlinePrefix = flight.getAirline().getCode();
        String pnr = airlinePrefix + "-" + (100000 + random.nextInt(900000));

        Booking booking = Booking.builder()
                .bookingReference(pnr)
                .user(user)
                .flight(flight)
                .bookingDate(LocalDateTime.now())
                .travelDate(request.getTravelDate())
                .totalAmount(totalAmount)
                .status("CONFIRMED")
                .contactEmail(request.getContactEmail())
                .contactPhone(request.getContactPhone())
                .build();

        Booking savedBooking = bookingRepository.save(booking);

        // Save booking passengers
        List<BookingPassenger> passengerList = new ArrayList<>();
        for (int i = 0; i < request.getPassengers().size(); i++) {
            BookingRequestDto.PassengerDetailDto pDto = request.getPassengers().get(i);
            FlightSeat seat = allocatedSeats.get(i);
            String ticketNum = "ETKT-" + flight.getFlightNumber() + "-" + (10000 + random.nextInt(90000));

            BookingPassenger bp = BookingPassenger.builder()
                    .booking(savedBooking)
                    .seat(seat)
                    .fullName(pDto.getFullName())
                    .age(pDto.getAge())
                    .gender(pDto.getGender().toUpperCase())
                    .seatNumber(seat.getSeatNumber())
                    .ticketNumber(ticketNum)
                    .build();
            passengerList.add(passengerRepository.save(bp));
        }
        savedBooking.setPassengers(passengerList);

        // Process simulated payment
        String method = request.getPaymentMethod() != null ? request.getPaymentMethod().toUpperCase() : "UPI";
        Payment payment = Payment.builder()
                .booking(savedBooking)
                .transactionId("TXN-" + System.currentTimeMillis())
                .paymentMethod(method)
                .amount(totalAmount)
                .status("SUCCESS")
                .paymentGateway("SIMULATED")
                .paymentTime(LocalDateTime.now())
                .build();
        paymentRepository.save(payment);

        // Generate confirmation notification
        notificationService.createNotification(
                user.getId(),
                "Booking Confirmed: " + flight.getFlightNumber(),
                "Your booking " + pnr + " from " + flight.getSourceAirport().getCity() +
                        " to " + flight.getDestinationAirport().getCity() + " is confirmed.",
                "BOOKING_CONFIRMED",
                pnr
        );

        log.info("Booking created successfully with PNR: {}", pnr);
        return BookingResponseDto.fromEntity(savedBooking);
    }

    @Transactional(readOnly = true)
    public List<BookingResponseDto> getMyBookings(Long userId) {
        return bookingRepository.findByUserIdOrderByCreatedAtDesc(userId).stream()
                .map(BookingResponseDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public BookingResponseDto getBookingById(Long bookingId, Long userId, String userRole) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found: " + bookingId));

        if (!"ROLE_ADMIN".equals(userRole) && !"ROLE_STAFF".equals(userRole)
                && !"ADMIN".equals(userRole) && !"STAFF".equals(userRole)) {
            if (!booking.getUser().getId().equals(userId)) {
                throw new UnauthorizedException("You do not have permission to view this booking");
            }
        }

        return BookingResponseDto.fromEntity(booking);
    }

    @Transactional(readOnly = true)
    public BookingResponseDto getBookingByReference(String pnr) {
        Booking booking = bookingRepository.findByBookingReference(pnr)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with PNR: " + pnr));
        return BookingResponseDto.fromEntity(booking);
    }

    @Transactional(readOnly = true)
    public List<BookingResponseDto> getAllBookings() {
        return bookingRepository.findAll().stream()
                .map(BookingResponseDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public byte[] generateTicketPdf(Long bookingId, Long userId, String userRole) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found: " + bookingId));

        if (!"ROLE_ADMIN".equals(userRole) && !"ROLE_STAFF".equals(userRole)
                && !"ADMIN".equals(userRole) && !"STAFF".equals(userRole)) {
            if (!booking.getUser().getId().equals(userId)) {
                throw new UnauthorizedException("You do not have permission to download this ticket");
            }
        }

        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, out);
            document.open();

            // Header Title
            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 20, new Color(15, 23, 42));
            Paragraph title = new Paragraph("AEROLINK INTELLIGENT E-TICKET", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            title.setSpacingAfter(15);
            document.add(title);

            // Sub-header with PNR and Booking Date
            Font subFont = FontFactory.getFont(FontFactory.HELVETICA, 11, Color.GRAY);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a");
            Paragraph sub = new Paragraph("PNR: " + booking.getBookingReference() + "  |  Status: " + booking.getStatus() +
                    "  |  Issued: " + booking.getBookingDate().format(dtf), subFont);
            sub.setAlignment(Element.ALIGN_CENTER);
            sub.setSpacingAfter(20);
            document.add(sub);

            // Flight Details Table
            PdfPTable flightTable = new PdfPTable(4);
            flightTable.setWidthPercentage(100);
            flightTable.setSpacingAfter(20);

            addCell(flightTable, "Flight Number", booking.getFlight().getFlightNumber(), true);
            addCell(flightTable, "Airline", booking.getFlight().getAirline().getName(), true);
            addCell(flightTable, "From", booking.getFlight().getSourceAirport().getName() + " (" + booking.getFlight().getSourceAirport().getCode() + ")", false);
            addCell(flightTable, "To", booking.getFlight().getDestinationAirport().getName() + " (" + booking.getFlight().getDestinationAirport().getCode() + ")", false);
            addCell(flightTable, "Departure", booking.getFlight().getDepartureTime().format(dtf), false);
            addCell(flightTable, "Arrival", booking.getFlight().getArrivalTime().format(dtf), false);
            addCell(flightTable, "Duration", booking.getFlight().getDurationMinutes() + " mins", false);
            addCell(flightTable, "Total Fare", "INR " + booking.getTotalAmount(), false);

            document.add(flightTable);

            // Passenger List Header
            Font sectionFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14, new Color(30, 41, 59));
            Paragraph pHeader = new Paragraph("Passenger & Seat Allocations", sectionFont);
            pHeader.setSpacingAfter(10);
            document.add(pHeader);

            // Passenger Details Table
            PdfPTable passTable = new PdfPTable(5);
            passTable.setWidthPercentage(100);
            passTable.setSpacingAfter(25);

            passTable.addCell(createHeaderCell("Passenger Name"));
            passTable.addCell(createHeaderCell("Age"));
            passTable.addCell(createHeaderCell("Gender"));
            passTable.addCell(createHeaderCell("Seat"));
            passTable.addCell(createHeaderCell("Ticket Number"));

            for (BookingPassenger bp : booking.getPassengers()) {
                passTable.addCell(bp.getFullName());
                passTable.addCell(String.valueOf(bp.getAge()));
                passTable.addCell(bp.getGender());
                passTable.addCell(bp.getSeatNumber());
                passTable.addCell(bp.getTicketNumber());
            }
            document.add(passTable);

            // Important instructions
            Font noteFont = FontFactory.getFont(FontFactory.HELVETICA, 9, Color.DARK_GRAY);
            Paragraph notes = new Paragraph(
                    "IMPORTANT TRAVEL INFORMATION:\n" +
                    "1. Please report at the airport check-in counter at least 2 hours prior to domestic departure.\n" +
                    "2. Government-issued photo ID (Aadhaar Card, Passport, or Voter ID) is mandatory for airport entry.\n" +
                    "3. Standard baggage allowance: 15kg Check-in (1 piece) and 7kg Cabin baggage.\n" +
                    "4. For flight disruptions, cancellation, or special assistance, visit our AI Travel Assistant.",
                    noteFont
            );
            document.add(notes);

            document.close();
            return out.toByteArray();
        } catch (Exception e) {
            log.error("Failed to generate PDF ticket", e);
            throw new RuntimeException("Error generating ticket PDF: " + e.getMessage());
        }
    }

    private void addCell(PdfPTable table, String header, String value, boolean isHeaderRow) {
        Font hFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, Color.DARK_GRAY);
        Font vFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Color.BLACK);
        PdfPCell cell = new PdfPCell();
        cell.setPadding(6);
        cell.addElement(new Paragraph(header, hFont));
        cell.addElement(new Paragraph(value, vFont));
        table.addCell(cell);
    }

    private PdfPCell createHeaderCell(String text) {
        Font f = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, Color.WHITE);
        PdfPCell cell = new PdfPCell(new Phrase(text, f));
        cell.setBackgroundColor(new Color(30, 41, 59));
        cell.setPadding(6);
        return cell;
    }
}
