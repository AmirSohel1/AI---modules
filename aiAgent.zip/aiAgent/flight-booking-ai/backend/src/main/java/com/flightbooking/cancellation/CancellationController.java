package com.flightbooking.cancellation;

import com.flightbooking.common.ApiResponse;
import com.flightbooking.security.UserPrincipal;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/cancellations")
@RequiredArgsConstructor
public class CancellationController {

    private final CancellationService cancellationService;

    @PostMapping("/booking/{bookingId}")
    public ResponseEntity<ApiResponse<CancellationDto>> cancelBooking(
            @PathVariable Long bookingId,
            @RequestBody(required = false) Map<String, String> body,
            @AuthenticationPrincipal UserPrincipal user) {

        String reason = body != null ? body.get("reason") : "Passenger cancellation request";
        CancellationDto result = cancellationService.cancelBooking(bookingId, user.getId(), user.getRole(), reason);
        return ResponseEntity.ok(ApiResponse.ok("Booking cancelled and refund processed", result));
    }

    @GetMapping("/all")
    @PreAuthorize("hasAnyRole('STAFF', 'ADMIN')")
    public ResponseEntity<ApiResponse<List<CancellationRequest>>> getAllCancellations() {
        return ResponseEntity.ok(ApiResponse.ok(cancellationService.getAllCancellations()));
    }
}
