package com.flightbooking.cancellation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CancellationDto {
    private Long id;
    private Long bookingId;
    private String bookingReference;
    private String reason;
    private BigDecimal originalAmount;
    private BigDecimal cancellationFee;
    private BigDecimal refundAmount;
    private String status;
    private LocalDateTime requestedAt;
    private LocalDateTime processedAt;
    private String refundTransactionId;

    public static CancellationDto fromEntity(CancellationRequest c, Refund r) {
        return CancellationDto.builder()
                .id(c.getId())
                .bookingId(c.getBooking().getId())
                .bookingReference(c.getBooking().getBookingReference())
                .reason(c.getReason())
                .originalAmount(c.getBooking().getTotalAmount())
                .cancellationFee(c.getCancellationFee())
                .refundAmount(c.getRefundAmount())
                .status(c.getStatus())
                .requestedAt(c.getRequestedAt())
                .processedAt(c.getProcessedAt())
                .refundTransactionId(r != null ? r.getRefundTransactionId() : null)
                .build();
    }
}
