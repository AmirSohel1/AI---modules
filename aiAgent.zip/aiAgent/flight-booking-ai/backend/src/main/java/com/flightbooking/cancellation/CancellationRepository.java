package com.flightbooking.cancellation;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CancellationRepository extends JpaRepository<CancellationRequest, Long> {
    List<CancellationRequest> findByBookingId(Long bookingId);
}
