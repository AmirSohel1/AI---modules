package com.flightbooking.cancellation;

import com.flightbooking.booking.Booking;
import com.flightbooking.booking.BookingPassenger;
import com.flightbooking.booking.BookingRepository;
import com.flightbooking.exception.BadRequestException;
import com.flightbooking.exception.ResourceNotFoundException;
import com.flightbooking.exception.UnauthorizedException;
import com.flightbooking.notification.NotificationService;
import com.flightbooking.seat.FlightSeat;
import com.flightbooking.seat.FlightSeatRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

@Slf4j
@Service
@RequiredArgsConstructor
public class CancellationService {

    private final BookingRepository bookingRepository;
    private final CancellationRepository cancellationRepository;
    private final RefundRepository refundRepository;
    private final FlightSeatRepository seatRepository;
    private final NotificationService notificationService;

    private final Random random = new Random();

    @Transactional
    public CancellationDto cancelBooking(Long bookingId, Long userId, String userRole, String reason) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found: " + bookingId));

        if (!"ROLE_ADMIN".equals(userRole) && !"ROLE_STAFF".equals(userRole)
                && !"ADMIN".equals(userRole) && !"STAFF".equals(userRole)) {
            if (!booking.getUser().getId().equals(userId)) {
                throw new UnauthorizedException("You do not have permission to cancel this booking");
            }
        }

        if ("CANCELLED".equalsIgnoreCase(booking.getStatus())) {
            throw new BadRequestException("Booking is already cancelled");
        }

        BigDecimal cancellationFee = BigDecimal.ZERO;
        BigDecimal totalAmount = booking.getTotalAmount();
        boolean isAirlineDisruption = "CANCELLED".equalsIgnoreCase(booking.getFlight().getStatus())
                || booking.getFlight().getDelayMinutes() > 120;

        if (!isAirlineDisruption) {
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime departure = booking.getFlight().getDepartureTime();
            long hoursToDeparture = Duration.between(now, departure).toHours();

            if (hoursToDeparture > 72) {
                cancellationFee = BigDecimal.valueOf(2500);
            } else if (hoursToDeparture >= 24) {
                cancellationFee = BigDecimal.valueOf(3000);
            } else {
                cancellationFee = BigDecimal.valueOf(3500);
            }

            if (cancellationFee.compareTo(totalAmount) > 0) {
                cancellationFee = totalAmount;
            }
        }

        BigDecimal refundAmount = totalAmount.subtract(cancellationFee);
        if (refundAmount.compareTo(BigDecimal.ZERO) < 0) {
            refundAmount = BigDecimal.ZERO;
        }

        // Release allocated seats back to flight inventory
        for (BookingPassenger bp : booking.getPassengers()) {
            if (bp.getSeat() != null) {
                FlightSeat seat = bp.getSeat();
                seat.setIsAvailable(true);
                seatRepository.save(seat);
            }
        }

        // Update booking status
        booking.setStatus("CANCELLED");
        bookingRepository.save(booking);

        // Record cancellation
        CancellationRequest cancellation = CancellationRequest.builder()
                .booking(booking)
                .reason(reason != null ? reason : "Passenger requested cancellation")
                .cancellationFee(cancellationFee)
                .refundAmount(refundAmount)
                .status("PROCESSED")
                .processedAt(LocalDateTime.now())
                .staffNotes(isAirlineDisruption ? "Full refund due to airline flight disruption" : "Standard policy applied")
                .build();
        CancellationRequest savedCancellation = cancellationRepository.save(cancellation);

        // Record refund
        String refundTxn = "RFND-" + (100000 + random.nextInt(900000));
        Refund refund = Refund.builder()
                .cancellationRequest(savedCancellation)
                .booking(booking)
                .amount(refundAmount)
                .refundTransactionId(refundTxn)
                .status("COMPLETED")
                .processedAt(LocalDateTime.now())
                .build();
        Refund savedRefund = refundRepository.save(refund);

        // Notify passenger
        notificationService.createNotification(
                booking.getUser().getId(),
                "Cancellation & Refund Processed",
                "Booking " + booking.getBookingReference() + " has been cancelled. Refund of INR " +
                        refundAmount + " initiated (Ref: " + refundTxn + ").",
                "REFUND_UPDATE",
                refundTxn
        );

        return CancellationDto.fromEntity(savedCancellation, savedRefund);
    }

    @Transactional(readOnly = true)
    public List<CancellationRequest> getAllCancellations() {
        return cancellationRepository.findAll();
    }
}
