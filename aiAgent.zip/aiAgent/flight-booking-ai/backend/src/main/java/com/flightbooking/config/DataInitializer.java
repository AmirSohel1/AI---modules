package com.flightbooking.config;

import com.flightbooking.user.User;
import com.flightbooking.user.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        log.info("Checking initial user password encodings...");
        List<User> users = userRepository.findAll();
        int updatedCount = 0;

        for (User user : users) {
            if (user.getPasswordHash() != null && user.getPasswordHash().startsWith("RAW:")) {
                String plain = user.getPasswordHash().substring(4);
                user.setPasswordHash(passwordEncoder.encode(plain));
                userRepository.save(user);
                updatedCount++;
            }
        }

        if (updatedCount > 0) {
            log.info("Successfully encoded and secured {} demo user passwords with BCrypt.", updatedCount);
        } else {
            log.info("All user passwords verified securely.");
        }
    }
}
