package com.flightbooking.disruption;

import com.flightbooking.booking.BookingResponseDto;
import com.flightbooking.common.ApiResponse;
import com.flightbooking.flight.FlightDto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/disruptions")
@RequiredArgsConstructor
public class DisruptionController {

    private final DisruptionService disruptionService;

    @GetMapping
    public ResponseEntity<ApiResponse<List<DisruptionDto>>> getAllDisruptions() {
        return ResponseEntity.ok(ApiResponse.ok(disruptionService.getAllDisruptions()));
    }

    @GetMapping("/affected-passengers/{flightId}")
    @PreAuthorize("hasAnyRole('STAFF', 'ADMIN')")
    public ResponseEntity<ApiResponse<List<BookingResponseDto>>> getAffectedPassengers(@PathVariable Long flightId) {
        return ResponseEntity.ok(ApiResponse.ok(disruptionService.getAffectedPassengers(flightId)));
    }

    @GetMapping("/alternatives/{flightId}")
    public ResponseEntity<ApiResponse<List<FlightDto>>> getAlternatives(@PathVariable Long flightId) {
        return ResponseEntity.ok(ApiResponse.ok(disruptionService.getAlternativesForFlight(flightId)));
    }

    @PostMapping("/simulate")
    @PreAuthorize("hasAnyRole('STAFF', 'ADMIN')")
    public ResponseEntity<ApiResponse<DisruptionDto>> simulateDisruption(@RequestBody Map<String, Object> body) {
        Long flightId = ((Number) body.get("flightId")).longValue();
        String type = (String) body.get("type"); // DELAY or CANCELLATION
        String reason = (String) body.get("reason");
        Integer delayMinutes = body.get("delayMinutes") != null ? ((Number) body.get("delayMinutes")).intValue() : 0;

        DisruptionDto result = disruptionService.createOrUpdateDisruption(flightId, type, reason, delayMinutes);
        return ResponseEntity.ok(ApiResponse.ok("Flight disruption created and passengers notified", result));
    }
}
