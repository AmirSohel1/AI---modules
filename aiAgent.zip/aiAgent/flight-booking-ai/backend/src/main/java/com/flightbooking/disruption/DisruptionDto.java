package com.flightbooking.disruption;

import com.flightbooking.flight.FlightDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DisruptionDto {
    private Long id;
    private FlightDto flight;
    private String disruptionType;
    private String reason;
    private Integer delayMinutes;
    private Integer affectedPassengerCount;
    private String alternativesSuggested;
    private String status;
    private LocalDateTime createdAt;
    private LocalDateTime resolvedAt;

    public static DisruptionDto fromEntity(FlightDisruption d) {
        return DisruptionDto.builder()
                .id(d.getId())
                .flight(FlightDto.fromEntity(d.getFlight(), null))
                .disruptionType(d.getDisruptionType())
                .reason(d.getReason())
                .delayMinutes(d.getDelayMinutes())
                .affectedPassengerCount(d.getAffectedPassengerCount())
                .alternativesSuggested(d.getAlternativesSuggested())
                .status(d.getStatus())
                .createdAt(d.getCreatedAt())
                .resolvedAt(d.getResolvedAt())
                .build();
    }
}
