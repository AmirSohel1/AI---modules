package com.flightbooking.disruption;

import com.flightbooking.booking.Booking;
import com.flightbooking.booking.BookingRepository;
import com.flightbooking.booking.BookingResponseDto;
import com.flightbooking.exception.ResourceNotFoundException;
import com.flightbooking.flight.Flight;
import com.flightbooking.flight.FlightDto;
import com.flightbooking.flight.FlightRepository;
import com.flightbooking.notification.NotificationService;
import com.flightbooking.seat.FlightSeatRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class DisruptionService {

    private final FlightDisruptionRepository disruptionRepository;
    private final FlightRepository flightRepository;
    private final BookingRepository bookingRepository;
    private final FlightSeatRepository seatRepository;
    private final NotificationService notificationService;

    @Transactional(readOnly = true)
    public List<DisruptionDto> getAllDisruptions() {
        return disruptionRepository.findAll().stream()
                .map(DisruptionDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<BookingResponseDto> getAffectedPassengers(Long flightId) {
        return bookingRepository.findConfirmedBookingsByFlightId(flightId).stream()
                .map(BookingResponseDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<FlightDto> getAlternativesForFlight(Long flightId) {
        Flight flight = flightRepository.findById(flightId)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found: " + flightId));

        List<Flight> alternatives = flightRepository.findAlternativeFlights(
                flight.getSourceAirport().getId(),
                flight.getDestinationAirport().getId(),
                LocalDateTime.now(),
                flight.getId()
        );

        return alternatives.stream()
                .map(f -> {
                    long available = seatRepository.countAvailableSeatsByFlightId(f.getId());
                    return FlightDto.fromEntity(f, available);
                })
                .collect(Collectors.toList());
    }

    @Transactional
    public DisruptionDto createOrUpdateDisruption(Long flightId, String type, String reason, Integer delayMinutes) {
        Flight flight = flightRepository.findById(flightId)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found: " + flightId));

        flight.setStatus(type.equalsIgnoreCase("CANCELLATION") ? "CANCELLED" : "DELAYED");
        flight.setDelayReason(reason);
        flight.setDelayMinutes(delayMinutes != null ? delayMinutes : 0);
        flightRepository.save(flight);

        List<Booking> affectedBookings = bookingRepository.findConfirmedBookingsByFlightId(flightId);
        int passengerCount = affectedBookings.stream().mapToInt(b -> b.getPassengers().size()).sum();

        // Query alternative flights
        List<Flight> alts = flightRepository.findAlternativeFlights(
                flight.getSourceAirport().getId(),
                flight.getDestinationAirport().getId(),
                LocalDateTime.now(),
                flight.getId()
        );
        String altSummary = alts.stream()
                .limit(3)
                .map(a -> a.getFlightNumber() + " (" + a.getAirline().getCode() + ") at " + a.getDepartureTime().toLocalTime())
                .collect(Collectors.joining(", "));

        FlightDisruption disruption = disruptionRepository.findByFlightIdAndStatus(flightId, "ACTIVE")
                .orElseGet(() -> FlightDisruption.builder().flight(flight).build());

        disruption.setDisruptionType(type.toUpperCase());
        disruption.setReason(reason);
        disruption.setDelayMinutes(delayMinutes != null ? delayMinutes : 0);
        disruption.setAffectedPassengerCount(passengerCount);
        disruption.setAlternativesSuggested(altSummary.isBlank() ? "No direct alternatives immediately available" : altSummary);
        disruption.setStatus("ACTIVE");

        FlightDisruption saved = disruptionRepository.save(disruption);

        // Notify affected passengers
        for (Booking b : affectedBookings) {
            String title = type.equalsIgnoreCase("CANCELLATION")
                    ? "URGENT: Flight " + flight.getFlightNumber() + " Cancelled"
                    : "ALERT: Flight " + flight.getFlightNumber() + " Delayed by " + delayMinutes + " mins";
            String msg = "Your scheduled flight " + flight.getFlightNumber() + " is affected. " + reason +
                    ". Free rescheduling or full refund available via AI Assistant.";
            notificationService.createNotification(
                    b.getUser().getId(),
                    title,
                    msg,
                    type.equalsIgnoreCase("CANCELLATION") ? "FLIGHT_CANCELLED" : "FLIGHT_DELAYED",
                    flight.getFlightNumber()
            );
        }

        return DisruptionDto.fromEntity(saved);
    }
}
