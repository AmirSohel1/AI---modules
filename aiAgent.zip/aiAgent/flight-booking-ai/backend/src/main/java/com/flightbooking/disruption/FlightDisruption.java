package com.flightbooking.disruption;

import com.flightbooking.flight.Flight;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "flight_disruptions")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FlightDisruption {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "flight_id", nullable = false)
    private Flight flight;

    @Column(name = "disruption_type", nullable = false, length = 30)
    private String disruptionType; // DELAY, CANCELLATION

    @Column(nullable = false)
    private String reason;

    @Column(name = "delay_minutes")
    @Builder.Default
    private Integer delayMinutes = 0;

    @Column(name = "affected_passenger_count")
    @Builder.Default
    private Integer affectedPassengerCount = 0;

    @Column(name = "alternatives_suggested", columnDefinition = "TEXT")
    private String alternativesSuggested;

    @Column(nullable = false, length = 30)
    @Builder.Default
    private String status = "ACTIVE"; // ACTIVE, RESOLVED

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "resolved_at")
    private LocalDateTime resolvedAt;
}
