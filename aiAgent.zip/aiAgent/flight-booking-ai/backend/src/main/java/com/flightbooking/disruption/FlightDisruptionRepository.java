package com.flightbooking.disruption;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FlightDisruptionRepository extends JpaRepository<FlightDisruption, Long> {
    List<FlightDisruption> findByStatus(String status);
    Optional<FlightDisruption> findByFlightIdAndStatus(Long flightId, String status);
}
