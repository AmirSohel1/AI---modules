package com.flightbooking.feedback;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "feedback_analysis")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FeedbackAnalysis {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "feedback_id", nullable = false, unique = true)
    private Feedback feedback;

    @Column(nullable = false, length = 30)
    private String sentiment; // POSITIVE, NEUTRAL, NEGATIVE

    @Column(nullable = false, length = 50)
    private String category; // FLIGHT_DELAY, STAFF_BEHAVIOR, BOOKING_PROBLEM, BAGGAGE_PROBLEM, REFUND_PROBLEM, PAYMENT_PROBLEM, CLEANLINESS, OTHER

    @Column(name = "key_phrases", columnDefinition = "TEXT")
    private String keyPhrases;

    @Column(name = "urgency_score")
    @Builder.Default
    private Integer urgencyScore = 5; // 1 to 10

    @Column(name = "ai_summary", columnDefinition = "TEXT")
    private String aiSummary;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
}
