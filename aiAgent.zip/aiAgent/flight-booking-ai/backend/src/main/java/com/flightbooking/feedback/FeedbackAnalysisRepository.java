package com.flightbooking.feedback;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FeedbackAnalysisRepository extends JpaRepository<FeedbackAnalysis, Long> {
    Optional<FeedbackAnalysis> findByFeedbackId(Long feedbackId);

    @Query("SELECT fa.sentiment, COUNT(fa) FROM FeedbackAnalysis fa GROUP BY fa.sentiment")
    List<Object[]> countBySentiment();

    @Query("SELECT fa.category, COUNT(fa) FROM FeedbackAnalysis fa GROUP BY fa.category")
    List<Object[]> countByCategory();
}
