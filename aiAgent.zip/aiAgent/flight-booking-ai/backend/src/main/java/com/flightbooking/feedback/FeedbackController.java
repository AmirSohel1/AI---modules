package com.flightbooking.feedback;

import com.flightbooking.common.ApiResponse;
import com.flightbooking.security.UserPrincipal;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/feedback")
@RequiredArgsConstructor
public class FeedbackController {

    private final FeedbackService feedbackService;

    @PostMapping
    public ResponseEntity<ApiResponse<FeedbackDto>> submitFeedback(
            @RequestBody Map<String, Object> body,
            @AuthenticationPrincipal UserPrincipal user) {

        Long flightId = body.get("flightId") != null ? ((Number) body.get("flightId")).longValue() : null;
        Long bookingId = body.get("bookingId") != null ? ((Number) body.get("bookingId")).longValue() : null;
        int rating = ((Number) body.getOrDefault("rating", 5)).intValue();
        String comment = (String) body.get("comment");

        FeedbackDto result = feedbackService.submitFeedback(user.getId(), flightId, bookingId, rating, comment);
        return ResponseEntity.ok(ApiResponse.ok("Feedback submitted successfully", result));
    }

    @GetMapping("/my")
    public ResponseEntity<ApiResponse<List<FeedbackDto>>> getMyFeedback(@AuthenticationPrincipal UserPrincipal user) {
        return ResponseEntity.ok(ApiResponse.ok(feedbackService.getMyFeedback(user.getId())));
    }

    @GetMapping("/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<FeedbackDto>>> getAllFeedbackAdmin() {
        return ResponseEntity.ok(ApiResponse.ok(feedbackService.getAllFeedback()));
    }

    @GetMapping("/admin/analytics")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getFeedbackAnalytics() {
        return ResponseEntity.ok(ApiResponse.ok(feedbackService.getFeedbackAnalytics()));
    }

    @PostMapping("/internal/{id}/analysis")
    public ResponseEntity<ApiResponse<FeedbackDto>> updateAnalysisFromAi(
            @PathVariable Long id,
            @RequestBody Map<String, Object> body) {
        String sentiment = (String) body.get("sentiment");
        String category = (String) body.get("category");
        int urgency = body.get("urgencyScore") != null ? ((Number) body.get("urgencyScore")).intValue() : 5;
        String summary = (String) body.get("aiSummary");
        String keyPhrases = (String) body.get("keyPhrases");

        return ResponseEntity.ok(ApiResponse.ok(feedbackService.updateAiAnalysis(id, sentiment, category, urgency, summary, keyPhrases)));
    }
}
