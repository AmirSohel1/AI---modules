package com.flightbooking.feedback;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeedbackDto {
    private Long id;
    private Long userId;
    private String userName;
    private Long flightId;
    private String flightNumber;
    private Integer rating;
    private String comment;
    private LocalDateTime submittedAt;

    // AI Analysis fields
    private String sentiment;
    private String category;
    private String keyPhrases;
    private Integer urgencyScore;
    private String aiSummary;

    public static FeedbackDto fromEntity(Feedback f) {
        FeedbackDto.FeedbackDtoBuilder builder = FeedbackDto.builder()
                .id(f.getId())
                .userId(f.getUser().getId())
                .userName(f.getUser().getFullName())
                .flightId(f.getFlight() != null ? f.getFlight().getId() : null)
                .flightNumber(f.getFlight() != null ? f.getFlight().getFlightNumber() : "General")
                .rating(f.getRating())
                .comment(f.getComment())
                .submittedAt(f.getSubmittedAt());

        if (f.getAnalysis() != null) {
            builder.sentiment(f.getAnalysis().getSentiment())
                    .category(f.getAnalysis().getCategory())
                    .keyPhrases(f.getAnalysis().getKeyPhrases())
                    .urgencyScore(f.getAnalysis().getUrgencyScore())
                    .aiSummary(f.getAnalysis().getAiSummary());
        }

        return builder.build();
    }
}
