package com.flightbooking.feedback;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FeedbackRepository extends JpaRepository<Feedback, Long> {
    List<Feedback> findByUserIdOrderBySubmittedAtDesc(Long userId);
    List<Feedback> findAllByOrderBySubmittedAtDesc();

    @Query("SELECT AVG(f.rating) FROM Feedback f")
    Double findAverageRating();
}
