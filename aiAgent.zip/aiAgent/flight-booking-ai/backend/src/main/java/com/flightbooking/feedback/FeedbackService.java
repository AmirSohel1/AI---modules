package com.flightbooking.feedback;

import com.flightbooking.booking.Booking;
import com.flightbooking.booking.BookingRepository;
import com.flightbooking.exception.ResourceNotFoundException;
import com.flightbooking.flight.Flight;
import com.flightbooking.flight.FlightRepository;
import com.flightbooking.user.User;
import com.flightbooking.user.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class FeedbackService {

    private final FeedbackRepository feedbackRepository;
    private final FeedbackAnalysisRepository analysisRepository;
    private final UserRepository userRepository;
    private final FlightRepository flightRepository;
    private final BookingRepository bookingRepository;

    @Transactional
    public FeedbackDto submitFeedback(Long userId, Long flightId, Long bookingId, int rating, String comment) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userId));

        Flight flight = flightId != null ? flightRepository.findById(flightId).orElse(null) : null;
        Booking booking = bookingId != null ? bookingRepository.findById(bookingId).orElse(null) : null;

        Feedback feedback = Feedback.builder()
                .user(user)
                .flight(flight)
                .booking(booking)
                .rating(rating)
                .comment(comment)
                .build();

        Feedback saved = feedbackRepository.save(feedback);

        // Run local baseline sentiment classification
        String sentiment = rating >= 4 ? "POSITIVE" : (rating == 3 ? "NEUTRAL" : "NEGATIVE");
        String category = classifyCategory(comment);
        int urgency = rating <= 2 ? 8 : (rating == 3 ? 5 : 2);

        FeedbackAnalysis analysis = FeedbackAnalysis.builder()
                .feedback(saved)
                .sentiment(sentiment)
                .category(category)
                .urgencyScore(urgency)
                .aiSummary("Passenger expressed " + sentiment.toLowerCase() + " feedback regarding " + category.toLowerCase().replace('_', ' ') + ".")
                .keyPhrases(extractKeywords(comment))
                .build();

        analysisRepository.save(analysis);
        saved.setAnalysis(analysis);

        return FeedbackDto.fromEntity(saved);
    }

    private String classifyCategory(String comment) {
        if (comment == null) return "OTHER";
        String lower = comment.toLowerCase();
        if (lower.contains("delay") || lower.contains("late") || lower.contains("cancelled") || lower.contains("rescheduled")) {
            return "FLIGHT_DELAY";
        } else if (lower.contains("bag") || lower.contains("luggage") || lower.contains("suitcase")) {
            return "BAGGAGE_PROBLEM";
        } else if (lower.contains("staff") || lower.contains("crew") || lower.contains("rude") || lower.contains("pilot") || lower.contains("polite")) {
            return "STAFF_BEHAVIOR";
        } else if (lower.contains("refund") || lower.contains("money") || lower.contains("charge") || lower.contains("fee")) {
            return "REFUND_PROBLEM";
        } else if (lower.contains("clean") || lower.contains("seat") || lower.contains("dirty") || lower.contains("food") || lower.contains("meal")) {
            return "CLEANLINESS";
        } else if (lower.contains("book") || lower.contains("ticket") || lower.contains("pnr")) {
            return "BOOKING_PROBLEM";
        }
        return "OTHER";
    }

    private String extractKeywords(String text) {
        if (text == null || text.isBlank()) return "general feedback";
        return text.replaceAll("[^a-zA-Z0-9 ]", "").toLowerCase();
    }

    @Transactional
    public FeedbackDto updateAiAnalysis(Long feedbackId, String sentiment, String category, int urgency, String summary, String keyPhrases) {
        Feedback feedback = feedbackRepository.findById(feedbackId)
                .orElseThrow(() -> new ResourceNotFoundException("Feedback not found: " + feedbackId));

        FeedbackAnalysis analysis = analysisRepository.findByFeedbackId(feedbackId)
                .orElseGet(() -> FeedbackAnalysis.builder().feedback(feedback).build());

        analysis.setSentiment(sentiment.toUpperCase());
        analysis.setCategory(category.toUpperCase());
        analysis.setUrgencyScore(urgency);
        analysis.setAiSummary(summary);
        if (keyPhrases != null) analysis.setKeyPhrases(keyPhrases);

        analysisRepository.save(analysis);
        feedback.setAnalysis(analysis);
        return FeedbackDto.fromEntity(feedback);
    }

    @Transactional(readOnly = true)
    public List<FeedbackDto> getMyFeedback(Long userId) {
        return feedbackRepository.findByUserIdOrderBySubmittedAtDesc(userId).stream()
                .map(FeedbackDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<FeedbackDto> getAllFeedback() {
        return feedbackRepository.findAllByOrderBySubmittedAtDesc().stream()
                .map(FeedbackDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getFeedbackAnalytics() {
        Map<String, Object> map = new HashMap<>();
        map.put("averageRating", feedbackRepository.findAverageRating());
        map.put("sentimentCounts", analysisRepository.countBySentiment());
        map.put("categoryCounts", analysisRepository.countByCategory());
        return map;
    }
}
