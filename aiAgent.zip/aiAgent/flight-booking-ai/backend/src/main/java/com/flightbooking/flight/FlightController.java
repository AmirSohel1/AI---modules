package com.flightbooking.flight;

import com.flightbooking.common.ApiResponse;
import com.flightbooking.seat.FlightSeatDto;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/flights")
@RequiredArgsConstructor
public class FlightController {

    private final FlightService flightService;

    @GetMapping
    public ResponseEntity<ApiResponse<List<FlightDto>>> getAllFlights() {
        return ResponseEntity.ok(ApiResponse.ok(flightService.getAllFlights()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<FlightDto>> getFlightById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok(flightService.getFlightById(id)));
    }

    @GetMapping("/{id}/seats")
    public ResponseEntity<ApiResponse<List<FlightSeatDto>>> getFlightSeats(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok(flightService.getSeatsByFlightId(id)));
    }

    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<FlightDto>>> searchFlights(
            @RequestParam(required = false) String source,
            @RequestParam(required = false) String destination,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate travelDate,
            @RequestParam(required = false) BigDecimal maxBudget,
            @RequestParam(required = false) String airlineCode,
            @RequestParam(required = false) Integer maxStops,
            @RequestParam(required = false) String timeOfDay,
            @RequestParam(required = false) String sortBy) {

        FlightSearchCriteria criteria = FlightSearchCriteria.builder()
                .source(source)
                .destination(destination)
                .travelDate(travelDate)
                .maxBudget(maxBudget)
                .airlineCode(airlineCode)
                .maxStops(maxStops)
                .timeOfDay(timeOfDay)
                .sortBy(sortBy)
                .build();

        List<FlightDto> results = flightService.searchFlights(criteria);
        return ResponseEntity.ok(ApiResponse.ok(results));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('STAFF', 'ADMIN')")
    public ResponseEntity<ApiResponse<FlightDto>> updateFlightStatus(
            @PathVariable Long id,
            @RequestBody Map<String, Object> body) {

        String status = (String) body.get("status");
        String reason = (String) body.get("delayReason");
        Integer minutes = body.get("delayMinutes") != null ? ((Number) body.get("delayMinutes")).intValue() : 0;

        FlightDto updated = flightService.updateFlightStatus(id, status, reason, minutes);
        return ResponseEntity.ok(ApiResponse.ok("Flight status updated successfully", updated));
    }
}
