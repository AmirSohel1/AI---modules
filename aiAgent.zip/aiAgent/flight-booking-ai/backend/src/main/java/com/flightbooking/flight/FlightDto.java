package com.flightbooking.flight;

import com.flightbooking.aircraft.Aircraft;
import com.flightbooking.airline.Airline;
import com.flightbooking.airport.Airport;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightDto {
    private Long id;
    private String flightNumber;
    private Airline airline;
    private Aircraft aircraft;
    private Airport sourceAirport;
    private Airport destinationAirport;
    private LocalDateTime departureTime;
    private LocalDateTime arrivalTime;
    private Integer durationMinutes;
    private Integer stops;
    private BigDecimal basePrice;
    private String status;
    private String delayReason;
    private Integer delayMinutes;
    private Long availableSeatsCount;

    public static FlightDto fromEntity(Flight flight, Long availableSeats) {
        return FlightDto.builder()
                .id(flight.getId())
                .flightNumber(flight.getFlightNumber())
                .airline(flight.getAirline())
                .aircraft(flight.getAircraft())
                .sourceAirport(flight.getSourceAirport())
                .destinationAirport(flight.getDestinationAirport())
                .departureTime(flight.getDepartureTime())
                .arrivalTime(flight.getArrivalTime())
                .durationMinutes(flight.getDurationMinutes())
                .stops(flight.getStops())
                .basePrice(flight.getBasePrice())
                .status(flight.getStatus())
                .delayReason(flight.getDelayReason())
                .delayMinutes(flight.getDelayMinutes())
                .availableSeatsCount(availableSeats != null ? availableSeats : 0L)
                .build();
    }
}
