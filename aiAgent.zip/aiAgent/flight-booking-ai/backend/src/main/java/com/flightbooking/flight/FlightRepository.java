package com.flightbooking.flight;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface FlightRepository extends JpaRepository<Flight, Long> {
    Optional<Flight> findByFlightNumber(String flightNumber);

    List<Flight> findByStatus(String status);

    @Query("SELECT f FROM Flight f WHERE " +
           "(:sourceCode IS NULL OR LOWER(f.sourceAirport.code) = LOWER(:sourceCode) OR LOWER(f.sourceAirport.city) = LOWER(:sourceCode)) AND " +
           "(:destCode IS NULL OR LOWER(f.destinationAirport.code) = LOWER(:destCode) OR LOWER(f.destinationAirport.city) = LOWER(:destCode)) AND " +
           "(:startDate IS NULL OR f.departureTime >= :startDate) AND " +
           "(:endDate IS NULL OR f.departureTime <= :endDate) AND " +
           "(:status IS NULL OR f.status = :status)")
    List<Flight> searchFlights(@Param("sourceCode") String sourceCode,
                              @Param("destCode") String destCode,
                              @Param("startDate") LocalDateTime startDate,
                              @Param("endDate") LocalDateTime endDate,
                              @Param("status") String status);

    @Query("SELECT f FROM Flight f WHERE " +
           "f.sourceAirport.id = :sourceId AND " +
           "f.destinationAirport.id = :destId AND " +
           "f.departureTime >= :afterTime AND " +
           "f.status = 'SCHEDULED' AND " +
           "f.id != :excludeFlightId")
    List<Flight> findAlternativeFlights(@Param("sourceId") Long sourceId,
                                       @Param("destId") Long destId,
                                       @Param("afterTime") LocalDateTime afterTime,
                                       @Param("excludeFlightId") Long excludeFlightId);

    long countByStatus(String status);
}
