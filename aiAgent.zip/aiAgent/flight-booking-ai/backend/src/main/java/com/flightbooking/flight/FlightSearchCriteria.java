package com.flightbooking.flight;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightSearchCriteria {
    private String source;
    private String destination;
    private LocalDate travelDate;
    private BigDecimal maxBudget;
    private String airlineCode;
    private Integer maxStops;
    private String timeOfDay; // MORNING, AFTERNOON, EVENING, NIGHT
    private String sortBy; // price_asc, price_desc, duration_asc, departure_asc
}
