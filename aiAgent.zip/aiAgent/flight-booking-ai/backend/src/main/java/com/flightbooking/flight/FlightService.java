package com.flightbooking.flight;

import com.flightbooking.exception.ResourceNotFoundException;
import com.flightbooking.seat.FlightSeat;
import com.flightbooking.seat.FlightSeatDto;
import com.flightbooking.seat.FlightSeatRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class FlightService {

    private final FlightRepository flightRepository;
    private final FlightSeatRepository seatRepository;

    @Transactional(readOnly = true)
    public List<FlightDto> getAllFlights() {
        return flightRepository.findAll().stream()
                .map(f -> {
                    long available = seatRepository.countAvailableSeatsByFlightId(f.getId());
                    return FlightDto.fromEntity(f, available);
                })
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public FlightDto getFlightById(Long id) {
        Flight flight = flightRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found with id: " + id));
        long available = seatRepository.countAvailableSeatsByFlightId(flight.getId());
        return FlightDto.fromEntity(flight, available);
    }

    @Transactional(readOnly = true)
    public List<FlightSeatDto> getSeatsByFlightId(Long flightId) {
        if (!flightRepository.existsById(flightId)) {
            throw new ResourceNotFoundException("Flight not found with id: " + flightId);
        }
        return seatRepository.findByFlightId(flightId).stream()
                .map(FlightSeatDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<FlightDto> searchFlights(FlightSearchCriteria criteria) {
        LocalDateTime start = null;
        LocalDateTime end = null;

        if (criteria.getTravelDate() != null) {
            start = criteria.getTravelDate().atStartOfDay();
            end = criteria.getTravelDate().atTime(LocalTime.MAX);
        }

        List<Flight> flights = flightRepository.searchFlights(
                criteria.getSource(),
                criteria.getDestination(),
                start,
                end,
                null // allow any or scheduled status
        );

        return flights.stream()
                // Filter max budget
                .filter(f -> criteria.getMaxBudget() == null || f.getBasePrice().compareTo(criteria.getMaxBudget()) <= 0)
                // Filter airline
                .filter(f -> criteria.getAirlineCode() == null || f.getAirline().getCode().equalsIgnoreCase(criteria.getAirlineCode()))
                // Filter max stops
                .filter(f -> criteria.getMaxStops() == null || f.getStops() <= criteria.getMaxStops())
                // Filter time of day
                .filter(f -> matchesTimeOfDay(f.getDepartureTime().toLocalTime(), criteria.getTimeOfDay()))
                .map(f -> {
                    long available = seatRepository.countAvailableSeatsByFlightId(f.getId());
                    return FlightDto.fromEntity(f, available);
                })
                .sorted(getComparator(criteria.getSortBy()))
                .collect(Collectors.toList());
    }

    private boolean matchesTimeOfDay(LocalTime time, String preference) {
        if (preference == null || preference.isBlank() || preference.equalsIgnoreCase("ALL")) return true;
        int hour = time.getHour();
        return switch (preference.toUpperCase()) {
            case "MORNING" -> hour >= 5 && hour < 12;
            case "AFTERNOON" -> hour >= 12 && hour < 17;
            case "EVENING" -> hour >= 17 && hour < 21;
            case "NIGHT" -> hour >= 21 || hour < 5;
            default -> true;
        };
    }

    private Comparator<FlightDto> getComparator(String sortBy) {
        if (sortBy == null) return Comparator.comparing(FlightDto::getDepartureTime);
        return switch (sortBy.toLowerCase()) {
            case "price_asc" -> Comparator.comparing(FlightDto::getBasePrice);
            case "price_desc" -> Comparator.comparing(FlightDto::getBasePrice).reversed();
            case "duration_asc" -> Comparator.comparing(FlightDto::getDurationMinutes);
            case "departure_asc" -> Comparator.comparing(FlightDto::getDepartureTime);
            default -> Comparator.comparing(FlightDto::getDepartureTime);
        };
    }

    @Transactional
    public FlightDto updateFlightStatus(Long flightId, String newStatus, String delayReason, Integer delayMinutes) {
        Flight flight = flightRepository.findById(flightId)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found with id: " + flightId));

        flight.setStatus(newStatus.toUpperCase());
        if (delayReason != null) flight.setDelayReason(delayReason);
        if (delayMinutes != null) flight.setDelayMinutes(delayMinutes);

        Flight saved = flightRepository.save(flight);
        long available = seatRepository.countAvailableSeatsByFlightId(saved.getId());
        return FlightDto.fromEntity(saved, available);
    }
}
