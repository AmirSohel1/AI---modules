package com.flightbooking.passenger;

import com.flightbooking.common.ApiResponse;
import com.flightbooking.security.UserPrincipal;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/passengers")
@RequiredArgsConstructor
public class PassengerController {

    private final PassengerService passengerService;

    @GetMapping("/preferences")
    public ResponseEntity<ApiResponse<PassengerPreferenceDto>> getPreferences(@AuthenticationPrincipal UserPrincipal user) {
        return ResponseEntity.ok(ApiResponse.ok(passengerService.getPreferences(user.getId())));
    }

    @PutMapping("/preferences")
    public ResponseEntity<ApiResponse<PassengerPreferenceDto>> updatePreferences(
            @AuthenticationPrincipal UserPrincipal user,
            @RequestBody PassengerPreferenceDto dto) {
        return ResponseEntity.ok(ApiResponse.ok("Preferences updated successfully",
                passengerService.updatePreferences(user.getId(), dto)));
    }
}
