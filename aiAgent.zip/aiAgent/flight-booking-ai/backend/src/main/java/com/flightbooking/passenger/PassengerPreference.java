package com.flightbooking.passenger;

import com.flightbooking.user.User;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "passenger_preferences")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PassengerPreference {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;

    @Column(name = "preferred_seat_type", length = 30)
    @Builder.Default
    private String preferredSeatType = "AISLE"; // WINDOW, AISLE, MIDDLE

    @Column(name = "preferred_class", length = 30)
    @Builder.Default
    private String preferredClass = "ECONOMY"; // ECONOMY, BUSINESS

    @Column(name = "meal_preference", length = 30)
    @Builder.Default
    private String mealPreference = "VEG"; // VEG, NON_VEG, JAIN, VEGAN

    @Column(name = "preferred_departure_time", length = 30)
    @Builder.Default
    private String preferredDepartureTime = "MORNING"; // MORNING, AFTERNOON, EVENING, NIGHT

    @Column(name = "consent_given")
    @Builder.Default
    private Boolean consentGiven = true;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
