package com.flightbooking.passenger;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PassengerPreferenceDto {
    private String preferredSeatType;
    private String preferredClass;
    private String mealPreference;
    private String preferredDepartureTime;
    private Boolean consentGiven;

    private String passportNumber;
    private LocalDate dateOfBirth;
    private String gender;
    private String nationality;
    private String emergencyContact;
}
