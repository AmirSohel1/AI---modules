package com.flightbooking.passenger;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PassengerPreferenceRepository extends JpaRepository<PassengerPreference, Long> {
    Optional<PassengerPreference> findByUserId(Long userId);
}
