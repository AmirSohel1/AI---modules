package com.flightbooking.passenger;

import com.flightbooking.exception.ResourceNotFoundException;
import com.flightbooking.user.User;
import com.flightbooking.user.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class PassengerService {

    private final PassengerRepository passengerRepository;
    private final PassengerPreferenceRepository preferenceRepository;
    private final UserRepository userRepository;

    @Transactional(readOnly = true)
    public PassengerPreferenceDto getPreferences(Long userId) {
        Passenger passenger = passengerRepository.findByUserId(userId).orElse(null);
        PassengerPreference pref = preferenceRepository.findByUserId(userId).orElse(null);

        return PassengerPreferenceDto.builder()
                .preferredSeatType(pref != null ? pref.getPreferredSeatType() : "AISLE")
                .preferredClass(pref != null ? pref.getPreferredClass() : "ECONOMY")
                .mealPreference(pref != null ? pref.getMealPreference() : "VEG")
                .preferredDepartureTime(pref != null ? pref.getPreferredDepartureTime() : "MORNING")
                .consentGiven(pref != null ? pref.getConsentGiven() : true)
                .passportNumber(passenger != null ? passenger.getPassportNumber() : null)
                .dateOfBirth(passenger != null ? passenger.getDateOfBirth() : null)
                .gender(passenger != null ? passenger.getGender() : null)
                .nationality(passenger != null ? passenger.getNationality() : "Indian")
                .emergencyContact(passenger != null ? passenger.getEmergencyContact() : null)
                .build();
    }

    @Transactional
    public PassengerPreferenceDto updatePreferences(Long userId, PassengerPreferenceDto dto) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Passenger passenger = passengerRepository.findByUserId(userId)
                .orElseGet(() -> Passenger.builder().user(user).nationality("Indian").build());

        if (dto.getPassportNumber() != null) passenger.setPassportNumber(dto.getPassportNumber());
        if (dto.getDateOfBirth() != null) passenger.setDateOfBirth(dto.getDateOfBirth());
        if (dto.getGender() != null) passenger.setGender(dto.getGender());
        if (dto.getNationality() != null) passenger.setNationality(dto.getNationality());
        if (dto.getEmergencyContact() != null) passenger.setEmergencyContact(dto.getEmergencyContact());
        passengerRepository.save(passenger);

        PassengerPreference pref = preferenceRepository.findByUserId(userId)
                .orElseGet(() -> PassengerPreference.builder().user(user).build());

        if (dto.getPreferredSeatType() != null) pref.setPreferredSeatType(dto.getPreferredSeatType());
        if (dto.getPreferredClass() != null) pref.setPreferredClass(dto.getPreferredClass());
        if (dto.getMealPreference() != null) pref.setMealPreference(dto.getMealPreference());
        if (dto.getPreferredDepartureTime() != null) pref.setPreferredDepartureTime(dto.getPreferredDepartureTime());
        if (dto.getConsentGiven() != null) pref.setConsentGiven(dto.getConsentGiven());
        preferenceRepository.save(pref);

        return getPreferences(userId);
    }
}
