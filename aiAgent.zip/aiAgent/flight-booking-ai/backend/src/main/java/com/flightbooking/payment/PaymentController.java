package com.flightbooking.payment;

import com.flightbooking.booking.Booking;
import com.flightbooking.booking.BookingRepository;
import com.flightbooking.common.ApiResponse;
import com.flightbooking.exception.ResourceNotFoundException;
import com.flightbooking.notification.NotificationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentRepository paymentRepository;
    private final BookingRepository bookingRepository;
    private final NotificationService notificationService;

    @PostMapping("/simulate")
    @Transactional
    public ResponseEntity<ApiResponse<PaymentDto>> simulatePayment(@Valid @RequestBody PaymentSimulationRequest request) {
        Booking booking = bookingRepository.findById(request.getBookingId())
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found: " + request.getBookingId()));

        String txnId = "TXN-" + System.currentTimeMillis();
        Payment payment = Payment.builder()
                .booking(booking)
                .transactionId(txnId)
                .paymentMethod(request.getPaymentMethod().toUpperCase())
                .amount(request.getAmount() != null ? request.getAmount() : booking.getTotalAmount())
                .status("SUCCESS")
                .paymentGateway("SIMULATED")
                .paymentTime(LocalDateTime.now())
                .build();

        Payment saved = paymentRepository.save(payment);
        booking.setStatus("CONFIRMED");
        bookingRepository.save(booking);

        notificationService.createNotification(
                booking.getUser().getId(),
                "Payment Successful",
                "Payment of INR " + payment.getAmount() + " processed successfully via " + payment.getPaymentMethod() + ". Transaction ID: " + txnId,
                "PAYMENT_SUCCESS",
                txnId
        );

        return ResponseEntity.ok(ApiResponse.ok("Payment simulated successfully", PaymentDto.fromEntity(saved)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<PaymentDto>> getPaymentById(@PathVariable Long id) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found: " + id));
        return ResponseEntity.ok(ApiResponse.ok(PaymentDto.fromEntity(payment)));
    }

    @GetMapping("/booking/{bookingId}")
    public ResponseEntity<ApiResponse<List<PaymentDto>>> getPaymentsByBooking(@PathVariable Long bookingId) {
        List<PaymentDto> payments = paymentRepository.findByBookingId(bookingId).stream()
                .map(PaymentDto::fromEntity)
                .collect(Collectors.toList());
        return ResponseEntity.ok(ApiResponse.ok(payments));
    }
}
