package com.flightbooking.payment;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentSimulationRequest {

    @NotNull(message = "Booking ID is required")
    private Long bookingId;

    @NotBlank(message = "Payment method is required")
    private String paymentMethod; // UPI, CARD, NETBANKING

    private String simulatedAccountInfo; // e.g., "user@okhdfcbank" or "XXXX-XXXX-XXXX-1234"

    private BigDecimal amount;
}
