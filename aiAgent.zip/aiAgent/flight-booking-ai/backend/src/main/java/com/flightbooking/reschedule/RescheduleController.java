package com.flightbooking.reschedule;

import com.flightbooking.common.ApiResponse;
import com.flightbooking.flight.FlightDto;
import com.flightbooking.security.UserPrincipal;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reschedule")
@RequiredArgsConstructor
public class RescheduleController {

    private final RescheduleService rescheduleService;

    @GetMapping("/options/{bookingId}")
    public ResponseEntity<ApiResponse<List<FlightDto>>> getAlternativeOptions(@PathVariable Long bookingId) {
        return ResponseEntity.ok(ApiResponse.ok(rescheduleService.getRescheduleAlternatives(bookingId)));
    }

    @PostMapping("/booking/{bookingId}")
    public ResponseEntity<ApiResponse<RescheduleDto>> reschedule(
            @PathVariable Long bookingId,
            @RequestBody Map<String, Object> body,
            @AuthenticationPrincipal UserPrincipal user) {

        Long newFlightId = ((Number) body.get("newFlightId")).longValue();
        String notes = (String) body.get("notes");

        RescheduleDto result = rescheduleService.rescheduleBooking(bookingId, newFlightId, user.getId(), user.getRole(), notes);
        return ResponseEntity.ok(ApiResponse.ok("Booking rescheduled successfully", result));
    }
}
