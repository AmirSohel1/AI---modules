package com.flightbooking.reschedule;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RescheduleDto {
    private Long id;
    private Long bookingId;
    private String bookingReference;
    private Long oldFlightId;
    private String oldFlightNumber;
    private Long newFlightId;
    private String newFlightNumber;
    private BigDecimal fareDifference;
    private BigDecimal fee;
    private String status;
    private LocalDateTime requestedAt;
    private LocalDateTime completedAt;
    private String notes;

    public static RescheduleDto fromEntity(RescheduleRequest r) {
        return RescheduleDto.builder()
                .id(r.getId())
                .bookingId(r.getBooking().getId())
                .bookingReference(r.getBooking().getBookingReference())
                .oldFlightId(r.getOldFlight().getId())
                .oldFlightNumber(r.getOldFlight().getFlightNumber())
                .newFlightId(r.getNewFlight().getId())
                .newFlightNumber(r.getNewFlight().getFlightNumber())
                .fareDifference(r.getFareDifference())
                .fee(r.getFee())
                .status(r.getStatus())
                .requestedAt(r.getRequestedAt())
                .completedAt(r.getCompletedAt())
                .notes(r.getNotes())
                .build();
    }
}
