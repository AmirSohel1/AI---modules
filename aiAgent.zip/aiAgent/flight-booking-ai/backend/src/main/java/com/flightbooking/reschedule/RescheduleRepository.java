package com.flightbooking.reschedule;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RescheduleRepository extends JpaRepository<RescheduleRequest, Long> {
    List<RescheduleRequest> findByBookingId(Long bookingId);
}
