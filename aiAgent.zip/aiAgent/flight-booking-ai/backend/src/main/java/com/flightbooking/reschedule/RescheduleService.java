package com.flightbooking.reschedule;

import com.flightbooking.booking.Booking;
import com.flightbooking.booking.BookingPassenger;
import com.flightbooking.booking.BookingRepository;
import com.flightbooking.exception.BadRequestException;
import com.flightbooking.exception.ResourceNotFoundException;
import com.flightbooking.exception.UnauthorizedException;
import com.flightbooking.flight.Flight;
import com.flightbooking.flight.FlightDto;
import com.flightbooking.flight.FlightRepository;
import com.flightbooking.flight.FlightService;
import com.flightbooking.notification.NotificationService;
import com.flightbooking.seat.FlightSeat;
import com.flightbooking.seat.FlightSeatRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class RescheduleService {

    private final BookingRepository bookingRepository;
    private final RescheduleRepository rescheduleRepository;
    private final FlightRepository flightRepository;
    private final FlightSeatRepository seatRepository;
    private final NotificationService notificationService;

    @Transactional(readOnly = true)
    public List<FlightDto> getRescheduleAlternatives(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found: " + bookingId));

        Flight currentFlight = booking.getFlight();
        List<Flight> alternatives = flightRepository.findAlternativeFlights(
                currentFlight.getSourceAirport().getId(),
                currentFlight.getDestinationAirport().getId(),
                LocalDateTime.now(),
                currentFlight.getId()
        );

        return alternatives.stream()
                .map(f -> {
                    long available = seatRepository.countAvailableSeatsByFlightId(f.getId());
                    return FlightDto.fromEntity(f, available);
                })
                .collect(Collectors.toList());
    }

    @Transactional
    public RescheduleDto rescheduleBooking(Long bookingId, Long newFlightId, Long userId, String userRole, String notes) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found: " + bookingId));

        if (!"ROLE_ADMIN".equals(userRole) && !"ROLE_STAFF".equals(userRole)
                && !"ADMIN".equals(userRole) && !"STAFF".equals(userRole)) {
            if (!booking.getUser().getId().equals(userId)) {
                throw new UnauthorizedException("You do not have permission to reschedule this booking");
            }
        }

        Flight oldFlight = booking.getFlight();
        Flight newFlight = flightRepository.findById(newFlightId)
                .orElseThrow(() -> new ResourceNotFoundException("New flight not found: " + newFlightId));

        if ("CANCELLED".equalsIgnoreCase(newFlight.getStatus())) {
            throw new BadRequestException("Target flight is cancelled and cannot be booked");
        }

        // Release old seats
        for (BookingPassenger bp : booking.getPassengers()) {
            if (bp.getSeat() != null) {
                FlightSeat oldSeat = bp.getSeat();
                oldSeat.setIsAvailable(true);
                seatRepository.save(oldSeat);
            }
        }

        // Allocate available seats on new flight
        List<FlightSeat> availableNewSeats = seatRepository.findByFlightIdAndIsAvailableTrue(newFlight.getId());
        if (availableNewSeats.size() < booking.getPassengers().size()) {
            throw new BadRequestException("Not enough seats available on the new flight");
        }

        for (int i = 0; i < booking.getPassengers().size(); i++) {
            BookingPassenger bp = booking.getPassengers().get(i);
            FlightSeat newSeat = availableNewSeats.get(i);
            newSeat.setIsAvailable(false);
            seatRepository.save(newSeat);

            bp.setSeat(newSeat);
            bp.setSeatNumber(newSeat.getSeatNumber());
        }

        // Calculate fee & fare difference
        boolean isAirlineDisrupted = "CANCELLED".equalsIgnoreCase(oldFlight.getStatus()) || oldFlight.getDelayMinutes() > 120;
        BigDecimal fee = isAirlineDisrupted ? BigDecimal.ZERO : BigDecimal.valueOf(1500);
        BigDecimal fareDiff = BigDecimal.ZERO;

        if (!isAirlineDisrupted) {
            BigDecimal diff = newFlight.getBasePrice().subtract(oldFlight.getBasePrice());
            if (diff.compareTo(BigDecimal.ZERO) > 0) {
                fareDiff = diff.multiply(BigDecimal.valueOf(booking.getPassengers().size()));
            }
        }

        booking.setFlight(newFlight);
        booking.setStatus("RESCHEDULED");
        booking.setTravelDate(newFlight.getDepartureTime().toLocalDate());
        booking.setTotalAmount(booking.getTotalAmount().add(fareDiff).add(fee));
        bookingRepository.save(booking);

        RescheduleRequest req = RescheduleRequest.builder()
                .booking(booking)
                .oldFlight(oldFlight)
                .newFlight(newFlight)
                .fareDifference(fareDiff)
                .fee(fee)
                .status("COMPLETED")
                .completedAt(LocalDateTime.now())
                .notes(notes != null ? notes : (isAirlineDisrupted ? "Free reschedule due to flight disruption" : "Passenger voluntary change"))
                .build();
        RescheduleRequest savedReq = rescheduleRepository.save(req);

        notificationService.createNotification(
                booking.getUser().getId(),
                "Flight Rescheduled: " + newFlight.getFlightNumber(),
                "Your booking " + booking.getBookingReference() + " has been successfully rescheduled to flight " +
                        newFlight.getFlightNumber() + " departing at " + newFlight.getDepartureTime(),
                "RESCHEDULE_AVAILABLE",
                booking.getBookingReference()
        );

        return RescheduleDto.fromEntity(savedReq);
    }
}
