package com.flightbooking.seat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightSeatDto {
    private Long id;
    private Long flightId;
    private String seatNumber;
    private String seatClass;
    private BigDecimal priceMultiplier;
    private Boolean isAvailable;

    public static FlightSeatDto fromEntity(FlightSeat seat) {
        return FlightSeatDto.builder()
                .id(seat.getId())
                .flightId(seat.getFlight().getId())
                .seatNumber(seat.getSeatNumber())
                .seatClass(seat.getSeatClass())
                .priceMultiplier(seat.getPriceMultiplier())
                .isAvailable(seat.getIsAvailable())
                .build();
    }
}
