package com.flightbooking.seat;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FlightSeatRepository extends JpaRepository<FlightSeat, Long> {
    List<FlightSeat> findByFlightId(Long flightId);
    List<FlightSeat> findByFlightIdAndIsAvailableTrue(Long flightId);
    Optional<FlightSeat> findByFlightIdAndSeatNumber(Long flightId, String seatNumber);

    @Query("SELECT COUNT(s) FROM FlightSeat s WHERE s.flight.id = :flightId AND s.isAvailable = true")
    long countAvailableSeatsByFlightId(@Param("flightId") Long flightId);
}
