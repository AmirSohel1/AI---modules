package com.flightbooking.staff;

import com.flightbooking.accessibility.AccessibilityRequestRepository;
import com.flightbooking.baggage.BaggageCaseRepository;
import com.flightbooking.booking.BookingRepository;
import com.flightbooking.booking.BookingResponseDto;
import com.flightbooking.cancellation.CancellationRepository;
import com.flightbooking.common.ApiResponse;
import com.flightbooking.flight.FlightRepository;
import com.flightbooking.notification.NotificationRepository;
import com.flightbooking.security.UserPrincipal;
import com.flightbooking.user.User;
import com.flightbooking.user.UserDto;
import com.flightbooking.user.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/staff")
@PreAuthorize("hasAnyRole('STAFF', 'ADMIN')")
@RequiredArgsConstructor
public class StaffController {

    private final FlightRepository flightRepository;
    private final BaggageCaseRepository baggageRepository;
    private final AccessibilityRequestRepository accessibilityRepository;
    private final CancellationRepository cancellationRepository;
    private final NotificationRepository notificationRepository;
    private final UserRepository userRepository;
    private final BookingRepository bookingRepository;

    @GetMapping("/dashboard")
    public ResponseEntity<ApiResponse<StaffDashboardDto>> getStaffDashboard(@AuthenticationPrincipal UserPrincipal user) {
        StaffDashboardDto dashboard = StaffDashboardDto.builder()
                .activeFlightsCount(flightRepository.countByStatus("SCHEDULED"))
                .delayedFlightsCount(flightRepository.countByStatus("DELAYED"))
                .cancelledFlightsCount(flightRepository.countByStatus("CANCELLED"))
                .pendingBaggageCasesCount(baggageRepository.countByStatus("REPORTED") + baggageRepository.countByStatus("INVESTIGATING"))
                .pendingAccessibilityRequestsCount(accessibilityRepository.countByStatus("PENDING"))
                .pendingCancellationsCount(cancellationRepository.count())
                .unreadAlertsCount(notificationRepository.countByUserIdAndIsReadFalse(user.getId()))
                .build();

        return ResponseEntity.ok(ApiResponse.ok(dashboard));
    }

    @GetMapping("/passengers")
    public ResponseEntity<ApiResponse<List<UserDto>>> searchPassengers(@RequestParam(required = false) String query) {
        List<User> passengers = userRepository.findByRole("PASSENGER");
        if (query != null && !query.isBlank()) {
            String q = query.toLowerCase();
            passengers = passengers.stream()
                    .filter(u -> u.getFullName().toLowerCase().contains(q) ||
                                 u.getEmail().toLowerCase().contains(q) ||
                                 (u.getPhone() != null && u.getPhone().contains(q)))
                    .collect(Collectors.toList());
        }
        return ResponseEntity.ok(ApiResponse.ok(passengers.stream().map(UserDto::fromEntity).collect(Collectors.toList())));
    }

    @GetMapping("/bookings")
    public ResponseEntity<ApiResponse<List<BookingResponseDto>>> searchBookings(@RequestParam(required = false) String query) {
        List<BookingResponseDto> all = bookingRepository.findAll().stream()
                .map(BookingResponseDto::fromEntity)
                .collect(Collectors.toList());

        if (query != null && !query.isBlank()) {
            String q = query.toLowerCase();
            all = all.stream()
                    .filter(b -> b.getBookingReference().toLowerCase().contains(q) ||
                                 (b.getUserName() != null && b.getUserName().toLowerCase().contains(q)) ||
                                 (b.getFlight() != null && b.getFlight().getFlightNumber().toLowerCase().contains(q)))
                    .collect(Collectors.toList());
        }

        return ResponseEntity.ok(ApiResponse.ok(all));
    }
}
