package com.flightbooking.staff;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StaffDashboardDto {
    private long activeFlightsCount;
    private long delayedFlightsCount;
    private long cancelledFlightsCount;
    private long pendingBaggageCasesCount;
    private long pendingAccessibilityRequestsCount;
    private long pendingCancellationsCount;
    private long unreadAlertsCount;
}
