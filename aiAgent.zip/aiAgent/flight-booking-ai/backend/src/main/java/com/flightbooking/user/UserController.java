package com.flightbooking.user;

import com.flightbooking.common.ApiResponse;
import com.flightbooking.security.UserPrincipal;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @GetMapping("/me")
    public ResponseEntity<ApiResponse<UserDto>> getCurrentUser(@AuthenticationPrincipal UserPrincipal currentUser) {
        return ResponseEntity.ok(ApiResponse.ok(userService.getUserById(currentUser.getId())));
    }

    @PutMapping("/profile")
    public ResponseEntity<ApiResponse<UserDto>> updateProfile(@AuthenticationPrincipal UserPrincipal currentUser,
                                                              @RequestBody UserDto request) {
        UserDto updated = userService.updateUserProfile(currentUser.getId(), request.getFullName(), request.getPhone());
        return ResponseEntity.ok(ApiResponse.ok("Profile updated successfully", updated));
    }
}
