-- ===================================================
-- Flyway Migration V2: Seed Data
-- AI-Powered Intelligent Flight Booking System
-- ===================================================

-- 1. ROLES
INSERT INTO roles (name, description) VALUES
('ROLE_PASSENGER', 'Standard passenger access for searching, booking, and managing flights'),
('ROLE_STAFF', 'Airline and airport staff for operations, baggage, disruptions, and complaints'),
('ROLE_ADMIN', 'System administrator with full operational, analytics, and AI management privileges');

-- 2. USERS (Initial passwords with RAW: prefix will be auto-hashed by Spring DataInitializer on first boot)
INSERT INTO users (username, email, password_hash, full_name, phone, role, status) VALUES
('admin', 'admin@flightai.local', 'RAW:Admin@123', 'Rajesh Sharma (System Admin)', '+91 9876543210', 'ADMIN', 'ACTIVE'),
('staff', 'staff@flightai.local', 'RAW:Staff@123', 'Pooja Verma (Ground Operations)', '+91 9876543211', 'STAFF', 'ACTIVE'),
('passenger', 'passenger@flightai.local', 'RAW:Passenger@123', 'Aarav Patel', '+91 9876543212', 'PASSENGER', 'ACTIVE'),
('staff_rahul', 'rahul.staff@flightai.local', 'RAW:Staff@123', 'Rahul Nair (Duty Manager)', '+91 9876543213', 'STAFF', 'ACTIVE'),
('staff_priya', 'priya.staff@flightai.local', 'RAW:Staff@123', 'Priya Iyer (Baggage Officer)', '+91 9876543214', 'STAFF', 'ACTIVE'),
('staff_vikram', 'vikram.staff@flightai.local', 'RAW:Staff@123', 'Vikram Singh (Customer Support)', '+91 9876543215', 'STAFF', 'ACTIVE'),
('staff_ananya', 'ananya.staff@flightai.local', 'RAW:Staff@123', 'Ananya Sen (Special Assistance)', '+91 9876543216', 'STAFF', 'ACTIVE'),
('pass_rohit', 'rohit.sharma@example.com', 'RAW:Passenger@123', 'Rohit Sharma', '+91 9811122201', 'PASSENGER', 'ACTIVE'),
('pass_sneha', 'sneha.kulkarni@example.com', 'RAW:Passenger@123', 'Sneha Kulkarni', '+91 9811122202', 'PASSENGER', 'ACTIVE'),
('pass_amit', 'amit.gupta@example.com', 'RAW:Passenger@123', 'Amit Gupta', '+91 9811122203', 'PASSENGER', 'ACTIVE'),
('pass_divya', 'divya.menon@example.com', 'RAW:Passenger@123', 'Divya Menon', '+91 9811122204', 'PASSENGER', 'ACTIVE'),
('pass_karan', 'karan.malhotra@example.com', 'RAW:Passenger@123', 'Karan Malhotra', '+91 9811122205', 'PASSENGER', 'ACTIVE'),
('pass_neha', 'neha.jain@example.com', 'RAW:Passenger@123', 'Neha Jain', '+91 9811122206', 'PASSENGER', 'ACTIVE'),
('pass_suresh', 'suresh.reddy@example.com', 'RAW:Passenger@123', 'Suresh Reddy', '+91 9811122207', 'PASSENGER', 'ACTIVE'),
('pass_kavita', 'kavita.deshmukh@example.com', 'RAW:Passenger@123', 'Kavita Deshmukh', '+91 9811122208', 'PASSENGER', 'ACTIVE'),
('pass_manoj', 'manoj.tiwari@example.com', 'RAW:Passenger@123', 'Manoj Tiwari', '+91 9811122209', 'PASSENGER', 'ACTIVE'),
('pass_pooja', 'pooja.mehta@example.com', 'RAW:Passenger@123', 'Pooja Mehta', '+91 9811122210', 'PASSENGER', 'ACTIVE'),
('pass_arjun', 'arjun.kapoor@example.com', 'RAW:Passenger@123', 'Arjun Kapoor', '+91 9811122211', 'PASSENGER', 'ACTIVE'),
('pass_meera', 'meera.das@example.com', 'RAW:Passenger@123', 'Meera Das', '+91 9811122212', 'PASSENGER', 'ACTIVE'),
('pass_deepak', 'deepak.chopra@example.com', 'RAW:Passenger@123', 'Deepak Chopra', '+91 9811122213', 'PASSENGER', 'ACTIVE'),
('pass_ritika', 'ritika.bose@example.com', 'RAW:Passenger@123', 'Ritika Bose', '+91 9811122214', 'PASSENGER', 'ACTIVE'),
('pass_sanjay', 'sanjay.dutt@example.com', 'RAW:Passenger@123', 'Sanjay Dutt', '+91 9811122215', 'PASSENGER', 'ACTIVE'),
('pass_tanvi', 'tanvi.joshi@example.com', 'RAW:Passenger@123', 'Tanvi Joshi', '+91 9811122216', 'PASSENGER', 'ACTIVE'),
('pass_harsh', 'harsh.vardhan@example.com', 'RAW:Passenger@123', 'Harsh Vardhan', '+91 9811122217', 'PASSENGER', 'ACTIVE'),
('pass_swati', 'swati.patil@example.com', 'RAW:Passenger@123', 'Swati Patil', '+91 9811122218', 'PASSENGER', 'ACTIVE'),
('pass_varun', 'varun.dhavan@example.com', 'RAW:Passenger@123', 'Varun Dhawan', '+91 9811122219', 'PASSENGER', 'ACTIVE'),
('pass_ishita', 'ishita.sharma@example.com', 'RAW:Passenger@123', 'Ishita Sharma', '+91 9811122220', 'PASSENGER', 'ACTIVE');

-- 3. USER ROLES MAPPING
INSERT INTO user_roles (user_id, role_id) VALUES
(1, 3), -- admin -> ROLE_ADMIN
(2, 2), -- staff -> ROLE_STAFF
(3, 1), -- passenger -> ROLE_PASSENGER
(4, 2), (5, 2), (6, 2), (7, 2),
(8, 1), (9, 1), (10, 1), (11, 1), (12, 1), (13, 1), (14, 1), (15, 1),
(16, 1), (17, 1), (18, 1), (19, 1), (20, 1), (21, 1), (22, 1), (23, 1),
(24, 1), (25, 1), (26, 1), (27, 1);

-- 4. STAFF PROFILES
INSERT INTO staff_profiles (user_id, employee_id, department, designation, shift) VALUES
(2, 'EMP-1001', 'Ground Operations', 'Lead Ground Executive', 'Morning'),
(4, 'EMP-1002', 'Airport Management', 'Duty Airport Manager', 'Day'),
(5, 'EMP-1003', 'Baggage Services', 'Senior Baggage Specialist', 'Evening'),
(6, 'EMP-1004', 'Customer Support', 'Passenger Care Representative', 'General'),
(7, 'EMP-1005', 'Special Assistance', 'Accessibility Coordinator', 'Morning');

-- 5. PASSENGERS
INSERT INTO passengers (user_id, passport_number, date_of_birth, gender, nationality, emergency_contact) VALUES
(3, 'Z1234567', '1995-04-12', 'MALE', 'Indian', '+91 9876500001'),
(8, 'Z2345678', '1987-04-30', 'MALE', 'Indian', '+91 9876500002'),
(9, 'Z3456789', '1992-09-18', 'FEMALE', 'Indian', '+91 9876500003'),
(10, 'Z4567890', '1990-11-25', 'MALE', 'Indian', '+91 9876500004'),
(11, 'Z5678901', '1996-03-14', 'FEMALE', 'Indian', '+91 9876500005'),
(12, 'Z6789012', '1989-07-22', 'MALE', 'Indian', '+91 9876500006'),
(13, 'Z7890123', '1994-01-05', 'FEMALE', 'Indian', '+91 9876500007'),
(14, 'Z8901234', '1982-12-10', 'MALE', 'Indian', '+91 9876500008'),
(15, 'Z9012345', '1998-05-19', 'FEMALE', 'Indian', '+91 9876500009'),
(16, 'Z0123456', '1985-08-30', 'MALE', 'Indian', '+91 9876500010'),
(17, 'Z1122334', '1993-02-17', 'FEMALE', 'Indian', '+91 9876500011'),
(18, 'Z2233445', '1991-06-28', 'MALE', 'Indian', '+91 9876500012'),
(19, 'Z3344556', '1997-10-09', 'FEMALE', 'Indian', '+91 9876500013'),
(20, 'Z4455667', '1984-03-21', 'MALE', 'Indian', '+91 9876500014'),
(21, 'Z5566778', '1999-12-04', 'FEMALE', 'Indian', '+91 9876500015'),
(22, 'Z6677889', '1980-07-15', 'MALE', 'Indian', '+91 9876500016'),
(23, 'Z7788990', '1995-11-11', 'FEMALE', 'Indian', '+91 9876500017'),
(24, 'Z8899001', '1988-09-02', 'MALE', 'Indian', '+91 9876500018'),
(25, 'Z9900112', '1992-04-14', 'FEMALE', 'Indian', '+91 9876500019'),
(26, 'Z1029384', '1994-08-25', 'MALE', 'Indian', '+91 9876500020'),
(27, 'Z2039485', '1996-01-31', 'FEMALE', 'Indian', '+91 9876500021');

-- 6. PASSENGER PREFERENCES
INSERT INTO passenger_preferences (user_id, preferred_seat_type, preferred_class, meal_preference, preferred_departure_time, consent_given) VALUES
(3, 'AISLE', 'ECONOMY', 'VEG', 'MORNING', TRUE),
(8, 'WINDOW', 'BUSINESS', 'NON_VEG', 'EVENING', TRUE),
(9, 'WINDOW', 'ECONOMY', 'VEGAN', 'MORNING', TRUE),
(10, 'AISLE', 'ECONOMY', 'JAIN', 'AFTERNOON', TRUE),
(11, 'WINDOW', 'ECONOMY', 'VEG', 'MORNING', TRUE);

-- 7. AIRLINES
INSERT INTO airlines (code, name, logo_url, contact_number, status) VALUES
('AI', 'Air India', 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=100&q=80', '+91 1800 180 1407', 'ACTIVE'),
('6E', 'IndiGo Airlines', 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?auto=format&fit=crop&w=100&q=80', '+91 9910 383 838', 'ACTIVE'),
('UK', 'Vistara Airlines', 'https://images.unsplash.com/photo-1520437358207-323b43b50729?auto=format&fit=crop&w=100&q=80', '+91 9289 228 888', 'ACTIVE'),
('QP', 'Akasa Air', 'https://images.unsplash.com/photo-1517479149777-5f3b1511d5ad?auto=format&fit=crop&w=100&q=80', '+91 9606 112 131', 'ACTIVE');

-- 8. AIRPORTS
INSERT INTO airports (code, name, city, country, terminal_count) VALUES
('BOM', 'Chhatrapati Shivaji Maharaj International Airport', 'Mumbai', 'India', 2),
('DEL', 'Indira Gandhi International Airport', 'Delhi', 'India', 3),
('BLR', 'Kempegowda International Airport', 'Bengaluru', 'India', 2),
('MAA', 'Chennai International Airport', 'Chennai', 'India', 2),
('HYD', 'Rajiv Gandhi International Airport', 'Hyderabad', 'India', 1),
('CCU', 'Netaji Subhash Chandra Bose International Airport', 'Kolkata', 'India', 1),
('PNQ', 'Pune International Airport', 'Pune', 'India', 1),
('GOI', 'Dabolim Airport', 'Goa', 'India', 1);

-- 9. AIRCRAFT
INSERT INTO aircraft (airline_id, model, registration_number, total_seats, economy_seats, business_seats, status) VALUES
(1, 'Boeing 787-8 Dreamliner', 'VT-ANI', 256, 238, 18, 'ACTIVE'),
(1, 'Airbus A320neo', 'VT-EXF', 180, 168, 12, 'ACTIVE'),
(1, 'Airbus A321neo', 'VT-RTD', 192, 180, 12, 'ACTIVE'),
(2, 'Airbus A320neo', 'VT-IZB', 186, 186, 0, 'ACTIVE'),
(2, 'Airbus A321neo', 'VT-IMD', 222, 222, 0, 'ACTIVE'),
(2, 'Airbus A320neo', 'VT-IHN', 186, 186, 0, 'ACTIVE'),
(3, 'Airbus A320neo', 'VT-TNC', 158, 126, 32, 'ACTIVE'),
(3, 'Boeing 787-9 Dreamliner', 'VT-TSD', 299, 248, 51, 'ACTIVE'),
(3, 'Airbus A321neo', 'VT-TVE', 188, 144, 44, 'ACTIVE'),
(4, 'Boeing 737-MAX 8', 'VT-YAA', 189, 189, 0, 'ACTIVE'),
(4, 'Boeing 737-MAX 8', 'VT-YAB', 189, 189, 0, 'ACTIVE'),
(2, 'Airbus A320neo', 'VT-ITR', 186, 186, 0, 'ACTIVE');

-- 10. FLIGHTS (30 sample flights across key Indian routes)
INSERT INTO flights (flight_number, airline_id, aircraft_id, source_airport_id, destination_airport_id, departure_time, arrival_time, duration_minutes, stops, base_price, status, delay_reason, delay_minutes) VALUES
-- BOM to DEL
('AI-806', 1, 1, 1, 2, '2026-11-25 06:00:00', '2026-11-25 08:15:00', 135, 0, 5400.00, 'SCHEDULED', NULL, 0),
('6E-204', 2, 4, 1, 2, '2026-11-25 07:30:00', '2026-11-25 09:45:00', 135, 0, 4800.00, 'CANCELLED', 'Technical maintenance check required', 0),
('UK-970', 3, 7, 1, 2, '2026-11-25 09:00:00', '2026-11-25 11:15:00', 135, 0, 6200.00, 'SCHEDULED', NULL, 0),
('QP-1102', 4, 10, 1, 2, '2026-11-25 14:15:00', '2026-11-25 16:30:00', 135, 0, 4500.00, 'SCHEDULED', NULL, 0),
('6E-512', 2, 5, 1, 2, '2026-11-25 18:00:00', '2026-11-25 20:15:00', 135, 0, 5200.00, 'DELAYED', 'Air traffic congestion at destination', 45),
('AI-665', 1, 2, 1, 2, '2026-11-25 21:30:00', '2026-11-25 23:45:00', 135, 0, 4900.00, 'SCHEDULED', NULL, 0),

-- DEL to BLR
('UK-811', 3, 7, 2, 3, '2026-11-25 06:45:00', '2026-11-25 09:30:00', 165, 0, 6800.00, 'SCHEDULED', NULL, 0),
('6E-188', 2, 4, 2, 3, '2026-11-25 11:00:00', '2026-11-25 13:50:00', 170, 0, 5500.00, 'SCHEDULED', NULL, 0),
('AI-504', 1, 3, 2, 3, '2026-11-25 16:30:00', '2026-11-25 19:15:00', 165, 0, 5900.00, 'SCHEDULED', NULL, 0),
('QP-1334', 4, 11, 2, 3, '2026-11-25 20:10:00', '2026-11-25 23:00:00', 170, 0, 5100.00, 'SCHEDULED', NULL, 0),

-- BLR to BOM
('6E-451', 2, 6, 3, 1, '2026-11-25 07:00:00', '2026-11-25 08:45:00', 105, 0, 4200.00, 'SCHEDULED', NULL, 0),
('AI-640', 1, 2, 3, 1, '2026-11-25 12:30:00', '2026-11-25 14:15:00', 105, 0, 4600.00, 'SCHEDULED', NULL, 0),
('UK-852', 3, 7, 3, 1, '2026-11-25 17:45:00', '2026-11-25 19:30:00', 105, 0, 5400.00, 'SCHEDULED', NULL, 0),

-- BOM to GOI
('6E-344', 2, 4, 1, 8, '2026-11-25 08:30:00', '2026-11-25 09:40:00', 70, 0, 3400.00, 'SCHEDULED', NULL, 0),
('AI-033', 1, 2, 1, 8, '2026-11-25 15:00:00', '2026-11-25 16:15:00', 75, 0, 3900.00, 'SCHEDULED', NULL, 0),

-- DEL to CCU
('6E-621', 2, 5, 2, 6, '2026-11-25 06:15:00', '2026-11-25 08:30:00', 135, 0, 5100.00, 'SCHEDULED', NULL, 0),
('AI-701', 1, 3, 2, 6, '2026-11-25 13:00:00', '2026-11-25 15:15:00', 135, 0, 5600.00, 'SCHEDULED', NULL, 0),

-- BOM to HYD
('UK-871', 3, 7, 1, 5, '2026-11-25 07:15:00', '2026-11-25 08:45:00', 90, 0, 4300.00, 'SCHEDULED', NULL, 0),
('6E-728', 2, 6, 1, 5, '2026-11-25 14:00:00', '2026-11-25 15:30:00', 90, 0, 3900.00, 'SCHEDULED', NULL, 0),

-- HYD to MAA
('6E-902', 2, 4, 5, 4, '2026-11-25 09:30:00', '2026-11-25 10:45:00', 75, 0, 3600.00, 'SCHEDULED', NULL, 0),
('AI-543', 1, 2, 5, 4, '2026-11-25 17:15:00', '2026-11-25 18:30:00', 75, 0, 4100.00, 'SCHEDULED', NULL, 0),

-- PNQ to DEL
('6E-2419', 2, 5, 7, 2, '2026-11-25 08:00:00', '2026-11-25 10:15:00', 135, 0, 5300.00, 'SCHEDULED', NULL, 0),
('AI-850', 1, 3, 7, 2, '2026-11-25 19:00:00', '2026-11-25 21:15:00', 135, 0, 5800.00, 'SCHEDULED', NULL, 0),

-- Connected / 1-stop routes
('6E-301', 2, 4, 1, 4, '2026-11-25 06:30:00', '2026-11-25 10:45:00', 255, 1, 5700.00, 'SCHEDULED', NULL, 0),
('AI-441', 1, 2, 2, 8, '2026-11-25 09:15:00', '2026-11-25 14:30:00', 315, 1, 7200.00, 'SCHEDULED', NULL, 0),

-- Past & Arrived flights for historical analytics
('AI-101', 1, 1, 1, 2, '2026-11-20 06:00:00', '2026-11-20 08:15:00', 135, 0, 5200.00, 'ARRIVED', NULL, 0),
('6E-102', 2, 4, 2, 3, '2026-11-20 10:00:00', '2026-11-20 12:45:00', 165, 0, 5400.00, 'ARRIVED', NULL, 0),
('UK-103', 3, 7, 3, 1, '2026-11-20 15:00:00', '2026-11-20 16:45:00', 105, 0, 5100.00, 'ARRIVED', NULL, 0),
('6E-104', 2, 5, 1, 5, '2026-11-20 18:30:00', '2026-11-20 20:00:00', 90, 0, 3800.00, 'ARRIVED', NULL, 0),
('QP-105', 4, 10, 7, 2, '2026-11-20 21:00:00', '2026-11-20 23:15:00', 135, 0, 4900.00, 'ARRIVED', NULL, 0);

-- 11. FLIGHT SEATS (Generate standard seats 1A-1F up to row 10 for all 30 flights)
-- Flight 1 (AI-806)
INSERT INTO flight_seats (flight_id, seat_number, seat_class, price_multiplier, is_available) VALUES
(1, '1A', 'BUSINESS', 2.00, FALSE), (1, '1B', 'BUSINESS', 2.00, TRUE), (1, '1C', 'BUSINESS', 2.00, TRUE),
(1, '1D', 'BUSINESS', 2.00, TRUE), (1, '1E', 'BUSINESS', 2.00, TRUE), (1, '1F', 'BUSINESS', 2.00, TRUE),
(1, '2A', 'BUSINESS', 2.00, TRUE), (1, '2B', 'BUSINESS', 2.00, TRUE), (1, '2C', 'BUSINESS', 2.00, TRUE),
(1, '3A', 'ECONOMY', 1.00, FALSE), (1, '3B', 'ECONOMY', 1.00, FALSE), (1, '3C', 'ECONOMY', 1.00, TRUE),
(1, '3D', 'ECONOMY', 1.00, TRUE), (1, '3E', 'ECONOMY', 1.00, TRUE), (1, '3F', 'ECONOMY', 1.00, TRUE),
(1, '4A', 'ECONOMY', 1.00, TRUE), (1, '4B', 'ECONOMY', 1.00, TRUE), (1, '4C', 'ECONOMY', 1.00, TRUE),
(1, '4D', 'ECONOMY', 1.00, TRUE), (1, '4E', 'ECONOMY', 1.00, TRUE), (1, '4F', 'ECONOMY', 1.00, TRUE),
(1, '5A', 'ECONOMY', 1.00, TRUE), (1, '5B', 'ECONOMY', 1.00, TRUE), (1, '5C', 'ECONOMY', 1.00, TRUE),
(1, '5D', 'ECONOMY', 1.00, TRUE), (1, '5E', 'ECONOMY', 1.00, TRUE), (1, '5F', 'ECONOMY', 1.00, TRUE);

-- Flight 2 (6E-204 - Cancelled flight with affected bookings)
INSERT INTO flight_seats (flight_id, seat_number, seat_class, price_multiplier, is_available) VALUES
(2, '1A', 'ECONOMY', 1.00, FALSE), (2, '1B', 'ECONOMY', 1.00, FALSE), (2, '1C', 'ECONOMY', 1.00, FALSE),
(2, '2A', 'ECONOMY', 1.00, FALSE), (2, '2B', 'ECONOMY', 1.00, FALSE), (2, '2C', 'ECONOMY', 1.00, TRUE),
(2, '3A', 'ECONOMY', 1.00, TRUE), (2, '3B', 'ECONOMY', 1.00, TRUE), (2, '3C', 'ECONOMY', 1.00, TRUE);

-- Flight 3 (UK-970)
INSERT INTO flight_seats (flight_id, seat_number, seat_class, price_multiplier, is_available) VALUES
(3, '1A', 'BUSINESS', 1.80, TRUE), (3, '1B', 'BUSINESS', 1.80, TRUE), (3, '1C', 'BUSINESS', 1.80, TRUE),
(3, '2A', 'ECONOMY', 1.00, TRUE), (3, '2B', 'ECONOMY', 1.00, TRUE), (3, '2C', 'ECONOMY', 1.00, TRUE),
(3, '3A', 'ECONOMY', 1.00, TRUE), (3, '3B', 'ECONOMY', 1.00, TRUE), (3, '3C', 'ECONOMY', 1.00, TRUE);

-- Flight 4 (QP-1102)
INSERT INTO flight_seats (flight_id, seat_number, seat_class, price_multiplier, is_available) VALUES
(4, '1A', 'ECONOMY', 1.00, TRUE), (4, '1B', 'ECONOMY', 1.00, TRUE), (4, '1C', 'ECONOMY', 1.00, TRUE),
(4, '2A', 'ECONOMY', 1.00, TRUE), (4, '2B', 'ECONOMY', 1.00, TRUE), (4, '2C', 'ECONOMY', 1.00, TRUE),
(4, '3A', 'ECONOMY', 1.00, TRUE), (4, '3B', 'ECONOMY', 1.00, TRUE), (4, '3C', 'ECONOMY', 1.00, TRUE);

-- Flight 5 (6E-512 - Delayed)
INSERT INTO flight_seats (flight_id, seat_number, seat_class, price_multiplier, is_available) VALUES
(5, '1A', 'ECONOMY', 1.00, FALSE), (5, '1B', 'ECONOMY', 1.00, FALSE), (5, '1C', 'ECONOMY', 1.00, TRUE),
(5, '2A', 'ECONOMY', 1.00, TRUE), (5, '2B', 'ECONOMY', 1.00, TRUE), (5, '2C', 'ECONOMY', 1.00, TRUE);

-- Populate general seats for flights 6 to 30
INSERT INTO flight_seats (flight_id, seat_number, seat_class, price_multiplier, is_available)
SELECT f.id, s.seat_num, 
       CASE WHEN s.seat_num LIKE '1%' THEN 'BUSINESS' ELSE 'ECONOMY' END,
       CASE WHEN s.seat_num LIKE '1%' THEN 1.80 ELSE 1.00 END,
       TRUE
FROM flights f
CROSS JOIN (
    SELECT '1A' AS seat_num UNION ALL SELECT '1B' UNION ALL SELECT '1C' UNION ALL
    SELECT '2A' UNION ALL SELECT '2B' UNION ALL SELECT '2C' UNION ALL
    SELECT '3A' UNION ALL SELECT '3B' UNION ALL SELECT '3C' UNION ALL
    SELECT '4A' UNION ALL SELECT '4B' UNION ALL SELECT '4C' UNION ALL
    SELECT '5A' UNION ALL SELECT '5B' UNION ALL SELECT '5C'
) s
WHERE f.id BETWEEN 6 AND 30;

-- 12. SAMPLE BOOKINGS (Generate realistic 100+ bookings)
-- Bookings for demo passenger (user_id = 3)
INSERT INTO bookings (booking_reference, user_id, flight_id, booking_date, travel_date, total_amount, status, contact_email, contact_phone) VALUES
('AI-829101', 3, 1, '2026-11-18 10:30:00', '2026-11-25', 5400.00, 'CONFIRMED', 'passenger@flightai.local', '+91 9876543212'),
('6E-829102', 3, 2, '2026-11-19 14:15:00', '2026-11-25', 4800.00, 'CANCELLED', 'passenger@flightai.local', '+91 9876543212'),
('UK-829103', 3, 7, '2026-11-20 18:45:00', '2026-11-25', 6800.00, 'CONFIRMED', 'passenger@flightai.local', '+91 9876543212'),
('AI-829104', 3, 26, '2026-11-10 09:20:00', '2026-11-20', 5200.00, 'CONFIRMED', 'passenger@flightai.local', '+91 9876543212');

-- Passenger and payment details for demo passenger bookings
INSERT INTO booking_passengers (booking_id, seat_id, full_name, age, gender, seat_number, ticket_number) VALUES
(1, 1, 'Aarav Patel', 30, 'MALE', '1A', 'ETKT-AI-00101'),
(2, 28, 'Aarav Patel', 30, 'MALE', '1A', 'ETKT-6E-00102'),
(3, 50, 'Aarav Patel', 30, 'MALE', '1A', 'ETKT-UK-00103'),
(4, NULL, 'Aarav Patel', 30, 'MALE', '3B', 'ETKT-AI-00104');

INSERT INTO payments (booking_id, transaction_id, payment_method, amount, status, payment_gateway) VALUES
(1, 'TXN-UPI-88001', 'UPI', 5400.00, 'SUCCESS', 'SIMULATED'),
(2, 'TXN-CARD-88002', 'CARD', 4800.00, 'REFUNDED', 'SIMULATED'),
(3, 'TXN-NB-88003', 'NETBANKING', 6800.00, 'SUCCESS', 'SIMULATED'),
(4, 'TXN-UPI-88004', 'UPI', 5200.00, 'SUCCESS', 'SIMULATED');

-- Additional bookings across users 8-27 and flights 1-30 to reach 100+ bookings
INSERT INTO bookings (booking_reference, user_id, flight_id, booking_date, travel_date, total_amount, status, contact_email, contact_phone)
SELECT 
    CONCAT('BK-', LPAD(u.id * 100 + f.id, 6, '0')),
    u.id,
    f.id,
    DATE_SUB(NOW(), INTERVAL ((u.id + f.id) % 30) DAY),
    f.departure_time,
    f.base_price,
    CASE 
        WHEN (u.id + f.id) % 15 = 0 THEN 'CANCELLED'
        WHEN (u.id + f.id) % 25 = 0 THEN 'RESCHEDULED'
        ELSE 'CONFIRMED'
    END,
    u.email,
    u.phone
FROM users u
CROSS JOIN flights f
WHERE u.role = 'PASSENGER' AND u.id <= 15 AND f.id <= 10;

-- Additional booking passengers
INSERT INTO booking_passengers (booking_id, full_name, age, gender, seat_number, ticket_number)
SELECT 
    b.id,
    u.full_name,
    28 + (b.id % 20),
    CASE WHEN b.id % 2 = 0 THEN 'FEMALE' ELSE 'MALE' END,
    CONCAT(CAST(((b.id % 8) + 1) AS CHAR), CHAR(65 + (b.id % 6))),
    CONCAT('TKT-', LPAD(b.id, 7, '0'))
FROM bookings b
JOIN users u ON b.user_id = u.id
WHERE b.id > 4;

-- Additional payments
INSERT INTO payments (booking_id, transaction_id, payment_method, amount, status, payment_gateway)
SELECT 
    b.id,
    CONCAT('TXN-', LPAD(b.id * 77 + 1000, 8, '0')),
    CASE 
        WHEN b.id % 3 = 0 THEN 'UPI'
        WHEN b.id % 3 = 1 THEN 'CARD'
        ELSE 'NETBANKING'
    END,
    b.total_amount,
    CASE WHEN b.status = 'CANCELLED' THEN 'REFUNDED' ELSE 'SUCCESS' END,
    'SIMULATED'
FROM bookings b
WHERE b.id > 4;

-- 13. CANCELLATION REQUESTS & REFUNDS
INSERT INTO cancellation_requests (booking_id, reason, cancellation_fee, refund_amount, status, requested_at, processed_at, staff_notes) VALUES
(2, 'Flight cancelled by airline due to maintenance', 0.00, 4800.00, 'PROCESSED', '2026-11-20 11:00:00', '2026-11-20 11:30:00', 'Full refund issued automatically due to flight disruption');

INSERT INTO refunds (cancellation_id, booking_id, amount, refund_transaction_id, status, processed_at) VALUES
(1, 2, 4800.00, 'RFND-TXN-99101', 'COMPLETED', '2026-11-20 11:30:00');

-- 14. BAGGAGE CASES
INSERT INTO baggage_cases (booking_id, passenger_id, case_reference, case_type, flight_id, tag_number, description, status, reported_at, internal_notes) VALUES
(1, 1, 'BAG-BOM-1001', 'DELAYED', 1, 'AI-BOM-9921', 'Black American Tourister trolley bag, 24 inches. Delayed at conveyor belt.', 'INVESTIGATING', '2026-11-20 14:00:00', 'Baggage identified in transit at Delhi Terminal 3 ramp. Scheduled for delivery.'),
(3, 1, 'BAG-DEL-1002', 'MISSING', 7, 'UK-DEL-7744', 'Blue Samsonite hard-case suitcase. Tag detached during loading.', 'LOCATED', '2026-11-21 16:30:00', 'Located in Bengaluru baggage sorting area. Being routed to owner.'),
(4, 1, 'BAG-BOM-1003', 'DAMAGED', 26, 'AI-BOM-1109', 'Broken side handle and cracked outer casing.', 'CLOSED', '2026-11-15 10:15:00', 'Compensation processed as per airline baggage policy.');

-- 15. FEEDBACK & SENTIMENT ANALYSIS
INSERT INTO feedback (user_id, flight_id, booking_id, rating, comment, submitted_at) VALUES
(3, 1, 1, 5, 'Exceptional experience with Air India morning flight. Crew was very polite and punctuality was on point.', '2026-11-21 12:00:00'),
(8, 2, 2, 1, 'Flight was cancelled without prior intimation! Very disappointed with the sudden cancellation.', '2026-11-20 12:30:00'),
(9, 7, 3, 4, 'Vistara flight was smooth and meals were tasty, but baggage took almost 40 minutes at carousel.', '2026-11-21 15:45:00'),
(10, 5, NULL, 2, 'Flight 6E-512 was delayed by nearly an hour without clear announcement at the gate.', '2026-11-21 21:00:00');

INSERT INTO feedback_analysis (feedback_id, sentiment, category, key_phrases, urgency_score, ai_summary) VALUES
(1, 'POSITIVE', 'CLEANLINESS', 'polite crew, on point punctuality, exceptional experience', 1, 'Passenger praised flight punctuality and cabin crew courtesy.'),
(2, 'NEGATIVE', 'FLIGHT_DELAY', 'flight cancelled, sudden cancellation, no prior intimation', 9, 'Severe dissatisfaction due to sudden flight cancellation without prior notice.'),
(3, 'NEUTRAL', 'BAGGAGE_PROBLEM', 'baggage delayed, smooth flight, tasty meals, 40 minutes wait', 5, 'Good flight experience offset by delayed baggage retrieval at carousel.'),
(4, 'NEGATIVE', 'FLIGHT_DELAY', 'delayed by hour, no clear announcement, gate delay', 7, 'Unannounced gate delay causing passenger frustration.');

-- 16. ACCESSIBILITY REQUESTS
INSERT INTO accessibility_requests (user_id, booking_id, service_type, details, status, requested_at, assigned_staff_id) VALUES
(3, 1, 'WHEELCHAIR', 'Passenger requires wheelchair from check-in counter to aircraft seat due to knee surgery.', 'ASSIGNED', '2026-11-20 15:00:00', 7),
(9, 3, 'ELDERLY_ASSISTANCE', 'Elderly passenger traveling alone. Needs meet-and-assist and buggy service at terminal.', 'PENDING', '2026-11-21 10:30:00', NULL);

-- 17. FLIGHT DISRUPTIONS
INSERT INTO flight_disruptions (flight_id, disruption_type, reason, delay_minutes, affected_passenger_count, alternatives_suggested, status) VALUES
(2, 'CANCELLATION', 'Technical maintenance check required on aircraft VT-IZB', 0, 48, 'Alternative flights suggested: AI-806 at 06:00, UK-970 at 09:00, QP-1102 at 14:15', 'ACTIVE'),
(5, 'DELAY', 'Air traffic congestion at Delhi Indira Gandhi International Airport', 45, 120, 'Flight rescheduled to depart at 18:45', 'ACTIVE');

-- 18. NOTIFICATIONS
INSERT INTO notifications (user_id, title, message, type, is_read, reference_id) VALUES
(3, 'Booking Confirmed: AI-806', 'Your flight AI-806 from Mumbai (BOM) to Delhi (DEL) on 25 Nov 2026 is confirmed. PNR: AI-829101.', 'BOOKING_CONFIRMED', FALSE, 'AI-829101'),
(3, 'Flight Cancellation Alert', 'Flight 6E-204 scheduled for 25 Nov 2026 has been cancelled due to technical maintenance. Full refund or free rescheduling available.', 'FLIGHT_CANCELLED', FALSE, '6E-204'),
(3, 'Wheelchair Assistance Assigned', 'Your wheelchair assistance request for booking AI-829101 has been assigned to Coordinator Ananya Sen.', 'ACCESSIBILITY_REQUEST_UPDATE', TRUE, 'REQ-WCH-01'),
(2, 'Urgent Disruption: 6E-204 Cancelled', 'Flight 6E-204 has been cancelled. 48 passengers affected. Review alternative rebooking options.', 'STAFF_ALERT', FALSE, '6E-204');

-- 19. KNOWLEDGE DOCUMENTS (Grounding data for RAG)
INSERT INTO knowledge_documents (title, category, filename, file_type, chunk_count, content_summary, full_text) VALUES
('Airline Flight Booking & Reservation Policy', 'BOOKING_POLICY', 'booking_policy.txt', 'TXT', 3, 'Covers booking validity, name correction rules, minor travel, and fare types.',
'AIRLINE FLIGHT BOOKING & RESERVATION POLICY
1. General Reservation Rules:
- Bookings can be made up to 365 days in advance.
- Passenger name must exactly match the government-issued photo ID (Aadhaar, Passport, Voter ID).
- Minor corrections of up to 3 characters in the passenger name are permitted free of charge up to 24 hours prior to scheduled departure.
2. Fare Types:
- Economy Saver: Standard baggage allowance (15kg check-in, 7kg cabin). Seat selection may attract nominal charges.
- Economy Flexi: Free date change up to 24 hours prior to departure. Free standard seat selection.
- Business Class: 30kg check-in baggage, 10kg cabin baggage, priority boarding, lounge access, and gourmet in-flight meals included.
3. Infants and Children:
- Infants under 2 years travel with an infant ticket without occupying a seat.
- Unaccompanied minors aged 5 to 12 require pre-booking under the Junior Aviator program.'),

('Airline Cancellation & Refund Policy', 'CANCELLATION_POLICY', 'cancellation_policy.txt', 'TXT', 4, 'Detailed rules on cancellation charges, full refund conditions, and processing timelines.',
'AIRLINE CANCELLATION & REFUND POLICY
1. Cancellation Timeline and Charges:
- More than 72 hours before departure: Cancellation fee of ₹2,500 or base fare (whichever is lower).
- Between 24 and 72 hours before departure: Cancellation fee of ₹3,000.
- Less than 24 hours before departure: Cancellation fee of ₹3,500.
- Less than 2 hours before departure (No-Show): Only statutory taxes and User Development Fee (UDF) are refundable.
2. Full Refund Scenarios (Zero Cancellation Fee):
- When a flight is cancelled or delayed by more than 2 hours by the airline, the passenger is entitled to a 100% full refund with zero deduction.
- Free cancellation is permitted within 24 hours of booking if the booking was made at least 7 days prior to flight departure.
3. Refund Processing:
- Simulated refunds are initiated immediately and credited to the original source within 5-7 business days.
- In case of booking through travel agents, refunds are credited back to the agency account.'),

('Baggage Allowance & Excess Baggage Rules', 'BAGGAGE_POLICY', 'baggage_policy.txt', 'TXT', 3, 'Check-in and cabin baggage weight limits, excess rates, and restricted items.',
'BAGGAGE ALLOWANCE & EXCESS BAGGAGE RULES
1. Standard Baggage Allowances for Domestic Flights:
- Cabin Baggage: 1 handbag or laptop bag up to 7 kg, maximum dimensions 115 cm (length + width + height).
- Check-in Baggage: Economy class is entitled to 1 piece up to 15 kg. Business class is entitled to 2 pieces up to 30 kg total.
2. Excess Baggage Charges:
- Pre-booked excess baggage via website: ₹450 per additional kg.
- Excess baggage paid at airport check-in counter: ₹550 per additional kg.
- Additional piece charges apply if check-in exceeds 1 piece in Economy class.
3. Delayed or Lost Baggage:
- If your baggage does not appear on the conveyor belt, report immediately to the Airport Baggage Helpdesk before leaving the arrival hall.
- Property Irregularity Report (PIR) reference number will be issued (e.g. BAG-BOM-1001).
- Tracing is conducted through WorldTracer global tracking system.
- Interim relief allowance of ₹3,000 is provided for baggage delayed beyond 24 hours on outbound journeys.'),

('Flight Rescheduling & Change Policy', 'RESCHEDULING_POLICY', 'rescheduling_policy.txt', 'TXT', 2, 'Rules for changing travel dates, flight timings, and applicable fare difference.',
'FLIGHT RESCHEDULING & CHANGE POLICY
1. Date and Time Modifications:
- Rescheduling can be requested up to 2 hours prior to scheduled departure.
- A standard rescheduling change fee of ₹1,500 applies plus any applicable fare difference between old and new flight.
- If the new flight fare is lower, no refund of fare difference is provided; only change fee is charged.
- For Economy Flexi tickets, date change fee is waived (only fare difference applies).
2. Airline Disruption Rescheduling:
- In case of airline-initiated flight delay (>2 hours) or cancellation, passengers may reschedule to any alternative flight within 7 days at ZERO extra fee or fare difference.'),

('Airport Special Assistance & Accessibility Guide', 'AIRPORT_ASSISTANCE', 'accessibility_guide.txt', 'TXT', 2, 'Wheelchair assistance, medical equipment, and support for travelers with special needs.',
'AIRPORT SPECIAL ASSISTANCE & ACCESSIBILITY GUIDE
1. Wheelchair Assistance:
- Wheelchair support is provided completely free of charge at all airports.
- Categories:
  * WCHR (Ramp): Passenger can climb stairs and walk to seat, needs wheelchair for ramp/gate distance.
  * WCHS (Steps): Passenger cannot climb stairs, can walk to seat inside cabin.
  * WCHC (Cabin): Passenger is completely immobile, requires onboard aisle chair.
- Wheelchair requests should ideally be placed at least 24 hours prior to travel.
2. Medical and Special Needs:
- Stretcher, portable oxygen concentrator (POC), and guide dog travel are accommodated with prior clearance from the Medical Desk at least 48 hours in advance.');
