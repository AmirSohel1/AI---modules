package com.flightbooking;

import com.flightbooking.auth.AuthResponse;
import com.flightbooking.auth.AuthService;
import com.flightbooking.auth.LoginRequest;
import com.flightbooking.auth.RegisterRequest;
import com.flightbooking.booking.BookingRequestDto;
import com.flightbooking.booking.BookingResponseDto;
import com.flightbooking.booking.BookingService;
import com.flightbooking.cancellation.CancellationDto;
import com.flightbooking.cancellation.CancellationService;
import com.flightbooking.exception.BadRequestException;
import com.flightbooking.flight.FlightDto;
import com.flightbooking.flight.FlightSearchCriteria;
import com.flightbooking.flight.FlightService;
import com.flightbooking.payment.PaymentDto;
import com.flightbooking.payment.PaymentRepository;
import com.flightbooking.payment.PaymentSimulationRequest;
import com.flightbooking.reschedule.RescheduleDto;
import com.flightbooking.reschedule.RescheduleService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class FlightBookingSystemTests {

    @Autowired
    private AuthService authService;

    @Autowired
    private FlightService flightService;

    @Autowired
    private BookingService bookingService;

    @Autowired
    private CancellationService cancellationService;

    @Autowired
    private RescheduleService rescheduleService;

    @Autowired
    private PaymentRepository paymentRepository;

    @Test
    @DisplayName("Test 1: Admin and Passenger Login with JWT generation")
    void testAuthentication() {
        // Test admin login
        AuthResponse adminAuth = authService.login(LoginRequest.builder()
                .username("admin")
                .password("Admin@123")
                .build());
        assertNotNull(adminAuth.getToken());
        assertEquals("ADMIN", adminAuth.getUser().getRole());

        // Test passenger login
        AuthResponse passAuth = authService.login(LoginRequest.builder()
                .username("passenger")
                .password("Passenger@123")
                .build());
        assertNotNull(passAuth.getToken());
        assertEquals("PASSENGER", passAuth.getUser().getRole());
    }

    @Test
    @DisplayName("Test 2: Flight Search with route and budget filters")
    void testFlightSearch() {
        List<FlightDto> results = flightService.searchFlights(FlightSearchCriteria.builder()
                .source("BOM")
                .destination("DEL")
                .maxBudget(BigDecimal.valueOf(6500))
                .build());

        assertFalse(results.isEmpty());
        for (FlightDto f : results) {
            assertTrue(f.getBasePrice().compareTo(BigDecimal.valueOf(6500)) <= 0);
            assertEquals("BOM", f.getSourceAirport().getCode());
            assertEquals("DEL", f.getDestinationAirport().getCode());
        }
    }

    @Test
    @Transactional
    @DisplayName("Test 3: Booking creation with seat allocation and double-booking prevention")
    void testBookingAndDoubleBookingPrevention() {
        // Book flight 1 with seat 4C
        BookingRequestDto request = BookingRequestDto.builder()
                .flightId(1L)
                .travelDate(LocalDate.now().plusDays(3))
                .contactEmail("test.passenger@example.com")
                .contactPhone("+91 9999988888")
                .paymentMethod("UPI")
                .passengers(List.of(
                        BookingRequestDto.PassengerDetailDto.builder()
                                .fullName("Test Passenger 1")
                                .age(28)
                                .gender("MALE")
                                .seatNumber("4C")
                                .build()
                ))
                .build();

        BookingResponseDto booking = bookingService.createBooking(3L, request);
        assertNotNull(booking);
        assertNotNull(booking.getBookingReference());
        assertEquals("CONFIRMED", booking.getStatus());

        // Attempt double-booking on same seat 4C -> MUST FAIL
        assertThrows(BadRequestException.class, () -> {
            bookingService.createBooking(3L, request);
        });
    }

    @Test
    @Transactional
    @DisplayName("Test 4: Booking Cancellation with automatic refund calculation")
    void testCancellationAndRefund() {
        // Book a test flight
        BookingRequestDto request = BookingRequestDto.builder()
                .flightId(3L)
                .travelDate(LocalDate.now().plusDays(5))
                .contactEmail("cancel.test@example.com")
                .contactPhone("+91 9999977777")
                .paymentMethod("CARD")
                .passengers(List.of(
                        BookingRequestDto.PassengerDetailDto.builder()
                                .fullName("Cancel Test")
                                .age(32)
                                .gender("FEMALE")
                                .seatNumber("2B")
                                .build()
                ))
                .build();

        BookingResponseDto booking = bookingService.createBooking(3L, request);
        assertNotNull(booking.getId());

        // Cancel booking
        CancellationDto cancellation = cancellationService.cancelBooking(booking.getId(), 3L, "PASSENGER", "Personal travel changes");
        assertNotNull(cancellation);
        assertEquals("PROCESSED", cancellation.getStatus());
        assertTrue(cancellation.getRefundAmount().compareTo(BigDecimal.ZERO) >= 0);
        assertNotNull(cancellation.getRefundTransactionId());
    }

    @Test
    @Transactional
    @DisplayName("Test 5: Rescheduling flight with fare difference calculation")
    void testRescheduling() {
        // Book flight 1
        BookingRequestDto request = BookingRequestDto.builder()
                .flightId(1L)
                .travelDate(LocalDate.now().plusDays(3))
                .contactEmail("reschedule.test@example.com")
                .contactPhone("+91 9999966666")
                .paymentMethod("NETBANKING")
                .passengers(List.of(
                        BookingRequestDto.PassengerDetailDto.builder()
                                .fullName("Reschedule Test")
                                .age(35)
                                .gender("MALE")
                                .seatNumber("4D")
                                .build()
                ))
                .build();

        BookingResponseDto booking = bookingService.createBooking(3L, request);

        // Reschedule to flight 3 (UK-970)
        RescheduleDto reschedule = rescheduleService.rescheduleBooking(booking.getId(), 3L, 3L, "PASSENGER", "Meeting postponed");
        assertNotNull(reschedule);
        assertEquals("COMPLETED", reschedule.getStatus());
        assertEquals("UK-970", reschedule.getNewFlightNumber());
    }
}
