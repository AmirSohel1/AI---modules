# FlightAI REST API Documentation

## 1. Authentication Endpoints (`/api/auth`)

| Method | Endpoint | Access | Description |
|---|---|---|---|
| `POST` | `/api/auth/register` | Public | Register a new passenger account |
| `POST` | `/api/auth/login` | Public | Authenticate credentials and obtain JWT Bearer token |
| `GET` | `/api/auth/me` | Authenticated | Retrieve current user profile and role |

**Login Request Example:**
```json
{
  "email": "passenger@flightai.local",
  "password": "Passenger@123"
}
```

---

## 2. Flight Endpoints (`/api/flights`)

| Method | Endpoint | Access | Description |
|---|---|---|---|
| `GET` | `/api/flights/search` | Public | Search flights by source, destination, date, airline, budget |
| `GET` | `/api/flights` | Public | List all scheduled flights |
| `GET` | `/api/flights/{id}` | Public | Get detailed flight information |
| `GET` | `/api/flights/{id}/seats` | Public | Get interactive seat layout and availability |
| `PUT` | `/api/flights/{id}/status` | STAFF, ADMIN | Update flight operational status, delay minutes & reason |
| `POST` | `/api/flights` | ADMIN | Create new flight schedule |

---

## 3. Booking Endpoints (`/api/bookings`)

| Method | Endpoint | Access | Description |
|---|---|---|---|
| `POST` | `/api/bookings` | PASSENGER | Create reservation, lock seat, and execute payment |
| `GET` | `/api/bookings/my-bookings` | PASSENGER | Retrieve bookings for logged-in passenger |
| `GET` | `/api/bookings/reference/{ref}` | Authenticated | Lookup booking by PNR code (e.g. `PNR-1001`) |
| `GET` | `/api/bookings` | STAFF, ADMIN | Search all passenger bookings across airline network |
| `GET` | `/api/bookings/{id}/ticket-pdf` | PASSENGER, STAFF | Download official generated OpenPDF E-Ticket |

**Create Booking Request:**
```json
{
  "flightId": 1,
  "travelDate": "2026-11-25",
  "contactEmail": "john@example.com",
  "contactPhone": "+91 9876543210",
  "passengers": [
    {
      "fullName": "John Doe",
      "age": 28,
      "gender": "MALE",
      "seatNumber": "12A"
    }
  ],
  "paymentMethod": "UPI"
}
```

---

## 4. Cancellation & Rescheduling (`/api/cancellations`, `/api/reschedule`)

| Method | Endpoint | Access | Description |
|---|---|---|---|
| `GET` | `/api/cancellations/preview/{id}` | PASSENGER | Calculate refund estimate and fee breakdown |
| `POST` | `/api/cancellations` | PASSENGER | Submit ticket cancellation request |
| `GET` | `/api/cancellations` | STAFF, ADMIN | List all cancellation and refund requests |
| `PUT` | `/api/cancellations/{id}/process`| STAFF, ADMIN | Approve or reject refund and update status |
| `POST` | `/api/reschedule` | PASSENGER | Request flight date/time change to alternate flight |
| `GET` | `/api/reschedule` | STAFF, ADMIN | List all reschedule requests |

---

## 5. Baggage Operations (`/api/baggage`)

| Method | Endpoint | Access | Description |
|---|---|---|---|
| `POST` | `/api/baggage` | PASSENGER | Report delayed, missing, or damaged baggage |
| `GET` | `/api/baggage/my-cases` | PASSENGER | Retrieve baggage cases filed by user |
| `GET` | `/api/baggage` | STAFF, ADMIN | Retrieve all baggage cases for airport staff |
| `PUT` | `/api/baggage/{id}/status` | STAFF, ADMIN | Update investigation status and add internal notes |

---

## 6. Accessibility & Special Assistance (`/api/accessibility`)

| Method | Endpoint | Access | Description |
|---|---|---|---|
| `POST` | `/api/accessibility` | PASSENGER | Request wheelchair, sensory guide, or elderly care |
| `GET` | `/api/accessibility/my-requests` | PASSENGER | View user's assistance bookings |
| `GET` | `/api/accessibility` | STAFF, ADMIN | Operational queue for ground staff assignment |
| `PUT` | `/api/accessibility/{id}/status` | STAFF, ADMIN | Assign staff member and mark completed |

---

## 7. AI Gateway Endpoints (`/api/ai`)

| Method | Endpoint | Access | Description |
|---|---|---|---|
| `POST` | `/api/ai/chat` | Authenticated | Send user query to AI service (Single or Multi-Agent) |
| `GET` | `/api/ai/conversations` | Authenticated | Retrieve conversation history |
| `GET` | `/api/ai/conversations/{id}/messages` | Authenticated | Retrieve session message history |
| `POST` | `/api/ai/rag/query` | ADMIN | Test RAG similarity search against policy chunks |

**AI Chat Request Example:**
```json
{
  "message": "Find the cheapest flight from BOM to DEL and tell me about the cancellation policy",
  "conversationId": 101,
  "mode": "MULTI_AGENT"
}
```

**AI Chat Response:**
```json
{
  "conversationId": 101,
  "response": "Here are the flight options for BOM to DEL...",
  "mode": "MULTI_AGENT",
  "modelUsed": "langgraph-supervisor-gpt4o",
  "demoMode": true,
  "agentTraces": [
    {
      "agentName": "FlightOrchestratorAgent",
      "status": "COMPLETED",
      "inputSummary": "Classified intent as FLIGHT_SEARCH and POLICY_QUERY",
      "outputSummary": "Delegated to FlightSearchAgent and RAGRetriever",
      "durationMs": 42,
      "order": 1
    }
  ]
}
```
