# FlightAI System Architecture & Engineering Design

## 1. System Overview

**FlightAI** is a production-style, multi-tiered enterprise flight reservation and passenger assistance platform. It pairs a **Java 21 / Spring Boot 3.3.5** transactional backbone with a **Python 3.13 / LangGraph** multi-agent cognitive supervisor, backed by **MySQL 8** (with Flyway database migrations), a local **RAG vector store**, and a **React 18 + TypeScript + Vite + Tailwind CSS** frontend.

```mermaid
flowchart TD
    subgraph ClientLayer ["Client Layer (Presentation)"]
        UI["React 18 + TypeScript + Tailwind CSS\n(Single-Page App on Vite)"]
    end

    subgraph GatewayAuthLayer ["Core Business & Gateway Layer"]
        SpringBoot["Java 21 Spring Boot 3.3.5 Core\n- Spring Security 6 & JJWT\n- Spring Data JPA + Hibernate\n- Optimistic Locking & Concurrency\n- OpenPDF Boarding Pass Engine\n- AI Gateway & Tool Reverse Proxy"]
    end

    subgraph DataLayer ["Data & Persistence Layer"]
        MySQL[("MySQL 8.0 Engine\n- 25 Relational Tables\n- Flyway Versioned Migrations\n- ACID Transaction Boundary")]
    end

    subgraph CognitiveLayer ["Cognitive & Multi-Agent Layer"]
        FastAPI["Python 3.13 FastAPI AI Service\n- Internal Service Token Auth\n- LangGraph StateGraph Supervisor\n- ChromaDB / TF-IDF Vector Store\n- Deterministic Fallback Engine"]
        
        Orchestrator["Flight Orchestrator Supervisor"]
        
        AgentSearch["Flight Search Agent"]
        AgentReco["Recommendation Agent"]
        AgentBook["Booking Mgmt Agent"]
        AgentDisrupt["Disruption Agent"]
        AgentBag["Baggage Agent"]
        AgentSent["Sentiment Agent"]
        AgentRAG["RAG Retrieval Agent"]
        AgentAccess["Accessibility Agent"]
    end

    UI -->|REST + JWT Bearer| SpringBoot
    SpringBoot -->|JDBC / Hibernate| MySQL
    SpringBoot -->|Internal Auth Token| FastAPI
    FastAPI -->|Tool Proxy HTTP Calls| SpringBoot
    FastAPI --> Orchestrator
    Orchestrator --> AgentSearch
    Orchestrator --> AgentReco
    Orchestrator --> AgentBook
    Orchestrator --> AgentDisrupt
    Orchestrator --> AgentBag
    Orchestrator --> AgentSent
    Orchestrator --> AgentRAG
    Orchestrator --> AgentAccess
```

---

## 2. Multi-Agent vs. Single-Agent Architecture

The platform implements and benchmarks two distinct cognitive paradigms:

### A. Single-Agent Mode ("Smart Flight Assistant")
- Operates as a single autonomous agent equipped with approved tools.
- Executes direct function dispatch (`search_flights`, `get_policy`, `check_booking_status`).
- **Characteristics**: Fast single-turn latency (~30-40 ms), straightforward execution path, suited for direct transactional queries without multi-hop reasoning.

### B. Multi-Agent Mode ("LangGraph Flight Orchestrator")
- Employs a **StateGraph Supervisor** architecture using LangGraph.
- The **Flight Orchestrator Supervisor** receives user input, decomposes the intent, and routes tasks to specialized domain agents:
  1. `FlightSearchAgent`: Searches flights across routes, dates, and budget filters.
  2. `SmartRecommendationAgent`: Computes a deterministic multi-criteria score (price weight 60%, duration weight 40%) to rank options without hallucinating.
  3. `BookingManagementAgent`: Validates PNR status, retrieves passenger lists, and checks policy rules. Never commits mutations without passenger confirmation.
  4. `FlightDisruptionAgent`: Detects delayed or cancelled flights, identifies affected passengers, and suggests real alternative schedules.
  5. `SmartBaggageAgent`: Calculates excess weight charges and manages baggage tracking tickets.
  6. `SentimentAgent`: Classifies customer feedback polarity and urgency scores.
  7. `RAGRetrievalAgent`: Performs cosine/TF-IDF similarity against indexed DGCA and airline policy chunk embeddings.
  8. `AccessibilityAgent`: Manages wheelchair, ramp, and special traveler requirements.

---

## 3. Communication & Security Boundaries

1. **Client Isolation**: The React frontend **never** connects directly to MySQL or the Python AI service. All requests terminate at Spring Boot.
2. **Secret Containment**: The OpenAI API key and AI tokens are encapsulated on the server side. The client has zero exposure.
3. **Internal AI Token**: Communication between Spring Boot and FastAPI is secured via a shared internal token (`AI_SERVICE_SECRET_TOKEN`).
4. **Role-Based Access Control (RBAC)**: Enforced at both URL filter and service method levels using `@PreAuthorize`:
   - `PASSENGER`: Access to personal bookings, tickets, baggage reports, and AI chat.
   - `STAFF`: Access to passenger lookups, disruption controls, baggage case updates, and accessibility queues.
   - `ADMIN`: Full system analytics, flight scheduling, user account management, RAG policy ingestion, and AI telemetry logs.
