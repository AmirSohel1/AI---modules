# FlightAI Database Design & Schema Specification

## 1. Relational Database Overview

The persistence architecture runs on **MySQL 8.0** and is managed through **Flyway versioned migrations** to guarantee deterministic schema evolution:
- **`V1__initial_schema.sql`**: 25 relational tables with primary keys, unique constraints, foreign key cascades, and operational indices.
- **`V2__seed_data.sql`**: Production seed data covering 4 airlines, 8 major airports, 12 aircraft, 30 scheduled flights, seats, 27 users across 3 roles, bookings, baggage cases, feedback, and policy documents.

---

## 2. Entity-Relationship (ER) Architecture

```mermaid
erDiagram
    USERS ||--o{ BOOKINGS : places
    USERS ||--o{ PASSENGERS : profile
    USERS ||--o{ FEEDBACK : submits
    USERS ||--o{ NOTIFICATIONS : receives
    AIRLINES ||--o{ FLIGHTS : operates
    AIRCRAFT ||--o{ FLIGHTS : assigned_to
    AIRPORTS ||--o{ FLIGHTS : origin
    AIRPORTS ||--o{ FLIGHTS : destination
    FLIGHTS ||--o{ FLIGHT_SEATS : contains
    FLIGHTS ||--o{ BOOKINGS : booked_for
    BOOKINGS ||--|{ BOOKING_PASSENGERS : includes
    BOOKINGS ||--o| PAYMENTS : settled_by
    BOOKINGS ||--o{ CANCELLATION_REQUESTS : initiates
    BOOKINGS ||--o{ RESCHEDULE_REQUESTS : requests
    BOOKINGS ||--o{ BAGGAGE_CASES : reports
    FLIGHTS ||--o{ FLIGHT_DISRUPTIONS : suffers
```

---

## 3. Core Tables Specification

### 1. `users` & `roles`
- `users`: `id`, `username`, `email` (UNIQUE), `password` (BCrypt), `full_name`, `phone`, `role` (`PASSENGER`, `STAFF`, `ADMIN`), `status` (`ACTIVE`, `SUSPENDED`), `created_at`.
- Initial seed passwords use standard BCrypt hashing initialized during startup.

### 2. `airports`, `airlines`, `aircraft`
- `airports`: `id`, `code` (`BOM`, `DEL`, `BLR`, `MAA`, `HYD`, `CCU`, `PNQ`, `GOI`), `name`, `city`, `country`, `terminal_count`.
- `airlines`: `id`, `code` (`AI`, `6E`, `UK`, `QP`), `name`, `logo_url`, `status`.
- `aircraft`: `id`, `model` (e.g. `Airbus A320neo`, `Boeing 737 MAX 8`), `registration_number`, `total_seats`, `economy_seats`, `business_seats`.

### 3. `flights` & `flight_seats`
- `flights`: `id`, `flight_number` (e.g. `AI-101`), `airline_id`, `aircraft_id`, `source_airport_id`, `dest_airport_id`, `departure_time`, `arrival_time`, `duration_minutes`, `stops`, `base_price`, `status` (`SCHEDULED`, `DELAYED`, `CANCELLED`, `DEPARTED`, `ARRIVED`), `delay_reason`, `delay_minutes`.
- `flight_seats`: `id`, `flight_id`, `seat_number` (e.g. `1A`, `12C`), `seat_class` (`ECONOMY`, `BUSINESS`), `price_multiplier`, `is_available`, `version` (optimistic lock).

### 4. `bookings`, `booking_passengers`, `payments`
- `bookings`: `id`, `booking_reference` (UNIQUE PNR e.g. `PNR-1001`), `user_id`, `flight_id`, `booking_date`, `travel_date`, `total_amount`, `status` (`CONFIRMED`, `CANCELLED`, `RESCHEDULED`), `contact_email`, `contact_phone`.
- `booking_passengers`: `id`, `booking_id`, `full_name`, `age`, `gender`, `seat_number`, `ticket_number`.
- `payments`: `id`, `booking_id`, `transaction_id`, `payment_method` (`UPI`, `CARD`, `NETBANKING`), `amount`, `status` (`SUCCESS`, `REFUNDED`), `paid_at`.

### 5. `cancellation_requests` & `refunds`
- `cancellation_requests`: `id`, `booking_id`, `reason`, `original_amount`, `cancellation_fee`, `refund_amount`, `status` (`PENDING`, `APPROVED`, `REJECTED`), `requested_at`, `processed_at`.
- Implements automated tiered cancellation fee calculations (>72 hrs: 10%, 24-72 hrs: 25%, 4-24 hrs: 50%, <4 hrs: non-refundable).

### 6. `flight_disruptions` & `notifications`
- `flight_disruptions`: `id`, `flight_id`, `disruption_type` (`DELAY`, `CANCELLATION`), `reason`, `delay_minutes`, `affected_passengers_count`, `reported_at`.
- `notifications`: `id`, `user_id`, `title`, `message`, `type`, `is_read`, `reference_id`, `created_at`.

### 7. `baggage_cases` & `accessibility_requests`
- `baggage_cases`: `id`, `booking_id`, `booking_reference`, `case_reference` (e.g. `BAG-8801`), `flight_id`, `flight_number`, `tag_number`, `case_type`, `description`, `status` (`REPORTED`, `INVESTIGATING`, `LOCATED`, `IN_TRANSIT`, `DELIVERED`, `CLOSED`).
- `accessibility_requests`: `id`, `user_id`, `booking_id`, `service_type` (`WHEELCHAIR_RAMP`, `WHEELCHAIR_CABIN`, `VISUAL_IMPAIRMENT`, `ELDERLY_ASSISTANCE`), `details`, `status` (`PENDING`, `ASSIGNED`, `COMPLETED`), `assigned_staff_name`.

### 8. `knowledge_documents` & `ai_agent_execution_logs`
- `knowledge_documents`: `id`, `title`, `category`, `filename`, `file_type`, `chunk_count`, `content_summary`, `full_text`.
- `ai_agent_execution_logs`: `id`, `conversation_id`, `agent_name`, `mode`, `tool_called`, `duration_ms`, `status`, `created_at`.

---

## 4. Concurrency & Optimistic Seat Locking

To prevent race conditions where two simultaneous users attempt to reserve the same seat:
1. `FlightSeat` entity utilizes JPA `@Version` optimistic locking.
2. The booking service executes inside a `@Transactional` block with isolation:
   ```java
   FlightSeat seat = seatRepository.findByFlightIdAndSeatNumberForUpdate(flightId, seatNumber)
       .orElseThrow(() -> new SeatNotFoundException());
   if (!seat.isAvailable()) {
       throw new SeatAlreadyBookedException("Seat " + seatNumber + " is already occupied.");
   }
   seat.setAvailable(false);
   seatRepository.save(seat);
   ```
3. If concurrent requests collide, one transaction completes and the other catches an `OptimisticLockingFailureException`, rolling back cleanly and prompting the user.
