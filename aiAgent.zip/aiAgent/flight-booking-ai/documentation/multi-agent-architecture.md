# LangGraph Multi-Agent Architecture: Flight Orchestrator

## 1. Supervisor Orchestration Architecture
The multi-agent system uses **LangGraph** to model multi-agent collaboration as a directed cyclical state graph governed by a central **Flight Orchestrator Supervisor**.

```mermaid
flowchart TD
    UserQuery["User Input Message"] --> Orchestrator["Flight Orchestrator Agent\n(Intent Classifier & Task Decomposition)"]

    Orchestrator -->|Intent: FLIGHT_SEARCH| AgentSearch["Flight Search Agent\n(Database Querying)"]
    Orchestrator -->|Intent: RECOMMENDATION| AgentReco["Smart Recommendation Agent\n(Deterministic Scoring)"]
    Orchestrator -->|Intent: BOOKING_MGMT| AgentBook["Booking Management Agent\n(Read-Only Verification)"]
    Orchestrator -->|Intent: DISRUPTION| AgentDisrupt["Flight Disruption Agent\n(Impact Analysis & Alternatives)"]
    Orchestrator -->|Intent: BAGGAGE| AgentBag["Smart Baggage Agent\n(Allowance & Tracking)"]
    Orchestrator -->|Intent: SENTIMENT| AgentSent["Passenger Sentiment Agent\n(Review Polarity & Urgency)"]
    Orchestrator -->|Intent: POLICY_RAG| AgentRAG["RAG Retrieval Agent\n(Vector Similarity Search)"]
    Orchestrator -->|Intent: ACCESSIBILITY| AgentAccess["Accessibility Agent\n(Special Mobility Assistance)"]

    AgentSearch --> Collector["Response Aggregator & Synthesis Node"]
    AgentReco --> Collector
    AgentBook --> Collector
    AgentDisrupt --> Collector
    AgentBag --> Collector
    AgentSent --> Collector
    AgentRAG --> Collector
    AgentAccess --> Collector

    Collector --> FinalAnswer["Final Natural Language Answer\n+ Live Execution Traces"]
```

---

## 2. Specialized Agents Breakdown

### Agent 1: Flight Orchestrator Agent (Supervisor)
- **Role**: Parses user input, extracts entities (airports, dates, PNRs), identifies required domains, routes subtasks to specialist nodes, and aggregates final syntheses.
- **Fail-Safe Mechanism**: If a specialist returns empty data, the orchestrator suggests broadened search criteria or policy alternatives without hallucinating.

### Agent 2: Flight Search Agent
- Queries MySQL database exclusively via Spring Boot's `/api/flights/search` endpoint.
- Validates airport IATA codes (`BOM`, `DEL`, `BLR`, `MAA`, `HYD`, `CCU`, `PNQ`, `GOI`).
- Returns real-time available seat counts and base prices.

### Agent 3: Smart Recommendation Agent
- Takes flight search results and applies a deterministic Python scoring formula:
  $$\text{Score} = 0.6 \times \left(1 - \frac{\text{Price}}{\text{MaxPrice}}\right) + 0.4 \times \left(1 - \frac{\text{Duration}}{\text{MaxDuration}}\right) + \text{DirectBonus}$$
- The LLM explains the reasoning in plain English while the underlying ranking is mathematically verifiable.

### Agent 4: Booking Management Agent
- Handles PNR verification, seat assignment lookup, and ticket retrieval.
- **Strict Constraint**: Never performs destructive database mutations directly. It only prepares cancellation or reschedule payloads for the passenger to confirm via Spring Boot.

### Agent 5: Flight Disruption Management Agent (Key Academic Innovation)
- Identifies flights in `DELAYED` or `CANCELLED` status.
- Queries confirmed bookings to extract the list of affected passengers.
- Searches alternative active flights on the same route and prepares rebooking recommendations.
- Explains applicable passenger compensation according to DGCA Civil Aviation Requirements (CAR).

### Agent 6: Smart Baggage Assistant Agent
- Explains weight allowances (7 kg cabin, 15 kg check-in for Economy, 30 kg for Business).
- Calculates excess baggage charges (₹550 per kg).
- Creates and tracks luggage tracking tickets (`BAG-8801`).

### Agent 7: Passenger Feedback & Sentiment Agent
- Analyzes natural language reviews.
- Categorizes sentiment into `POSITIVE`, `NEUTRAL`, `NEGATIVE`.
- Computes an operational urgency score (1 to 5) to flag critical customer grievances.

### Agent 8: RAG Retrieval Agent
- Searches policy documents and returns semantic chunk excerpts with exact citations.
