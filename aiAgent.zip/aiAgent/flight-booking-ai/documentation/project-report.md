# AI-Powered Intelligent Flight Booking & Passenger Assistance System
## Complete Major Project Academic Report

### Abstract
This project presents **FlightAI**, an intelligent flight reservation and passenger assistance platform designed with a hybrid Single-Agent and Multi-Agent cognitive architecture. The platform combines enterprise transactional reliability using Java 21, Spring Boot 3.3.5, and MySQL 8 with cutting-edge autonomous AI orchestration using Python 3.13 and LangGraph. The system introduces real-time flight disruption management, automated passenger rebooking recommendations, RAG-grounded regulatory compliance, and role-based operations across Passenger, Staff, and Admin portals. A comparative evaluation demonstrates the distinct latency, delegation, and reasoning capabilities of Single-Agent tool dispatch versus a supervised multi-agent pipeline.

---

### Chapter 1: Introduction
1. **Background**: Modern aviation platforms struggle with operational transparency during flight disruptions, static customer service chatbots prone to hallucination, and decoupled reservation systems.
2. **Project Objectives**:
   - Deliver end-to-end flight booking with real-time seat inventory and transactional locking.
   - Implement Single-Agent tool calling for high-speed deterministic lookups.
   - Implement a LangGraph Multi-Agent Supervisor coordinating 8 specialized agents.
   - Integrate Retrieval-Augmented Generation (RAG) for official airline policy citations.
   - Provide role-based dashboards for Passengers, Staff, and System Administrators.

---

### Chapter 2: Literature Survey & Architectural Analysis
1. **Traditional Rule-Based Systems**: Rigid and incapable of understanding nuanced passenger travel intent.
2. **Monolithic LLM Assistants**: Suffer from hallucination, context drift, and inability to execute verified database transactions safely.
3. **Multi-Agent Systems (MAS)**: Decomposing tasks into specialized autonomous agents (Search, Recommendation, Disruption, Baggage, Sentiment) supervised by an orchestrator guarantees domain specialization, transparency, and transactional safety.

---

### Chapter 3: System Requirements & Technology Stack
- **Frontend**: React 18, TypeScript, Vite, Tailwind CSS, Recharts, Lucide React.
- **Backend Core**: Java 21 LTS, Spring Boot 3.3.5, Spring Security 6, JJWT 0.12.6, OpenPDF, Flyway 10.
- **AI Core**: Python 3.13, FastAPI, LangGraph, ChromaDB / TF-IDF Vector Store, OpenAI SDK.
- **Persistence**: MySQL 8.0 with 25 relational tables and ACID boundary controls.

---

### Chapter 4: System Architecture & Implementation
1. **Security & Boundary Isolation**: React connects exclusively to Spring Boot; Spring Boot acts as the AI Gateway, verifying JWT tokens before forwarding authorized requests to FastAPI.
2. **Transactional Seat Booking**: Enforces JPA optimistic locking (`@Version`) preventing double booking under concurrent requests.
3. **Automated Disruption Management**: Real-time propagation of delays and cancellations with instant passenger manifest extraction and alternate flight recommendations.
4. **Deterministic Recommendation Engine**: Combines mathematical cost-duration scoring with LLM natural language explanations.

---

### Chapter 5: Results, Testing & Evaluation
- 100% test pass rate across Spring Boot backend integration tests and Python LangGraph unit tests.
- Comparative latency analysis: Single-Agent (35 ms average in local demo mode) vs Multi-Agent (72 ms average) illustrating the trade-off between execution speed and task decomposition depth.

---

### Chapter 6: Conclusion & Future Scope
FlightAI successfully bridges enterprise software engineering with autonomous multi-agent cognitive systems. Future enhancements include live airport radar API integrations, biometric boarding pass verification, and automated inter-airline rebooking agreements.
