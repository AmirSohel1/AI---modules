# Retrieval-Augmented Generation (RAG) Architecture

## 1. System Pipeline
The RAG subsystem empowers the agents to answer intricate regulatory and airline policy questions with 100% factual accuracy by extracting evidence directly from verified documentation.

```mermaid
flowchart LR
    subgraph Ingestion ["Ingestion Pipeline (Offline / Admin)"]
        RawDocs["Policy Documents\n(TXT / Regulatory CAR)"] --> Splitter["Semantic Text Splitter\n(Chunk Size: 300 words, Overlap: 50)"]
        Splitter --> VectorStore[("Vector Store / TF-IDF Index\n(ChromaDB / Local In-Memory)")]
    end

    subgraph Retrieval ["Retrieval Pipeline (Runtime)"]
        UserQuery["Passenger / Staff Question"] --> EmbedQuery["Query Vectorization"]
        EmbedQuery --> Similarity["Cosine / TF-IDF Similarity Search"]
        VectorStore --> Similarity
        Similarity --> TopChunks["Top K Relevant Chunks (K=3)"]
    end

    subgraph Generation ["Synthesis Pipeline"]
        TopChunks --> Prompt["Augmented Prompt Context\n+ User Query"]
        Prompt --> Agent["AI Assistant / RAG Agent"]
        Agent --> Answer["Grounded Answer with Chunk Citations"]
    end
```

---

## 2. Ingested Policy Collections
The seed system indexes four official travel policies:
1. **`domestic_baggage_policy_2026.txt`**: Cabin and check-in baggage weight limits, restricted items, and excess baggage fees.
2. **`flight_disruptions_dgca_rules.txt`**: DGCA Section 3, Series M, Part IV guidelines governing compensation, meals, hotel accommodations, and passenger rights during cancellations.
3. **`cancellation_refund_tiers.txt`**: Automated cancellation fee schedule based on departure proximity.
4. **`airport_accessibility_standards.txt`**: Protocols for PRM (Persons with Reduced Mobility), wheelchair ramps, cabin chairs, and guide escorts.

---

## 3. Grounding & Anti-Hallucination Guarantees
- Every RAG answer cites the source document title.
- If similarity score drops below the confidence threshold, the agent explicitly states: *"I cannot find an official policy clause addressing this specific condition in the airline manual. Please consult ground staff."*
