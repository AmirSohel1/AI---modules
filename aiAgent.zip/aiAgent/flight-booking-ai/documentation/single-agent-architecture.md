# Single-Agent Architecture: Smart Flight Assistant

## 1. Overview
The **Smart Flight Assistant** represents a direct tool-calling cognitive architecture. It operates as a single unified LLM agent initialized with a set of approved backend tools.

```mermaid
flowchart LR
    User["Passenger / Staff"] -->|Natural Language| Agent["Smart Flight Assistant\n(Single-Agent Runner)"]
    Agent -->|Direct Tool Dispatch| Tools["Approved Backend Tools"]
    Tools -->|HTTP / REST| SpringBoot["Spring Boot REST API"]
    SpringBoot -->|SQL| MySQL[("MySQL 8 Database")]
    Tools -->|Retrieved Context| Agent
    Agent -->|Structured Response| User
```

## 2. Tool Inventory
The Single-Agent has access to:
1. `search_flights(source, dest, date, airline, max_price)`: Queries Spring Boot flight search API.
2. `get_flight_details(flight_number)`: Retrieves flight status, timing, and aircraft info.
3. `check_booking_status(pnr)`: Retrieves booking details, passenger list, and seat assignments.
4. `calculate_cancellation_refund(booking_id)`: Previews tiered cancellation fees.
5. `search_policies(query)`: Queries RAG vector store for baggage, compensation, and accessibility policies.
6. `get_baggage_allowance(cabin_class)`: Returns cabin and check-in weight limits.

## 3. Advantages & Trade-Offs
- **Latency**: Single-hop execution produces faster response times (typically 25-45 ms in local demo mode, 1.2-1.8s with live OpenAI API).
- **Simplicity**: No supervisor orchestration overhead or complex state graphs.
- **Limitation**: When a prompt requires multi-step composite workflows (e.g., detecting a flight disruption, searching alternative flights, filtering by user budget, calculating refund differences, and notifying affected passengers), a single agent can suffer from cognitive drift or incomplete tool chaining compared to specialized multi-agent graphs.
