# FlightAI Use Cases & Operational Scenarios

## 1. Passenger Workflows

### UC-P1: Search Flights & Compare Recommendations
- **Actor**: Passenger
- **Flow**: User inputs Origin (`BOM`), Destination (`DEL`), and Date (`2026-11-25`). System displays available flights with direct vs connecting stops, duration, and pricing.
- **AI Integration**: Passenger asks AI: *"Find the cheapest flight from Mumbai to Delhi"*. Multi-agent orchestrator delegates to Search & Recommendation agents, returning sorted cards with "Select Seats" CTA.

### UC-P2: Interactive Seat Map & Booking
- **Actor**: Passenger
- **Flow**: Passenger selects an Economy or Business seat on the interactive aircraft fuselage map. Fills traveler age, gender, and contact details. System locks seat transactionally and returns PNR confirmation.
- **PDF Generation**: User clicks "PDF E-Ticket" to download the official boarding pass generated with OpenPDF.

### UC-P3: Ticket Cancellation & Refund Estimation
- **Actor**: Passenger
- **Flow**: User opens booking details and clicks "Cancel Booking". System previews cancellation fee based on departure proximity (e.g. 25% fee if cancelled 24-72 hrs prior) and calculates estimated refund.

### UC-P4: Baggage Inquiries & Lost Luggage Reporting
- **Actor**: Passenger
- **Flow**: User uses the Baggage Fee Calculator to calculate excess weight costs. If a bag is delayed, user registers a case with bag tag number (`AI987211`) and tracks its investigation status.

---

## 2. Staff Workflows

### UC-S1: Ground Operations & Passenger Lookup
- **Actor**: Staff
- **Flow**: Staff searches passenger reservations by PNR, passenger name, or flight number. Inspects ticket numbers, seat allocations, and emergency contact information.

### UC-S2: Flight Disruption Management & Notification
- **Actor**: Staff
- **Flow**: Due to inclement weather, staff updates flight `AI-101` status to `DELAYED` (+60 minutes) with reason. System immediately identifies all affected passengers and allows staff to broadcast automated alerts.

### UC-S3: Baggage Case Investigation
- **Actor**: Staff
- **Flow**: Staff updates baggage ticket status from `REPORTED` to `LOCATED` on carousel 4, adding internal operations notes.

---

## 3. Admin Workflows

### UC-A1: Executive Business Analytics
- **Actor**: Admin
- **Flow**: Admin views gross ticket revenues, booking volume trends (Recharts area chart), popular route corridors (bar chart), and feedback sentiment distribution (pie chart).

### UC-A2: AI Execution Telemetry & Model Evaluation
- **Actor**: Admin
- **Flow**: Admin inspects execution duration, token consumption, and step-by-step agent traces comparing Single-Agent vs Multi-Agent supervisor efficiency.

### UC-A3: RAG Knowledge Base Ingestion
- **Actor**: Admin
- **Flow**: Admin uploads new airline policies, runs semantic chunking, and tests real-time vector similarity scoring via the interactive RAG query tester.
