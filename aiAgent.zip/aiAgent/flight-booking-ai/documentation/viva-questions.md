# FlightAI Viva Examination Questions & Comprehensive Answers

## Section 1: System Architecture & Technologies

### Q1: What is the high-level architecture of FlightAI?
**Answer**: FlightAI follows a decoupled 4-tier architecture:
1. **Frontend**: React 18 + TypeScript SPA styled with Tailwind CSS, communicating via Axios to Spring Boot.
2. **Backend**: Java 21 Spring Boot 3.3.5 handling business logic, authentication, transactions, Flyway migrations, and acting as the AI Gateway.
3. **Database**: MySQL 8.0 maintaining 25 relational tables with ACID boundaries and optimistic concurrency controls.
4. **AI Service**: Python 3.13 FastAPI service running LangGraph for multi-agent supervisor orchestration and RAG vector indexing.

### Q2: Why is the AI service written in Python while the main backend is in Spring Boot?
**Answer**: This follows enterprise best practices for separation of concerns:
- **Spring Boot** excels at robust transaction management, multithreading, enterprise security (Spring Security + JJWT), ACID database operations, and high-throughput REST APIs.
- **Python** is the native ecosystem for AI and LLM orchestration frameworks (LangGraph, LangChain, Pydantic, ChromaDB).
- Spring Boot acts as the sole gatekeeper for all business transactions and database writes, ensuring the AI service cannot mutate data without validation.

### Q3: How is communication secured between Spring Boot and the Python AI service?
**Answer**: The Python FastAPI service is not publicly exposed. It authenticates Spring Boot requests using a pre-shared internal bearer secret token (`X-Internal-AI-Token` / `AI_SERVICE_SECRET_TOKEN`). The React frontend never connects to FastAPI directly and never has access to AI tokens or OpenAI API keys.

---

## Section 2: Multi-Agent vs. Single-Agent Architecture

### Q4: What is the core difference between the Single-Agent and Multi-Agent modes in your project?
**Answer**:
- **Single-Agent Mode ("Smart Flight Assistant")**: Uses a single LLM loop that directly invokes approved tools (`search_flights`, `get_policy`). It is lightweight and fast (30-40 ms latency), best suited for direct lookups.
- **Multi-Agent Mode ("LangGraph Flight Orchestrator")**: Employs a StateGraph supervisor architecture. The supervisor classifies user intent and delegates subtasks to 8 specialized domain agents (Search, Recommendation, Disruption, Baggage, Sentiment, RAG, Accessibility). Each specialist runs controlled tools, and their outputs are synthesized into a coherent response with an auditable step-by-step activity trace.

### Q5: What is LangGraph and why did you choose it over basic sequential chaining?
**Answer**: LangGraph allows modeling multi-agent workflows as **directed cyclical graphs** with shared state (`AgentState`). Unlike linear LangChain sequences, LangGraph supports:
1. Conditional branching based on intent classification.
2. Cyclic error recovery (e.g. if flight search returns no seats, redirecting to the recommendation agent to relax constraints).
3. Independent specialist execution nodes with strict boundaries.
4. Granular inspection of intermediate agent states.

### Q6: Can the AI agents directly book, modify, or cancel a flight?
**Answer**: **No.** In accordance with safety-critical software principles, the agents operate under strict read-only/drafting constraints. The agent can retrieve flights, prepare cancellation refund estimates, or suggest reschedule options, but the **final financial or state-altering transaction must be explicitly confirmed and executed by Spring Boot**.

---

## Section 3: Retrieval-Augmented Generation (RAG)

### Q7: What is RAG and why is it needed in an airline system?
**Answer**: Large Language Models suffer from hallucinations and lack knowledge of specific, frequently changing airline policies (such as DGCA refund rules, excess baggage fees, or wheelchair protocols). RAG retrieves exact semantic text chunks from indexed official documents and injects them into the prompt as factual ground truth, ensuring answers cite verified clauses.

### Q8: How is the RAG pipeline implemented in your project?
**Answer**:
1. **Ingestion**: Admin uploads TXT policy manuals. The document is chunked into 300-word segments with 50-word overlap.
2. **Indexing**: Chunks are stored with metadata in ChromaDB / local TF-IDF vector storage.
3. **Retrieval**: At query time, the user's question is vectorized, cosine similarity is computed, and the top $K=3$ highest-scoring chunks are retrieved.
4. **Synthesis**: The agent answers using the retrieved excerpts and includes chunk citations.

---

## Section 4: Concurrency & Database Design

### Q9: How do you prevent double-booking if two passengers attempt to book the last remaining seat simultaneously?
**Answer**:
1. In the database, the `flight_seats` table contains a `@Version` column enabling JPA **Optimistic Locking**.
2. When a seat is booked, the transaction verifies `is_available == true` inside an isolated database transaction.
3. If two concurrent threads read the same seat state, the first commit increments the version number. The second commit fails with an `OptimisticLockingFailureException`. The application catches this, aborts the second booking, and prompts the user to select another seat.

### Q10: What are Flyway migrations and why did you use them?
**Answer**: Flyway is an open-source database migration tool. It tracks schema versions in a `flyway_schema_history` table. Using Flyway (`V1__initial_schema.sql` and `V2__seed_data.sql`) guarantees that any developer or viva examiner running the project locally gets the exact 25 tables and seed records initialized automatically without manual SQL imports.

---

## Section 5: Unique Innovations & Disruption Handling

### Q11: What makes the Flight Disruption Management Agent unique?
**Answer**: Flight disruptions (delays and cancellations) are typically handled reactively. FlightAI provides an integrated disruption system where:
1. Staff updates a flight's status to `DELAYED` or `CANCELLED`.
2. The system immediately scans real bookings in MySQL to extract the affected passenger manifest.
3. The Disruption Agent evaluates alternative flights on the same route and computes replacement options.
4. DGCA CAR regulatory compensation rules (meals, refunds, accommodations) are automatically cited and explained to affected travelers.

### Q12: How does the system operate if no OpenAI API key is configured?
**Answer**: FlightAI incorporates a **Deterministic Local Fallback Engine**. When `OPENAI_API_KEY` is not present, the system runs local heuristic parsing, executes real MySQL queries through Spring Boot tools, performs TF-IDF RAG retrieval, and generates authentic multi-agent activity traces. This guarantees a 100% functional viva demonstration offline without paid third-party dependencies.
