import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import Navbar from './components/common/Navbar';
import Footer from './components/common/Footer';
import DashboardLayout from './components/common/DashboardLayout';

// Public Pages
import LandingPage from './pages/public/LandingPage';
import FlightSearchResultsPage from './pages/public/FlightSearchResultsPage';
import LoginPage from './pages/public/LoginPage';
import RegisterPage from './pages/public/RegisterPage';
import AiChatPage from './pages/ai/AiChatPage';

// Passenger Pages
import PassengerDashboard from './pages/passenger/PassengerDashboard';
import BookingCheckoutPage from './pages/passenger/BookingCheckoutPage';
import BookingConfirmationPage from './pages/passenger/BookingConfirmationPage';
import MyBookingsPage from './pages/passenger/MyBookingsPage';
import BaggageAssistancePage from './pages/passenger/BaggageAssistancePage';
import AccessibilityPage from './pages/passenger/AccessibilityPage';
import FeedbackPage from './pages/passenger/FeedbackPage';
import ProfilePage from './pages/passenger/ProfilePage';

// Staff Pages
import StaffDashboardPage from './pages/staff/StaffDashboardPage';
import PassengerLookupPage from './pages/staff/PassengerLookupPage';
import StaffDisruptionPage from './pages/staff/StaffDisruptionPage';
import StaffBaggagePage from './pages/staff/StaffBaggagePage';
import StaffAccessibilityPage from './pages/staff/StaffAccessibilityPage';

// Admin Pages
import AdminDashboardPage from './pages/admin/AdminDashboardPage';
import FlightManagementPage from './pages/admin/FlightManagementPage';
import UserManagementPage from './pages/admin/UserManagementPage';
import AdminAiLogsPage from './pages/admin/AdminAiLogsPage';
import KnowledgeBasePage from './pages/admin/KnowledgeBasePage';

// Route Guards
const ProtectedRoute = ({
  children,
  allowedRoles,
}: {
  children: React.ReactNode;
  allowedRoles?: ('PASSENGER' | 'STAFF' | 'ADMIN')[];
}) => {
  const { user, isAuthenticated, loading } = useAuth();

  if (loading) {
    return <div className="p-12 text-center text-xs text-slate-500">Checking credentials...</div>;
  }

  if (!isAuthenticated || !user) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};

export const App: React.FC = () => {
  return (
    <Routes>
      {/* Public Pages with Standard Layout */}
      <Route
        path="/"
        element={
          <div className="min-h-screen flex flex-col bg-slate-50">
            <Navbar />
            <main className="flex-1">
              <LandingPage />
            </main>
            <Footer />
          </div>
        }
      />

      <Route
        path="/flights"
        element={
          <div className="min-h-screen flex flex-col bg-slate-50">
            <Navbar />
            <main className="flex-1">
              <FlightSearchResultsPage />
            </main>
            <Footer />
          </div>
        }
      />

      <Route
        path="/ai-chat"
        element={
          <div className="min-h-screen flex flex-col bg-slate-50">
            <Navbar />
            <main className="flex-1 p-4 sm:p-6 max-w-7xl mx-auto w-full">
              <AiChatPage />
            </main>
            <Footer />
          </div>
        }
      />

      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />

      {/* Passenger Protected Routes */}
      <Route
        path="/passenger"
        element={
          <ProtectedRoute allowedRoles={['PASSENGER', 'STAFF', 'ADMIN']}>
            <DashboardLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<PassengerDashboard />} />
        <Route path="book" element={<BookingCheckoutPage />} />
        <Route path="confirmation" element={<BookingConfirmationPage />} />
        <Route path="bookings" element={<MyBookingsPage />} />
        <Route path="baggage" element={<BaggageAssistancePage />} />
        <Route path="accessibility" element={<AccessibilityPage />} />
        <Route path="feedback" element={<FeedbackPage />} />
        <Route path="profile" element={<ProfilePage />} />
      </Route>

      {/* Staff Protected Routes */}
      <Route
        path="/staff"
        element={
          <ProtectedRoute allowedRoles={['STAFF', 'ADMIN']}>
            <DashboardLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<StaffDashboardPage />} />
        <Route path="passengers" element={<PassengerLookupPage />} />
        <Route path="disruptions" element={<StaffDisruptionPage />} />
        <Route path="baggage" element={<StaffBaggagePage />} />
        <Route path="accessibility" element={<StaffAccessibilityPage />} />
      </Route>

      {/* Admin Protected Routes */}
      <Route
        path="/admin"
        element={
          <ProtectedRoute allowedRoles={['ADMIN']}>
            <DashboardLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<AdminDashboardPage />} />
        <Route path="flights" element={<FlightManagementPage />} />
        <Route path="users" element={<UserManagementPage />} />
        <Route path="ai-logs" element={<AdminAiLogsPage />} />
        <Route path="knowledge-base" element={<KnowledgeBasePage />} />
      </Route>

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

export default App;
