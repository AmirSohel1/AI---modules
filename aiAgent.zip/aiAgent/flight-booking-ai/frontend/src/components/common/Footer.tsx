import React from 'react';
import { Plane, Github, Shield, Cpu } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 text-slate-400 py-10 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8 text-xs">
          {/* Brand info */}
          <div className="space-y-3">
            <div className="flex items-center space-x-2 text-white font-bold text-base">
              <Plane className="w-5 h-5 text-indigo-400 transform -rotate-45" />
              <span>FlightAI</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              AI-Powered Intelligent Flight Booking and Passenger Assistance System using
              Single-Agent and Multi-Agent Architecture.
            </p>
            <div className="flex items-center space-x-2 text-[11px] text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span>All Systems Operational (Local Engine)</span>
            </div>
          </div>

          {/* Architecture Highlights */}
          <div className="space-y-2">
            <p className="font-semibold text-white uppercase tracking-wider text-[11px]">
              AI Architecture
            </p>
            <ul className="space-y-1 text-slate-400">
              <li>LangGraph Multi-Agent Supervisor</li>
              <li>Single-Agent Tool Calling</li>
              <li>Deterministic Fallback Engine</li>
              <li>ChromaDB / Local RAG Engine</li>
              <li>Flight Disruption Orchestrator</li>
            </ul>
          </div>

          {/* Backend & Security */}
          <div className="space-y-2">
            <p className="font-semibold text-white uppercase tracking-wider text-[11px]">
              Backend Stack
            </p>
            <ul className="space-y-1 text-slate-400">
              <li>Java 21 & Spring Boot 3.3.5</li>
              <li>Spring Security + JJWT Auth</li>
              <li>MySQL 8 + Flyway Migrations</li>
              <li>Optimistic Seat Locking</li>
              <li>OpenPDF Ticket Generator</li>
            </ul>
          </div>

          {/* Quick Demo Access */}
          <div className="space-y-2">
            <p className="font-semibold text-white uppercase tracking-wider text-[11px]">
              Demo Viva Credentials
            </p>
            <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 space-y-1 font-mono text-[10px]">
              <p className="text-sky-300">Admin: admin@flightai.local</p>
              <p className="text-amber-300">Staff: staff@flightai.local</p>
              <p className="text-emerald-300">User: passenger@flightai.local</p>
              <p className="text-slate-400">Password: &lt;Role&gt;@123</p>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500">
          <p>© 2026 FlightAI Platform. Academic Major Project & Viva Demonstration.</p>
          <div className="flex items-center space-x-4 mt-3 sm:mt-0">
            <span className="flex items-center space-x-1">
              <Cpu className="w-3.5 h-3.5" />
              <span>Multi-Agent AI Engine</span>
            </span>
            <span className="flex items-center space-x-1">
              <Shield className="w-3.5 h-3.5" />
              <span>Role-Based Access Control</span>
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
