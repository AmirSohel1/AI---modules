import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Plane,
  Ticket,
  Luggage,
  HeartHandshake,
  MessageSquare,
  User,
  Users,
  ShieldAlert,
  BarChart3,
  Bot,
  Database,
  SlidersHorizontal,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const Sidebar: React.FC = () => {
  const { user } = useAuth();
  if (!user) return null;

  const role = user.role;

  const passengerLinks = [
    { to: '/passenger', label: 'My Dashboard', icon: LayoutDashboard },
    { to: '/flights', label: 'Book Flight', icon: Plane },
    { to: '/passenger/bookings', label: 'My Bookings & Tickets', icon: Ticket },
    { to: '/passenger/baggage', label: 'Baggage Assistance', icon: Luggage },
    { to: '/passenger/accessibility', label: 'Special Assistance', icon: HeartHandshake },
    { to: '/passenger/feedback', label: 'Feedback & Reviews', icon: MessageSquare },
    { to: '/passenger/profile', label: 'Traveler Profile', icon: User },
    { to: '/ai-chat', label: 'AI Travel Assistant', icon: Bot, highlight: true },
  ];

  const staffLinks = [
    { to: '/staff', label: 'Ops Dashboard', icon: LayoutDashboard },
    { to: '/staff/passengers', label: 'Passenger Lookup', icon: Users },
    { to: '/staff/disruptions', label: 'Disruption Control', icon: ShieldAlert },
    { to: '/staff/baggage', label: 'Baggage Cases', icon: Luggage },
    { to: '/staff/accessibility', label: 'Accessibility Queue', icon: HeartHandshake },
    { to: '/ai-chat', label: 'Staff AI Assistant', icon: Bot, highlight: true },
  ];

  const adminLinks = [
    { to: '/admin', label: 'Analytics Dashboard', icon: BarChart3 },
    { to: '/admin/flights', label: 'Flight Management', icon: Plane },
    { to: '/admin/users', label: 'User & Staff Accounts', icon: Users },
    { to: '/admin/ai-logs', label: 'AI Execution Logs', icon: SlidersHorizontal },
    { to: '/admin/knowledge-base', label: 'RAG Knowledge Base', icon: Database },
    { to: '/ai-chat', label: 'Admin Analytics AI', icon: Bot, highlight: true },
  ];

  const links =
    role === 'ADMIN' ? adminLinks : role === 'STAFF' ? staffLinks : passengerLinks;

  return (
    <aside className="w-64 bg-slate-900 text-slate-300 min-h-[calc(100vh-4rem)] flex flex-col justify-between p-4 border-r border-slate-800">
      <div className="space-y-6">
        {/* User Card */}
        <div className="px-3 py-2 bg-slate-800/80 rounded-xl border border-slate-700/60">
          <p className="text-xs text-slate-400 font-medium">Logged in Role</p>
          <div className="flex items-center justify-between mt-1">
            <span className="font-semibold text-white text-sm tracking-wide">
              {role}
            </span>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          </div>
          <p className="text-[11px] text-slate-400 truncate mt-0.5">{user.email}</p>
        </div>

        {/* Navigation list */}
        <nav className="space-y-1">
          {links.map((link) => {
            const Icon = link.icon;
            return (
              <NavLink
                key={link.to}
                to={link.to}
                end={link.to === '/passenger' || link.to === '/staff' || link.to === '/admin'}
                className={({ isActive }) =>
                  `flex items-center space-x-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                      : link.highlight
                      ? 'text-sky-300 hover:bg-slate-800 border border-sky-500/30'
                      : 'hover:bg-slate-800 hover:text-white'
                  }`
                }
              >
                <Icon className={`w-4 h-4 ${link.highlight ? 'text-sky-400' : ''}`} />
                <span>{link.label}</span>
              </NavLink>
            );
          })}
        </nav>
      </div>

      {/* Architecture note */}
      <div className="p-3 bg-slate-800/40 rounded-lg border border-slate-700/40 text-[11px] text-slate-400">
        <span className="font-semibold text-slate-300 block mb-0.5">Architecture:</span>
        Spring Boot 3 + LangGraph Multi-Agent AI
      </div>
    </aside>
  );
};

export default Sidebar;
