import React from 'react';

interface StatusBadgeProps {
  status: string;
  type?: 'flight' | 'booking' | 'baggage' | 'sentiment' | 'urgency' | 'accessibility';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, type = 'booking' }) => {
  const getBadgeStyle = () => {
    switch (status.toUpperCase()) {
      // Success states
      case 'CONFIRMED':
      case 'ARRIVED':
      case 'DELIVERED':
      case 'COMPLETED':
      case 'POSITIVE':
      case 'APPROVED':
      case 'SCHEDULED':
      case 'ACTIVE':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';

      // Info / Ongoing states
      case 'DEPARTED':
      case 'LOCATED':
      case 'IN_TRANSIT':
      case 'ASSIGNED':
      case 'NEUTRAL':
      case 'SINGLE_AGENT':
        return 'bg-blue-100 text-blue-800 border-blue-200';

      // Warning states
      case 'DELAYED':
      case 'INVESTIGATING':
      case 'PENDING':
      case 'RESCHEDULED':
      case 'MEDIUM':
      case 'MULTI_AGENT':
        return 'bg-amber-100 text-amber-800 border-amber-200';

      // Danger / Alert states
      case 'CANCELLED':
      case 'REJECTED':
      case 'MISSING':
      case 'DAMAGED':
      case 'NEGATIVE':
      case 'HIGH':
      case 'SUSPENDED':
        return 'bg-rose-100 text-rose-800 border-rose-200';

      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${getBadgeStyle()}`}
    >
      <span className="w-1.5 h-1.5 mr-1.5 rounded-full bg-current opacity-75"></span>
      {status.replace(/_/g, ' ')}
    </span>
  );
};

export default StatusBadge;
