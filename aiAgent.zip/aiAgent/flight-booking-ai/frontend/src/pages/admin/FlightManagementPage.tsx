import React, { useState, useEffect } from 'react';
import { Plane, PlusCircle, Search, Edit2, AlertCircle } from 'lucide-react';
import { flightApi } from '../../services/api';
import { Flight } from '../../types';
import StatusBadge from '../../components/common/StatusBadge';
import LoadingSpinner from '../../components/common/LoadingSpinner';

export const FlightManagementPage: React.FC = () => {
  const [flights, setFlights] = useState<Flight[]>([]);
  const [loading, setLoading] = useState(true);
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [selectedFlight, setSelectedFlight] = useState<Flight | null>(null);
  const [newStatus, setNewStatus] = useState<string>('SCHEDULED');
  const [delayMinutes, setDelayMinutes] = useState<number>(0);
  const [delayReason, setDelayReason] = useState<string>('');
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    fetchFlights();
  }, []);

  const fetchFlights = async () => {
    setLoading(true);
    try {
      const data = await flightApi.getAllFlights();
      setFlights(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFlight) return;
    setUpdating(true);
    try {
      await flightApi.updateFlightStatus(selectedFlight.id, {
        status: newStatus,
        delayMinutes,
        delayReason,
      });
      alert('Flight status updated.');
      setShowStatusModal(false);
      fetchFlights();
    } catch (err: any) {
      alert(err.response?.data?.message || 'Update failed.');
    } finally {
      setUpdating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">Flight Inventory & Schedule</h1>
          <p className="text-xs text-slate-500">
            Control flight schedules, modify operating statuses, and review route details
          </p>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-sm">
            Configured Flights ({flights.length})
          </h3>
        </div>

        {loading ? (
          <LoadingSpinner message="Loading flight schedules..." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-100">
                <tr>
                  <th className="px-5 py-3">Flight No</th>
                  <th className="px-5 py-3">Airline</th>
                  <th className="px-5 py-3">Origin</th>
                  <th className="px-5 py-3">Destination</th>
                  <th className="px-5 py-3">Base Price</th>
                  <th className="px-5 py-3">Status</th>
                  <th className="px-5 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {flights.map((f) => (
                  <tr key={f.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-5 py-3.5 font-mono font-bold text-indigo-700">
                      {f.flightNumber}
                    </td>
                    <td className="px-5 py-3.5 text-slate-800 font-semibold">{f.airline.name}</td>
                    <td className="px-5 py-3.5 text-slate-600">
                      {f.sourceAirport.name} ({f.sourceAirport.code})
                    </td>
                    <td className="px-5 py-3.5 text-slate-600">
                      {f.destinationAirport.name} ({f.destinationAirport.code})
                    </td>
                    <td className="px-5 py-3.5 font-bold text-slate-900">
                      ₹{f.basePrice.toLocaleString()}
                    </td>
                    <td className="px-5 py-3.5">
                      <StatusBadge status={f.status} type="flight" />
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <button
                        onClick={() => {
                          setSelectedFlight(f);
                          setNewStatus(f.status);
                          setDelayMinutes(f.delayMinutes || 0);
                          setDelayReason(f.delayReason || '');
                          setShowStatusModal(true);
                        }}
                        className="px-3 py-1 rounded-lg bg-indigo-50 text-indigo-700 font-bold hover:bg-indigo-100"
                      >
                        Edit Status
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Edit Status Modal */}
      {showStatusModal && selectedFlight && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <h3 className="text-lg font-bold text-slate-900">
              Update Flight {selectedFlight.flightNumber}
            </h3>

            <form onSubmit={handleUpdateStatus} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Status
                </label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-bold"
                >
                  <option value="SCHEDULED">SCHEDULED</option>
                  <option value="DELAYED">DELAYED</option>
                  <option value="CANCELLED">CANCELLED</option>
                  <option value="DEPARTED">DEPARTED</option>
                  <option value="ARRIVED">ARRIVED</option>
                </select>
              </div>

              {newStatus === 'DELAYED' && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Delay Minutes
                  </label>
                  <input
                    type="number"
                    value={delayMinutes}
                    onChange={(e) => setDelayMinutes(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-semibold"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Reason / Notes
                </label>
                <input
                  type="text"
                  value={delayReason}
                  onChange={(e) => setDelayReason(e.target.value)}
                  placeholder="e.g. Scheduled maintenance"
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-medium"
                />
              </div>

              <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowStatusModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={updating}
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 disabled:opacity-50"
                >
                  {updating ? 'Saving...' : 'Update Status'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default FlightManagementPage;
