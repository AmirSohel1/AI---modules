import React, { useState, useEffect } from 'react';
import {
  HeartHandshake,
  CheckCircle,
  Clock,
  User,
  Shield,
  HelpCircle,
  AlertCircle,
  PlusCircle,
} from 'lucide-react';
import { accessibilityApi } from '../../services/api';
import { AccessibilityRequest } from '../../types';
import StatusBadge from '../../components/common/StatusBadge';
import LoadingSpinner from '../../components/common/LoadingSpinner';

export const AccessibilityPage: React.FC = () => {
  const [requests, setRequests] = useState<AccessibilityRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);

  // Form
  const [bookingReference, setBookingReference] = useState('');
  const [passengerName, setPassengerName] = useState('');
  const [serviceType, setServiceType] = useState('WHEELCHAIR_RAMP');
  const [details, setDetails] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = async () => {
    setLoading(true);
    try {
      const data = await accessibilityApi.getMyRequests();
      setRequests(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await accessibilityApi.requestAssistance({
        bookingReference,
        passengerName,
        serviceType,
        details,
      });
      alert('Special assistance request logged with ground operations staff.');
      setShowModal(false);
      setBookingReference('');
      setPassengerName('');
      setDetails('');
      fetchRequests();
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed to submit assistance request.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">
            Special Passenger Assistance & Accessibility
          </h1>
          <p className="text-xs text-slate-500">
            Complimentary airport mobility, wheelchair escort, and visual/elderly assistance
          </p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 shadow-sm"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Request Assistance</span>
        </button>
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
            Category 1: Wheelchair
          </span>
          <h3 className="text-sm font-bold text-slate-900">Ramp & Cabin Wheelchairs</h3>
          <p className="text-xs text-slate-500">
            Dedicated airport wheelchair assistance from security check to your aircraft seat.
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <span className="text-xs font-bold text-sky-600 uppercase tracking-wider">
            Category 2: Sensory Escort
          </span>
          <h3 className="text-sm font-bold text-slate-900">Visual & Hearing Support</h3>
          <p className="text-xs text-slate-500">
            Ground staff guide to assist passengers through check-in, customs, and boarding gate.
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <span className="text-xs font-bold text-amber-600 uppercase tracking-wider">
            Category 3: Elderly Care
          </span>
          <h3 className="text-sm font-bold text-slate-900">Senior Traveler Assistance</h3>
          <p className="text-xs text-slate-500">
            Electric buggy transit inside large airport terminals between security and gates.
          </p>
        </div>
      </div>

      {/* Requests Table */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <h3 className="text-base font-bold text-slate-900">
          My Assistance Requests ({requests.length})
        </h3>

        {loading ? (
          <LoadingSpinner message="Retrieving assistance schedule..." />
        ) : requests.length === 0 ? (
          <div className="p-8 text-center bg-slate-50 rounded-xl space-y-2">
            <HeartHandshake className="w-8 h-8 text-indigo-400 mx-auto" />
            <p className="text-xs font-bold text-slate-700">No Assistance Requests</p>
            <p className="text-xs text-slate-400">
              Need help navigating the airport? Submit a request before departure.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {requests.map((r) => (
              <div
                key={r.id}
                className="p-4 rounded-xl border border-slate-200 hover:border-slate-300 transition-colors flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="font-mono text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded">
                      {r.bookingReference}
                    </span>
                    <span className="text-xs font-bold text-slate-900">{r.passengerName}</span>
                  </div>
                  <p className="text-xs font-medium text-slate-700">{r.serviceType}</p>
                  <p className="text-[11px] text-slate-500">{r.details}</p>
                </div>

                <div className="flex items-center space-x-3">
                  {r.assignedStaffName && (
                    <span className="text-xs text-slate-600 bg-slate-100 px-2.5 py-1 rounded-lg">
                      Assigned: {r.assignedStaffName}
                    </span>
                  )}
                  <StatusBadge status={r.status} type="accessibility" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Request Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center space-x-2 text-indigo-600">
              <HeartHandshake className="w-6 h-6" />
              <h3 className="text-lg font-bold">Request Special Assistance</h3>
            </div>

            <form onSubmit={handleRequest} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  PNR Reference
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. PNR-1001"
                  value={bookingReference}
                  onChange={(e) => setBookingReference(e.target.value.toUpperCase())}
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Passenger Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="Name as printed on ticket"
                  value={passengerName}
                  onChange={(e) => setPassengerName(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-semibold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Assistance Type
                </label>
                <select
                  value={serviceType}
                  onChange={(e) => setServiceType(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-semibold"
                >
                  <option value="WHEELCHAIR_RAMP">Wheelchair for Ramp & Gate Transit</option>
                  <option value="WHEELCHAIR_CABIN">Wheelchair to Aircraft Seat (Cabin)</option>
                  <option value="VISUAL_IMPAIRMENT">Visual Assistance & Airport Escort</option>
                  <option value="HEARING_IMPAIRMENT">Hearing Impaired Guidance</option>
                  <option value="ELDERLY_ASSISTANCE">Senior Citizen Buggy & Porter Assistance</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Specific Requirements / Details
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="e.g. Requires assistance climbing aircraft stairs; carrying walking stick"
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-medium"
                />
              </div>

              <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 disabled:opacity-50"
                >
                  {submitting ? 'Submitting...' : 'Submit Request'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AccessibilityPage;
