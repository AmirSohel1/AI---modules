import React, { useState, useEffect } from 'react';
import {
  Luggage,
  Search,
  AlertCircle,
  PlusCircle,
  Clock,
  CheckCircle,
  HelpCircle,
  ShieldAlert,
} from 'lucide-react';
import { baggageApi } from '../../services/api';
import { BaggageCase } from '../../types';
import StatusBadge from '../../components/common/StatusBadge';
import LoadingSpinner from '../../components/common/LoadingSpinner';

export const BaggageAssistancePage: React.FC = () => {
  const [cases, setCases] = useState<BaggageCase[]>([]);
  const [loading, setLoading] = useState(true);
  const [showReportModal, setShowReportModal] = useState(false);

  // Report form state
  const [bookingReference, setBookingReference] = useState('');
  const [flightNumber, setFlightNumber] = useState('');
  const [tagNumber, setTagNumber] = useState('');
  const [caseType, setCaseType] = useState<'MISSING' | 'DELAYED' | 'DAMAGED'>('DELAYED');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Allowance calculator state
  const [calcCabinKg, setCalcCabinKg] = useState<number>(7);
  const [calcCheckinKg, setCalcCheckinKg] = useState<number>(15);
  const [cabinClass, setCabinClass] = useState<'ECONOMY' | 'BUSINESS'>('ECONOMY');

  useEffect(() => {
    fetchBaggageCases();
  }, []);

  const fetchBaggageCases = async () => {
    setLoading(true);
    try {
      const data = await baggageApi.getMyBaggageCases();
      setCases(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleReportCase = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await baggageApi.reportCase({
        bookingReference,
        flightNumber,
        tagNumber,
        caseType,
        description,
      });
      alert('Baggage tracking case registered successfully.');
      setShowReportModal(false);
      setBookingReference('');
      setFlightNumber('');
      setTagNumber('');
      setDescription('');
      fetchBaggageCases();
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed to submit baggage report.');
    } finally {
      setSubmitting(false);
    }
  };

  // Allowance calculation
  const cabinLimit = 7;
  const checkinLimit = cabinClass === 'BUSINESS' ? 30 : 15;
  const excessCabin = Math.max(0, calcCabinKg - cabinLimit);
  const excessCheckin = Math.max(0, calcCheckinKg - checkinLimit);
  const excessCharge = (excessCabin + excessCheckin) * 550; // ₹550 per excess kg

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">Baggage Assistance & Tracking</h1>
          <p className="text-xs text-slate-500">
            Check luggage allowance rules, estimate excess fees, and track mishandled bags
          </p>
        </div>
        <button
          onClick={() => setShowReportModal(true)}
          className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 shadow-sm"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Report Delayed / Lost Bag</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Baggage Allowance & Fee Calculator */}
        <div className="lg:col-span-1 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-5">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-base font-bold text-slate-900 flex items-center space-x-2">
              <Luggage className="w-4 h-4 text-indigo-600" />
              <span>Baggage Fee Calculator</span>
            </h3>
            <p className="text-xs text-slate-500">Instant allowance & excess weight estimator</p>
          </div>

          <div className="space-y-4 text-xs font-semibold text-slate-700">
            <div>
              <label className="block uppercase text-slate-500 mb-1">Cabin Class</label>
              <select
                value={cabinClass}
                onChange={(e: any) => setCabinClass(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 font-bold"
              >
                <option value="ECONOMY">Economy Class (15 kg Free Check-in)</option>
                <option value="BUSINESS">Business Class (30 kg Free Check-in)</option>
              </select>
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="uppercase text-slate-500">Cabin Hand Luggage:</span>
                <span className="font-bold text-slate-900">{calcCabinKg} kg (Max 7 kg free)</span>
              </div>
              <input
                type="range"
                min={1}
                max={15}
                value={calcCabinKg}
                onChange={(e) => setCalcCabinKg(Number(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="uppercase text-slate-500">Check-in Baggage:</span>
                <span className="font-bold text-slate-900">
                  {calcCheckinKg} kg (Max {checkinLimit} kg free)
                </span>
              </div>
              <input
                type="range"
                min={5}
                max={45}
                value={calcCheckinKg}
                onChange={(e) => setCalcCheckinKg(Number(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
              <div className="flex justify-between text-slate-600">
                <span>Free Allowed:</span>
                <span>{cabinLimit + checkinLimit} kg Total</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Excess Weight:</span>
                <span className="font-bold text-amber-700">
                  {excessCabin + excessCheckin} kg
                </span>
              </div>
              <div className="pt-2 border-t border-slate-200 flex justify-between font-extrabold text-sm text-slate-900">
                <span>Estimated Excess Charge:</span>
                <span className="text-indigo-600">₹{excessCharge.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>

        {/* My Baggage Tracking Cases */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-base font-bold text-slate-900">
              Active Baggage Inquiries ({cases.length})
            </h3>

            {loading ? (
              <LoadingSpinner message="Checking baggage case status..." />
            ) : cases.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-xl space-y-2">
                <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto" />
                <p className="text-xs font-bold text-slate-700">All Baggage Accounted For</p>
                <p className="text-xs text-slate-400">
                  No active lost or delayed baggage reports found for your profile.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {cases.map((c) => (
                  <div
                    key={c.id}
                    className="p-4 rounded-xl border border-slate-200 hover:border-slate-300 transition-colors space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="font-mono text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded">
                          {c.caseReference}
                        </span>
                        <StatusBadge status={c.caseType} type="baggage" />
                      </div>
                      <StatusBadge status={c.status} type="baggage" />
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                      <div>
                        <span className="text-slate-400 block text-[10px] uppercase">
                          Booking Reference
                        </span>
                        <span className="font-mono font-bold text-slate-800">
                          {c.bookingReference}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px] uppercase">
                          Flight Number
                        </span>
                        <span className="font-mono font-bold text-slate-800">{c.flightNumber}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px] uppercase">Tag Number</span>
                        <span className="font-mono font-bold text-slate-800">{c.tagNumber}</span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 bg-slate-50 p-2 rounded-lg">
                      {c.description}
                    </p>

                    {c.internalNotes && (
                      <p className="text-[11px] text-indigo-700 bg-indigo-50/60 p-2 rounded-lg font-medium">
                        <span className="font-bold">Staff Update:</span> {c.internalNotes}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Report Baggage Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center space-x-2 text-indigo-600">
              <Luggage className="w-6 h-6" />
              <h3 className="text-lg font-bold">Report Mishandled Baggage</h3>
            </div>
            <p className="text-xs text-slate-500">
              Submit your baggage tag details to initiate a ground search across baggage carousels.
            </p>

            <form onSubmit={handleReportCase} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  PNR Reference
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. PNR-1001"
                  value={bookingReference}
                  onChange={(e) => setBookingReference(e.target.value.toUpperCase())}
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-mono font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Flight Number
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. AI-101"
                    value={flightNumber}
                    onChange={(e) => setFlightNumber(e.target.value.toUpperCase())}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Bag Tag Number
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. AI987211"
                    value={tagNumber}
                    onChange={(e) => setTagNumber(e.target.value.toUpperCase())}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Case Type
                </label>
                <select
                  value={caseType}
                  onChange={(e: any) => setCaseType(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-semibold"
                >
                  <option value="DELAYED">Delayed / Not on Conveyor Belt</option>
                  <option value="MISSING">Missing / Lost Baggage</option>
                  <option value="DAMAGED">Damaged Luggage / Contents</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Bag Description & Color
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="e.g. Black Samsonite hardcase trolley with red ribbon on handle"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-medium"
                />
              </div>

              <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowReportModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 disabled:opacity-50"
                >
                  {submitting ? 'Registering...' : 'Register Case'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default BaggageAssistancePage;
