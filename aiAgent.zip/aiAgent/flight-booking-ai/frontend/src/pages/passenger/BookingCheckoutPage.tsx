import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import {
  Plane,
  CreditCard,
  ShieldCheck,
  User,
  AlertCircle,
  CheckCircle,
  Clock,
  ArrowRight,
  Info,
} from 'lucide-react';
import { flightApi, bookingApi } from '../../services/api';
import { Flight, FlightSeat } from '../../types';
import LoadingSpinner from '../../components/common/LoadingSpinner';

export const BookingCheckoutPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const flightId = Number(searchParams.get('flightId'));
  const travelDate = searchParams.get('date') || new Date().toISOString().split('T')[0];

  const [flight, setFlight] = useState<Flight | null>(null);
  const [seats, setSeats] = useState<FlightSeat[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Form State
  const [passengerName, setPassengerName] = useState('');
  const [passengerAge, setPassengerAge] = useState<number>(28);
  const [passengerGender, setPassengerGender] = useState('MALE');
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [selectedSeat, setSelectedSeat] = useState<FlightSeat | null>(null);
  const [paymentMethod, setPaymentMethod] = useState('UPI');

  useEffect(() => {
    if (!flightId) {
      setError('No flight selected.');
      setLoading(false);
      return;
    }
    fetchFlightAndSeats();
  }, [flightId]);

  const fetchFlightAndSeats = async () => {
    setLoading(true);
    try {
      const [flightData, seatsData] = await Promise.all([
        flightApi.getFlightById(flightId),
        flightApi.getFlightSeats(flightId),
      ]);
      setFlight(flightData);
      setSeats(seatsData);

      // Default email from logged-in user if available
      const savedUser = localStorage.getItem('user');
      if (savedUser) {
        const u = JSON.parse(savedUser);
        setPassengerName(u.fullName || '');
        setContactEmail(u.email || '');
        setContactPhone(u.phone || '');
      }
    } catch (err: any) {
      setError('Failed to fetch flight details and seat layout.');
    } finally {
      setLoading(false);
    }
  };

  const calculateTotalPrice = () => {
    if (!flight) return 0;
    const base = flight.basePrice;
    const multiplier = selectedSeat ? selectedSeat.priceMultiplier : 1.0;
    const seatPrice = base * multiplier;
    const tax = seatPrice * 0.12; // 12% GST
    return Math.round(seatPrice + tax);
  };

  const handleBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSeat) {
      setError('Please select an available seat on the interactive seat map.');
      return;
    }

    setSubmitting(true);
    setError(null);
    try {
      const booking = await bookingApi.createBooking({
        flightId,
        travelDate,
        contactEmail,
        contactPhone,
        passengers: [
          {
            fullName: passengerName,
            age: Number(passengerAge),
            gender: passengerGender,
            seatNumber: selectedSeat.seatNumber,
          },
        ],
        paymentMethod,
      });

      // Redirect to confirmation page with booking reference
      navigate(`/passenger/confirmation?pnr=${booking.bookingReference}`);
    } catch (err: any) {
      setError(
        err.response?.data?.message ||
          'Booking failed. Seat may have just been locked by another passenger. Please select another seat.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <LoadingSpinner message="Loading seat inventory & fare rules..." />;
  if (error && !flight) {
    return (
      <div className="max-w-2xl mx-auto my-12 p-6 bg-rose-50 border border-rose-200 rounded-2xl text-rose-700 text-center">
        <AlertCircle className="w-8 h-8 mx-auto mb-2 text-rose-500" />
        <p className="font-bold">{error}</p>
      </div>
    );
  }

  // Group seats by class
  const businessSeats = seats.filter((s) => s.seatClass === 'BUSINESS');
  const economySeats = seats.filter((s) => s.seatClass === 'ECONOMY');

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">Flight Booking & Seat Selection</h1>
        <p className="text-xs text-slate-500">
          Select your seat, provide traveler information, and complete simulated payment
        </p>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center space-x-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Interactive Seat Map */}
        <div className="lg:col-span-2 space-y-6">
          {/* Flight Summary Card */}
          {flight && (
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-700 font-bold flex items-center justify-center text-xs">
                  {flight.airline.code}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    {flight.airline.name} • {flight.flightNumber}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {flight.sourceAirport.city} ({flight.sourceAirport.code}) →{' '}
                    {flight.destinationAirport.city} ({flight.destinationAirport.code})
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs text-slate-400">Date: {travelDate}</p>
                <p className="text-sm font-extrabold text-slate-900">
                  Base: ₹{flight.basePrice.toLocaleString()}
                </p>
              </div>
            </div>
          )}

          {/* Interactive Seat Map */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">Select Your Seat</h3>
                <p className="text-xs text-slate-500">
                  Real-time seat occupancy with transactional database locking
                </p>
              </div>
              <div className="flex items-center space-x-4 text-xs">
                <span className="flex items-center space-x-1.5">
                  <span className="w-3.5 h-3.5 rounded bg-emerald-50 border border-emerald-400"></span>
                  <span>Available</span>
                </span>
                <span className="flex items-center space-x-1.5">
                  <span className="w-3.5 h-3.5 rounded bg-indigo-600"></span>
                  <span>Selected</span>
                </span>
                <span className="flex items-center space-x-1.5">
                  <span className="w-3.5 h-3.5 rounded bg-slate-200"></span>
                  <span>Occupied</span>
                </span>
              </div>
            </div>

            {/* Airplane Fuselage Layout */}
            <div className="max-w-md mx-auto p-6 bg-slate-50 rounded-3xl border-2 border-slate-200 space-y-6">
              {/* Cockpit Indicator */}
              <div className="w-24 h-6 mx-auto bg-slate-300 rounded-t-full flex items-center justify-center text-[10px] font-bold text-slate-600">
                COCKPIT
              </div>

              {/* Business Class Section */}
              <div>
                <div className="text-center mb-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-amber-700 bg-amber-50 px-3 py-0.5 rounded-full border border-amber-200">
                    Business Class (1.5x Fare)
                  </span>
                </div>
                <div className="grid grid-cols-4 gap-2.5">
                  {businessSeats.map((seat) => {
                    const isSelected = selectedSeat?.id === seat.id;
                    return (
                      <button
                        key={seat.id}
                        type="button"
                        disabled={!seat.isAvailable}
                        onClick={() => setSelectedSeat(seat)}
                        className={`p-2.5 rounded-xl text-xs font-bold transition-all border ${
                          !seat.isAvailable
                            ? 'bg-slate-200 border-slate-300 text-slate-400 cursor-not-allowed'
                            : isSelected
                            ? 'bg-indigo-600 border-indigo-700 text-white shadow-md scale-105'
                            : 'bg-amber-50 border-amber-300 text-amber-900 hover:bg-amber-100 hover:border-amber-400'
                        }`}
                      >
                        {seat.seatNumber}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Aisle Divider */}
              <div className="flex items-center space-x-2 text-[10px] text-slate-400 justify-center">
                <div className="h-px w-16 bg-slate-200"></div>
                <span>AISLE / GALLEY</span>
                <div className="h-px w-16 bg-slate-200"></div>
              </div>

              {/* Economy Class Section */}
              <div>
                <div className="text-center mb-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-3 py-0.5 rounded-full border border-indigo-200">
                    Economy Class (Standard Fare)
                  </span>
                </div>
                <div className="grid grid-cols-6 gap-2">
                  {economySeats.map((seat) => {
                    const isSelected = selectedSeat?.id === seat.id;
                    return (
                      <button
                        key={seat.id}
                        type="button"
                        disabled={!seat.isAvailable}
                        onClick={() => setSelectedSeat(seat)}
                        className={`p-2 rounded-lg text-xs font-bold transition-all border ${
                          !seat.isAvailable
                            ? 'bg-slate-200 border-slate-300 text-slate-400 cursor-not-allowed'
                            : isSelected
                            ? 'bg-indigo-600 border-indigo-700 text-white shadow-md scale-105'
                            : 'bg-emerald-50 border-emerald-300 text-emerald-900 hover:bg-emerald-100'
                        }`}
                      >
                        {seat.seatNumber}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Passenger Info & Checkout */}
        <div className="space-y-6">
          <form
            onSubmit={handleBooking}
            className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-5"
          >
            <h3 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
              Passenger & Payment Details
            </h3>

            {/* Passenger Info */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={passengerName}
                  onChange={(e) => setPassengerName(e.target.value)}
                  placeholder="e.g. John Doe"
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Age
                  </label>
                  <input
                    type="number"
                    required
                    min={1}
                    max={120}
                    value={passengerAge}
                    onChange={(e) => setPassengerAge(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Gender
                  </label>
                  <select
                    value={passengerGender}
                    onChange={(e) => setPassengerGender(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    <option value="MALE">Male</option>
                    <option value="FEMALE">Female</option>
                    <option value="OTHER">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Email (for Ticket PDF)
                </label>
                <input
                  type="email"
                  required
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  required
                  value={contactPhone}
                  onChange={(e) => setContactPhone(e.target.value)}
                  placeholder="+91 9876543210"
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Payment Method */}
            <div className="pt-3 border-t border-slate-100">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Simulated Payment Mode
              </label>
              <div className="space-y-2 text-xs font-medium text-slate-700">
                <label className="flex items-center space-x-2 p-2.5 rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-50">
                  <input
                    type="radio"
                    name="payment"
                    checked={paymentMethod === 'UPI'}
                    onChange={() => setPaymentMethod('UPI')}
                    className="text-indigo-600 focus:ring-indigo-500"
                  />
                  <span>UPI (Google Pay, PhonePe, Paytm)</span>
                </label>
                <label className="flex items-center space-x-2 p-2.5 rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-50">
                  <input
                    type="radio"
                    name="payment"
                    checked={paymentMethod === 'CARD'}
                    onChange={() => setPaymentMethod('CARD')}
                    className="text-indigo-600 focus:ring-indigo-500"
                  />
                  <span>Credit / Debit Card</span>
                </label>
                <label className="flex items-center space-x-2 p-2.5 rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-50">
                  <input
                    type="radio"
                    name="payment"
                    checked={paymentMethod === 'NETBANKING'}
                    onChange={() => setPaymentMethod('NETBANKING')}
                    className="text-indigo-600 focus:ring-indigo-500"
                  />
                  <span>Net Banking</span>
                </label>
              </div>
            </div>

            {/* Price Summary */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-600">Selected Seat:</span>
                <span className="font-bold text-slate-900">
                  {selectedSeat ? `${selectedSeat.seatNumber} (${selectedSeat.seatClass})` : 'None'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Base Fare:</span>
                <span className="font-semibold text-slate-800">
                  ₹{flight ? (flight.basePrice * (selectedSeat?.priceMultiplier || 1)).toLocaleString() : 0}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Taxes & GST (12%):</span>
                <span className="font-semibold text-slate-800">
                  ₹{flight ? Math.round(flight.basePrice * (selectedSeat?.priceMultiplier || 1) * 0.12).toLocaleString() : 0}
                </span>
              </div>
              <div className="pt-2 border-t border-slate-200 flex justify-between text-sm font-extrabold text-slate-900">
                <span>Total Amount:</span>
                <span className="text-indigo-600">₹{calculateTotalPrice().toLocaleString()}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting || !selectedSeat}
              className="w-full flex justify-center items-center py-3 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 shadow-md shadow-indigo-200 transition-colors disabled:opacity-50"
            >
              <CreditCard className="w-4 h-4 mr-2" />
              {submitting ? 'Confirming Reservation...' : `Pay ₹${calculateTotalPrice().toLocaleString()} & Confirm`}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default BookingCheckoutPage;
