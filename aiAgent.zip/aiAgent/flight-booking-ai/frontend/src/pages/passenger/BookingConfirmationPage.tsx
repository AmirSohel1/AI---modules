import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import {
  CheckCircle,
  Download,
  Plane,
  Bot,
  Calendar,
  User,
  ArrowRight,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { bookingApi } from '../../services/api';
import { Booking } from '../../types';
import LoadingSpinner from '../../components/common/LoadingSpinner';

export const BookingConfirmationPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const pnr = searchParams.get('pnr');

  const [booking, setBooking] = useState<Booking | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    if (pnr) {
      bookingApi
        .getBookingByReference(pnr)
        .then((data) => setBooking(data))
        .catch(() => setError('Could not locate booking reference.'))
        .finally(() => setLoading(false));
    } else {
      setError('Missing booking reference.');
      setLoading(false);
    }
  }, [pnr]);

  const handleDownloadTicket = async () => {
    if (!booking) return;
    setDownloading(true);
    try {
      const blob = await bookingApi.downloadTicketPdfBlob(booking.id);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `FlightAI-Ticket-${booking.bookingReference}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      alert('Failed to generate PDF ticket.');
    } finally {
      setDownloading(false);
    }
  };

  if (loading) return <LoadingSpinner message="Retrieving booking details..." />;

  if (error || !booking) {
    return (
      <div className="max-w-md mx-auto my-12 p-6 bg-white rounded-2xl border border-slate-200 shadow text-center space-y-4">
        <h2 className="text-lg font-bold text-slate-800">Booking Reference Not Found</h2>
        <p className="text-xs text-slate-500">{error || 'Please check your PNR number.'}</p>
        <Link
          to="/passenger"
          className="inline-block px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold"
        >
          Return to Dashboard
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Confirmation Success Card */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-md p-6 sm:p-8 text-center space-y-4">
        <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
          <CheckCircle className="w-10 h-10" />
        </div>
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">
            Booking Confirmed & Seat Locked
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
            Ready for Takeoff!
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            A confirmation receipt and boarding details have been sent to{' '}
            <span className="font-semibold text-slate-700">{booking.contactEmail}</span>
          </p>
        </div>

        {/* PNR Banner */}
        <div className="p-4 rounded-xl bg-indigo-50 border border-indigo-200 max-w-sm mx-auto flex items-center justify-between">
          <div className="text-left">
            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-500">
              Booking Reference (PNR)
            </span>
            <p className="text-xl font-mono font-extrabold text-indigo-900">
              {booking.bookingReference}
            </p>
          </div>
          <button
            onClick={handleDownloadTicket}
            disabled={downloading}
            className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 shadow-sm transition-colors disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{downloading ? 'Downloading...' : 'PDF E-Ticket'}</span>
          </button>
        </div>
      </div>

      {/* Ticket Details Preview */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-700 font-bold flex items-center justify-center text-xs">
              {booking.flight.airline.code}
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">{booking.flight.airline.name}</h3>
              <p className="text-xs font-mono text-slate-500">{booking.flight.flightNumber}</p>
            </div>
          </div>
          <div className="text-right">
            <span className="text-xs text-slate-400 block">Total Paid</span>
            <span className="text-base font-extrabold text-slate-900">
              ₹{booking.totalAmount.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Flight Route */}
        <div className="grid grid-cols-3 gap-4 items-center text-center">
          <div className="text-left">
            <p className="text-xl font-extrabold text-slate-900">
              {new Date(booking.flight.departureTime).toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit',
              })}
            </p>
            <p className="text-xs font-bold text-slate-700">{booking.flight.sourceAirport.code}</p>
            <p className="text-[11px] text-slate-400">{booking.flight.sourceAirport.city}</p>
          </div>

          <div className="flex flex-col items-center">
            <span className="text-[10px] text-slate-400 font-medium mb-1">
              {Math.floor(booking.flight.durationMinutes / 60)}h{' '}
              {booking.flight.durationMinutes % 60}m
            </span>
            <div className="w-full flex items-center space-x-1">
              <div className="h-0.5 flex-1 bg-slate-200"></div>
              <Plane className="w-3.5 h-3.5 text-indigo-600 transform rotate-90" />
              <div className="h-0.5 flex-1 bg-slate-200"></div>
            </div>
            <span className="text-[10px] text-slate-500 mt-1">Travel Date: {booking.travelDate}</span>
          </div>

          <div className="text-right">
            <p className="text-xl font-extrabold text-slate-900">
              {new Date(booking.flight.arrivalTime).toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit',
              })}
            </p>
            <p className="text-xs font-bold text-slate-700">
              {booking.flight.destinationAirport.code}
            </p>
            <p className="text-[11px] text-slate-400">{booking.flight.destinationAirport.city}</p>
          </div>
        </div>

        {/* Passenger Seat List */}
        <div className="pt-4 border-t border-slate-100">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-3">
            Passenger & Seat Assignments
          </h4>
          <div className="space-y-2">
            {booking.passengers.map((p) => (
              <div
                key={p.id}
                className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs"
              >
                <div className="flex items-center space-x-2">
                  <User className="w-4 h-4 text-slate-400" />
                  <span className="font-bold text-slate-800">{p.fullName}</span>
                  <span className="text-slate-400">
                    ({p.age} yrs, {p.gender})
                  </span>
                </div>
                <div className="flex items-center space-x-3">
                  <span className="px-2.5 py-1 rounded bg-indigo-100 text-indigo-800 font-mono font-bold text-xs">
                    Seat {p.seatNumber}
                  </span>
                  <span className="text-[11px] font-mono text-slate-400">#{p.ticketNumber}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* AI Assistant Help Card */}
      <div className="bg-gradient-to-r from-indigo-50 to-sky-50 rounded-2xl border border-indigo-200 p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center">
            <Bot className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-900">Need airport or baggage guidance?</h4>
            <p className="text-xs text-slate-600">
              Ask our RAG-powered AI Assistant about baggage limits, web check-in, or terminal gates.
            </p>
          </div>
        </div>
        <Link
          to={`/ai-chat?query=${encodeURIComponent(
            `What is the baggage allowance and check-in procedure for flight ${booking.flight.flightNumber}?`
          )}`}
          className="px-4 py-2 rounded-xl bg-white text-indigo-700 border border-indigo-200 text-xs font-bold hover:bg-indigo-50 shadow-sm transition-colors flex items-center space-x-1"
        >
          <span>Ask AI Assistant</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>
    </div>
  );
};

export default BookingConfirmationPage;
