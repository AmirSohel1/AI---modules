import React, { useState, useEffect } from 'react';
import {
  MessageSquare,
  Star,
  Sparkles,
  Send,
  AlertCircle,
  CheckCircle,
  ThumbsUp,
} from 'lucide-react';
import { feedbackApi } from '../../services/api';
import { Feedback } from '../../types';
import StatusBadge from '../../components/common/StatusBadge';
import LoadingSpinner from '../../components/common/LoadingSpinner';

export const FeedbackPage: React.FC = () => {
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [loading, setLoading] = useState(true);

  // Form
  const [flightNumber, setFlightNumber] = useState('');
  const [rating, setRating] = useState<number>(5);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [lastAnalyzedSentiment, setLastAnalyzedSentiment] = useState<any>(null);

  useEffect(() => {
    fetchFeedbacks();
  }, []);

  const fetchFeedbacks = async () => {
    setLoading(true);
    try {
      const data = await feedbackApi.getMyFeedback();
      setFeedbacks(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await feedbackApi.submitFeedback({
        flightNumber: flightNumber || undefined,
        rating,
        comment,
      });
      setLastAnalyzedSentiment(res);
      setComment('');
      setFlightNumber('');
      setRating(5);
      fetchFeedbacks();
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed to submit feedback.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">
          Passenger Feedback & AI Sentiment Agent
        </h1>
        <p className="text-xs text-slate-500">
          Share your journey experience. Every review is processed by the Sentiment & Urgency
          Classification Agent.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Review Form */}
        <div className="lg:col-span-1 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-base font-bold text-slate-900 flex items-center space-x-2">
              <MessageSquare className="w-4 h-4 text-indigo-600" />
              <span>Submit Flight Review</span>
            </h3>
            <p className="text-xs text-slate-500">AI analyzes sentiment upon submission</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Flight Number (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. AI-101"
                value={flightNumber}
                onChange={(e) => setFlightNumber(e.target.value.toUpperCase())}
                className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-mono font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Star Rating
              </label>
              <div className="flex items-center space-x-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    className="p-1 hover:scale-110 transition-transform"
                  >
                    <Star
                      className={`w-6 h-6 ${
                        star <= rating
                          ? 'text-amber-400 fill-amber-400'
                          : 'text-slate-300'
                      }`}
                    />
                  </button>
                ))}
                <span className="text-xs font-bold text-slate-700 ml-2">{rating} / 5</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Your Comments & Suggestions
              </label>
              <textarea
                rows={4}
                required
                placeholder="Share your thoughts about boarding, crew courtesy, in-flight comfort, or meals..."
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={submitting || !comment.trim()}
              className="w-full flex items-center justify-center space-x-2 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 disabled:opacity-50 shadow-md shadow-indigo-200 transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{submitting ? 'Analyzing & Saving...' : 'Submit Review'}</span>
            </button>
          </form>

          {/* AI Sentiment Result Highlight Card */}
          {lastAnalyzedSentiment && (
            <div className="p-4 rounded-xl bg-gradient-to-r from-indigo-50 to-sky-50 border border-indigo-200 space-y-2 animate-in fade-in duration-200">
              <div className="flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span className="text-xs font-bold text-slate-900">
                  Agent Sentiment Analysis Complete!
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <StatusBadge status={lastAnalyzedSentiment.sentiment || 'POSITIVE'} type="sentiment" />
                <span className="text-xs font-mono font-bold text-indigo-700 bg-white px-2 py-0.5 rounded border border-indigo-100">
                  Category: {lastAnalyzedSentiment.category || 'IN_FLIGHT'}
                </span>
              </div>
              {lastAnalyzedSentiment.aiSummary && (
                <p className="text-[11px] text-slate-600 italic">
                  "{lastAnalyzedSentiment.aiSummary}"
                </p>
              )}
            </div>
          )}
        </div>

        {/* Previous Reviews List */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <h3 className="text-base font-bold text-slate-900">
            My Submitted Reviews ({feedbacks.length})
          </h3>

          {loading ? (
            <LoadingSpinner message="Loading review history..." />
          ) : feedbacks.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 rounded-xl space-y-2">
              <MessageSquare className="w-8 h-8 text-slate-300 mx-auto" />
              <p className="text-xs font-bold text-slate-700">No Reviews Submitted Yet</p>
              <p className="text-xs text-slate-400">
                Help us improve airline service by submitting your travel feedback.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {feedbacks.map((f) => (
                <div
                  key={f.id}
                  className="p-4 rounded-xl border border-slate-200 hover:border-slate-300 transition-colors space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <Star
                            key={s}
                            className={`w-3.5 h-3.5 ${
                              s <= f.rating ? 'text-amber-400 fill-amber-400' : 'text-slate-200'
                            }`}
                          />
                        ))}
                      </div>
                      {f.flightNumber && (
                        <span className="font-mono text-xs font-bold text-slate-700">
                          {f.flightNumber}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center space-x-2">
                      {f.sentiment && <StatusBadge status={f.sentiment} type="sentiment" />}
                      <span className="text-[10px] text-slate-400">
                        {new Date(f.submittedAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-700">{f.comment}</p>

                  {f.aiSummary && (
                    <div className="p-2 rounded-lg bg-slate-50 border border-slate-100 text-[11px] text-slate-500">
                      <span className="font-bold text-slate-700">Agent Summary: </span>
                      {f.aiSummary}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FeedbackPage;
