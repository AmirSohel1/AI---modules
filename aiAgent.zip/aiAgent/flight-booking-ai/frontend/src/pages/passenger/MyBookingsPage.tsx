import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Ticket,
  Plane,
  Download,
  AlertTriangle,
  RotateCcw,
  XCircle,
  Eye,
  Calendar,
  Clock,
  ArrowRight,
} from 'lucide-react';
import { bookingApi, cancellationApi, rescheduleApi, flightApi } from '../../services/api';
import { Booking, Flight } from '../../types';
import StatusBadge from '../../components/common/StatusBadge';
import LoadingSpinner from '../../components/common/LoadingSpinner';

export const MyBookingsPage: React.FC = () => {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Modal states
  const [selectedBookingForCancel, setSelectedBookingForCancel] = useState<Booking | null>(null);
  const [cancelReason, setCancelReason] = useState('Personal reasons / schedule change');
  const [cancelPreview, setCancelPreview] = useState<any>(null);
  const [cancelling, setCancelling] = useState(false);

  const [selectedBookingForReschedule, setSelectedBookingForReschedule] = useState<Booking | null>(null);
  const [availableAlternativeFlights, setAvailableAlternativeFlights] = useState<Flight[]>([]);
  const [selectedNewFlightId, setSelectedNewFlightId] = useState<number | null>(null);
  const [rescheduleNotes, setRescheduleNotes] = useState('');
  const [rescheduling, setRescheduling] = useState(false);

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    setLoading(true);
    try {
      const data = await bookingApi.getMyBookings();
      setBookings(data);
    } catch (err: any) {
      setError('Failed to fetch your bookings.');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadTicket = async (bookingId: number, ref: string) => {
    try {
      const blob = await bookingApi.downloadTicketPdfBlob(bookingId);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `FlightAI-Ticket-${ref}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      alert('Failed to download ticket PDF.');
    }
  };

  // Open Cancel Modal
  const openCancelModal = async (booking: Booking) => {
    setSelectedBookingForCancel(booking);
    try {
      const preview = await cancellationApi.previewCancellationRefund(booking.id);
      setCancelPreview(preview);
    } catch (err) {
      setCancelPreview({
        originalAmount: booking.totalAmount,
        cancellationFee: Math.round(booking.totalAmount * 0.25),
        estimatedRefund: Math.round(booking.totalAmount * 0.75),
      });
    }
  };

  // Confirm Cancellation
  const handleConfirmCancellation = async () => {
    if (!selectedBookingForCancel) return;
    setCancelling(true);
    try {
      await cancellationApi.requestCancellation({
        bookingId: selectedBookingForCancel.id,
        reason: cancelReason,
      });
      alert('Cancellation request submitted successfully.');
      setSelectedBookingForCancel(null);
      fetchBookings();
    } catch (err: any) {
      alert(err.response?.data?.message || 'Cancellation request failed.');
    } finally {
      setCancelling(false);
    }
  };

  // Open Reschedule Modal
  const openRescheduleModal = async (booking: Booking) => {
    setSelectedBookingForReschedule(booking);
    try {
      const flights = await flightApi.searchFlights({
        sourceAirport: booking.flight.sourceAirport.code,
        destinationAirport: booking.flight.destinationAirport.code,
      });
      // Filter out current flight
      const alternatives = flights.filter((f) => f.id !== booking.flight.id);
      setAvailableAlternativeFlights(alternatives);
      if (alternatives.length > 0) {
        setSelectedNewFlightId(alternatives[0].id);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Confirm Reschedule
  const handleConfirmReschedule = async () => {
    if (!selectedBookingForReschedule || !selectedNewFlightId) return;
    setRescheduling(true);
    try {
      await rescheduleApi.requestReschedule({
        bookingId: selectedBookingForReschedule.id,
        newFlightId: selectedNewFlightId,
        notes: rescheduleNotes,
      });
      alert('Reschedule request submitted successfully.');
      setSelectedBookingForReschedule(null);
      fetchBookings();
    } catch (err: any) {
      alert(err.response?.data?.message || 'Rescheduling request failed.');
    } finally {
      setRescheduling(false);
    }
  };

  if (loading) return <LoadingSpinner message="Loading your flight reservations..." />;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">My Bookings & E-Tickets</h1>
          <p className="text-xs text-slate-500">
            View tickets, download official PDFs, or request cancellation and rescheduling
          </p>
        </div>
        <Link
          to="/flights"
          className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 shadow-sm"
        >
          Book New Flight
        </Link>
      </div>

      {bookings.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
          <Ticket className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="text-base font-bold text-slate-800">No Reservations Found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            You have not booked any flights yet. Search our schedule to reserve a seat.
          </p>
          <Link
            to="/flights"
            className="inline-block px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold"
          >
            Search Flights
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {bookings.map((booking) => {
            const isCancellable = booking.status === 'CONFIRMED';
            return (
              <div
                key={booking.id}
                className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow p-6 space-y-4"
              >
                {/* Header row */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-3 border-b border-slate-100 gap-2">
                  <div className="flex items-center space-x-3">
                    <span className="font-mono text-sm font-extrabold text-indigo-700 bg-indigo-50 px-3 py-1 rounded-lg border border-indigo-200">
                      PNR: {booking.bookingReference}
                    </span>
                    <StatusBadge status={booking.status} type="booking" />
                  </div>
                  <div className="text-xs text-slate-400">
                    Booked on: {new Date(booking.bookingDate).toLocaleDateString()}
                  </div>
                </div>

                {/* Flight Schedule */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-bold text-slate-900">
                        {booking.flight.airline.name}
                      </span>
                      <span className="text-xs font-mono text-indigo-600">
                        {booking.flight.flightNumber}
                      </span>
                    </div>
                    <p className="text-base font-bold text-slate-900 mt-1">
                      {booking.flight.sourceAirport.city} ({booking.flight.sourceAirport.code})
                    </p>
                    <p className="text-xs text-slate-500">
                      Dep: {new Date(booking.flight.departureTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>

                  <div className="flex flex-col items-center">
                    <span className="text-xs text-slate-400 font-medium">Travel Date</span>
                    <span className="text-sm font-bold text-slate-800">{booking.travelDate}</span>
                    <div className="w-full flex items-center space-x-1 my-1">
                      <div className="h-0.5 flex-1 bg-slate-200"></div>
                      <Plane className="w-3.5 h-3.5 text-indigo-600 transform rotate-90" />
                      <div className="h-0.5 flex-1 bg-slate-200"></div>
                    </div>
                    <span className="text-[11px] text-slate-400">
                      {Math.floor(booking.flight.durationMinutes / 60)}h {booking.flight.durationMinutes % 60}m
                    </span>
                  </div>

                  <div className="text-left md:text-right">
                    <span className="text-xs text-slate-400 block">Destination</span>
                    <p className="text-base font-bold text-slate-900">
                      {booking.flight.destinationAirport.city} ({booking.flight.destinationAirport.code})
                    </p>
                    <p className="text-xs text-slate-500">
                      Arr: {new Date(booking.flight.arrivalTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>

                {/* Passengers & Seats */}
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex flex-wrap items-center justify-between text-xs gap-2">
                  <div className="text-slate-700">
                    <span className="font-semibold">Passenger(s): </span>
                    {booking.passengers.map((p) => `${p.fullName} [Seat ${p.seatNumber}]`).join(', ')}
                  </div>
                  <div className="font-extrabold text-slate-900">
                    Total: ₹{booking.totalAmount.toLocaleString()}
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-2 flex flex-wrap items-center justify-end gap-2.5">
                  <button
                    onClick={() => handleDownloadTicket(booking.id, booking.bookingReference)}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 transition-colors shadow-sm"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download PDF</span>
                  </button>

                  {isCancellable && (
                    <>
                      <button
                        onClick={() => openRescheduleModal(booking)}
                        className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-50 transition-colors"
                      >
                        <RotateCcw className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Reschedule</span>
                      </button>

                      <button
                        onClick={() => openCancelModal(booking)}
                        className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl border border-rose-200 text-rose-700 text-xs font-bold hover:bg-rose-50 transition-colors"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Cancel Booking</span>
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Cancellation Modal */}
      {selectedBookingForCancel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center space-x-2 text-rose-600">
              <AlertTriangle className="w-6 h-6" />
              <h3 className="text-lg font-bold">Cancel Flight Reservation</h3>
            </div>
            <p className="text-xs text-slate-600">
              Are you sure you want to cancel booking{' '}
              <span className="font-mono font-bold text-slate-900">
                {selectedBookingForCancel.bookingReference}
              </span>
              ?
            </p>

            {/* Refund breakdown */}
            {cancelPreview && (
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-600">Original Fare:</span>
                  <span className="font-bold">₹{cancelPreview.originalAmount?.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-rose-600">
                  <span>Cancellation Fee (Tiered Policy):</span>
                  <span>- ₹{cancelPreview.cancellationFee?.toLocaleString()}</span>
                </div>
                <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-sm text-emerald-700">
                  <span>Estimated Refund:</span>
                  <span>₹{cancelPreview.estimatedRefund?.toLocaleString()}</span>
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Reason for Cancellation
              </label>
              <textarea
                rows={2}
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-rose-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setSelectedBookingForCancel(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold hover:bg-slate-50"
              >
                Keep Booking
              </button>
              <button
                type="button"
                onClick={handleConfirmCancellation}
                disabled={cancelling}
                className="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold hover:bg-rose-700 disabled:opacity-50"
              >
                {cancelling ? 'Processing...' : 'Confirm Cancellation'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reschedule Modal */}
      {selectedBookingForReschedule && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center space-x-2 text-indigo-600">
              <RotateCcw className="w-6 h-6" />
              <h3 className="text-lg font-bold">Reschedule Flight</h3>
            </div>
            <p className="text-xs text-slate-600">
              Choose an alternative available flight on the same route for PNR{' '}
              <span className="font-mono font-bold text-slate-900">
                {selectedBookingForReschedule.bookingReference}
              </span>
              .
            </p>

            <div className="space-y-2 max-h-60 overflow-y-auto">
              <label className="block text-xs font-bold text-slate-700 uppercase">
                Available Alternative Flights
              </label>
              {availableAlternativeFlights.length === 0 ? (
                <p className="text-xs text-slate-500 p-4 text-center bg-slate-50 rounded-xl">
                  No other flights scheduled on this route today.
                </p>
              ) : (
                availableAlternativeFlights.map((alt) => (
                  <label
                    key={alt.id}
                    className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer text-xs transition-colors ${
                      selectedNewFlightId === alt.id
                        ? 'bg-indigo-50 border-indigo-400'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <input
                        type="radio"
                        name="newFlight"
                        checked={selectedNewFlightId === alt.id}
                        onChange={() => setSelectedNewFlightId(alt.id)}
                        className="text-indigo-600"
                      />
                      <div>
                        <span className="font-bold text-slate-900">
                          {alt.airline.name} • {alt.flightNumber}
                        </span>
                        <p className="text-[11px] text-slate-500">
                          Dep: {new Date(alt.departureTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>
                    <span className="font-extrabold text-slate-900">
                      ₹{alt.basePrice.toLocaleString()}
                    </span>
                  </label>
                ))
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Reason / Passenger Notes
              </label>
              <textarea
                rows={2}
                value={rescheduleNotes}
                onChange={(e) => setRescheduleNotes(e.target.value)}
                placeholder="Optional notes for staff review"
                className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setSelectedBookingForReschedule(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmReschedule}
                disabled={rescheduling || !selectedNewFlightId}
                className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 disabled:opacity-50"
              >
                {rescheduling ? 'Submitting...' : 'Submit Reschedule Request'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MyBookingsPage;
