import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Plane,
  Ticket,
  Luggage,
  HeartHandshake,
  Bot,
  AlertCircle,
  Clock,
  ArrowRight,
  Download,
  Calendar,
  Sparkles,
  CheckCircle,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { bookingApi, baggageApi, accessibilityApi } from '../../services/api';
import { Booking, BaggageCase, AccessibilityRequest } from '../../types';
import StatusBadge from '../../components/common/StatusBadge';
import LoadingSpinner from '../../components/common/LoadingSpinner';

export const PassengerDashboard: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [bookings, setBookings] = useState<Booking[]>([]);
  const [baggageCases, setBaggageCases] = useState<BaggageCase[]>([]);
  const [accessibilityRequests, setAccessibilityRequests] = useState<AccessibilityRequest[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const [bookingsData, baggageData, accessibilityData] = await Promise.all([
        bookingApi.getMyBookings(),
        baggageApi.getMyBaggageCases(),
        accessibilityApi.getMyRequests(),
      ]);
      setBookings(bookingsData);
      setBaggageCases(baggageData);
      setAccessibilityRequests(accessibilityData);
    } catch (err) {
      console.error('Failed to load passenger dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  const upcomingBookings = bookings.filter((b) => b.status === 'CONFIRMED');
  const nextFlight = upcomingBookings[0];

  const handleDownloadTicket = async (bookingId: number) => {
    try {
      const blob = await bookingApi.downloadTicketPdfBlob(bookingId);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `E-Ticket-${bookingId}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      alert('Could not download ticket PDF. Please verify backend status.');
    }
  };

  if (loading) {
    return <LoadingSpinner message="Loading your passenger portal..." />;
  }

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-sky-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-2">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/10 text-sky-200 text-xs font-semibold">
            <span>Verified Passenger</span>
            <span>•</span>
            <span>Frequent Flyer</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Welcome back, {user?.fullName}!
          </h1>
          <p className="text-xs sm:text-sm text-indigo-100">
            Manage your trips, download official PDF boarding passes, track baggage, or collaborate
            with the Multi-Agent Travel Assistant.
          </p>
          <div className="pt-2 flex flex-wrap gap-3">
            <Link
              to="/flights"
              className="px-4 py-2 rounded-xl bg-white text-indigo-900 text-xs font-bold hover:bg-slate-100 transition-colors shadow-sm"
            >
              Book Next Journey
            </Link>
            <Link
              to="/ai-chat"
              className="px-4 py-2 rounded-xl bg-indigo-600/80 hover:bg-indigo-600 text-white border border-indigo-400 text-xs font-bold transition-colors inline-flex items-center space-x-1.5"
            >
              <Bot className="w-3.5 h-3.5" />
              <span>Ask AI Assistant</span>
              <Sparkles className="w-3 h-3 text-amber-300 animate-pulse" />
            </Link>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Confirmed Trips
            </p>
            <p className="text-2xl font-black text-slate-900 mt-1">{upcomingBookings.length}</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Ticket className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Bookings</p>
            <p className="text-2xl font-black text-slate-900 mt-1">{bookings.length}</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center">
            <Plane className="w-5 h-5 transform -rotate-45" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Baggage Cases</p>
            <p className="text-2xl font-black text-slate-900 mt-1">{baggageCases.length}</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <Luggage className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Special Assistance
            </p>
            <p className="text-2xl font-black text-slate-900 mt-1">
              {accessibilityRequests.length}
            </p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <HeartHandshake className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Next Upcoming Flight Card */}
      {nextFlight ? (
        <div className="bg-white rounded-2xl border border-indigo-100 shadow-md p-6 relative overflow-hidden">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-slate-100 gap-2">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
                Your Next Scheduled Flight
              </span>
              <h3 className="text-lg font-bold text-slate-900 mt-0.5">
                PNR Reference: <span className="font-mono text-indigo-700">{nextFlight.bookingReference}</span>
              </h3>
            </div>
            <div className="flex items-center space-x-2">
              <StatusBadge status={nextFlight.flight.status} type="flight" />
              <button
                onClick={() => handleDownloadTicket(nextFlight.id)}
                className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>PDF Ticket</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-4 items-center">
            <div>
              <p className="text-xs font-bold text-slate-400">DEPARTURE</p>
              <p className="text-xl font-extrabold text-slate-900">
                {new Date(nextFlight.flight.departureTime).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </p>
              <p className="text-xs font-bold text-slate-700">
                {nextFlight.flight.sourceAirport.name} ({nextFlight.flight.sourceAirport.code})
              </p>
              <p className="text-[11px] text-slate-500">Travel Date: {nextFlight.travelDate}</p>
            </div>

            <div className="flex flex-col items-center">
              <span className="text-xs font-mono font-bold text-indigo-600">
                {nextFlight.flight.flightNumber}
              </span>
              <div className="w-full flex items-center space-x-2 my-2">
                <div className="h-0.5 flex-1 bg-slate-200"></div>
                <Plane className="w-4 h-4 text-indigo-600 transform rotate-90" />
                <div className="h-0.5 flex-1 bg-slate-200"></div>
              </div>
              <span className="text-[11px] text-slate-500">
                {nextFlight.flight.stops === 0 ? 'Non-Stop' : `${nextFlight.flight.stops} Stop`} •{' '}
                {Math.floor(nextFlight.flight.durationMinutes / 60)}h{' '}
                {nextFlight.flight.durationMinutes % 60}m
              </span>
            </div>

            <div className="text-left md:text-right">
              <p className="text-xs font-bold text-slate-400">ARRIVAL</p>
              <p className="text-xl font-extrabold text-slate-900">
                {new Date(nextFlight.flight.arrivalTime).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </p>
              <p className="text-xs font-bold text-slate-700">
                {nextFlight.flight.destinationAirport.name} (
                {nextFlight.flight.destinationAirport.code})
              </p>
              <p className="text-[11px] text-slate-500">
                Airline: {nextFlight.flight.airline.name}
              </p>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between text-xs text-slate-600 gap-2">
            <div>
              Passengers:{' '}
              <span className="font-semibold text-slate-900">
                {nextFlight.passengers.map((p) => `${p.fullName} (Seat ${p.seatNumber})`).join(', ')}
              </span>
            </div>
            <Link
              to={`/passenger/bookings`}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800 inline-flex items-center"
            >
              Manage this Booking <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </Link>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-3">
          <Plane className="w-8 h-8 text-slate-300 mx-auto transform -rotate-45" />
          <h3 className="text-base font-bold text-slate-800">No Upcoming Flights</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Ready to explore? Search from our 30+ scheduled flights across 8 Indian airports.
          </p>
          <Link
            to="/flights"
            className="inline-flex items-center px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 shadow-md shadow-indigo-200"
          >
            Search Flights Now
          </Link>
        </div>
      )}

      {/* Quick Action Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link
          to="/passenger/baggage"
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-indigo-300 hover:shadow-md transition-all space-y-2 group"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center group-hover:scale-105 transition-transform">
            <Luggage className="w-5 h-5" />
          </div>
          <h4 className="text-sm font-bold text-slate-900">Baggage Assistance</h4>
          <p className="text-xs text-slate-500">
            Check luggage rules, calculate cabin/check-in excess, or report delayed baggage.
          </p>
        </Link>

        <Link
          to="/passenger/accessibility"
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-indigo-300 hover:shadow-md transition-all space-y-2 group"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:scale-105 transition-transform">
            <HeartHandshake className="w-5 h-5" />
          </div>
          <h4 className="text-sm font-bold text-slate-900">Special Assistance</h4>
          <p className="text-xs text-slate-500">
            Request wheelchair, ramp assistance, visual escort, or elderly passenger support.
          </p>
        </Link>

        <Link
          to="/passenger/feedback"
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-indigo-300 hover:shadow-md transition-all space-y-2 group"
        >
          <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center group-hover:scale-105 transition-transform">
            <Sparkles className="w-5 h-5" />
          </div>
          <h4 className="text-sm font-bold text-slate-900">Feedback & AI Sentiment</h4>
          <p className="text-xs text-slate-500">
            Share flight feedback with instant real-time AI sentiment & category analysis.
          </p>
        </Link>
      </div>
    </div>
  );
};

export default PassengerDashboard;
