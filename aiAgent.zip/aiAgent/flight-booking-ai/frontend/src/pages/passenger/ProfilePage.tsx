import React from 'react';
import { User, Mail, Phone, Shield, Award, MapPin } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const ProfilePage: React.FC = () => {
  const { user } = useAuth();

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">Traveler Profile & Preferences</h1>
        <p className="text-xs text-slate-500">
          Manage your personal details, frequent flyer information, and travel settings
        </p>
      </div>

      {/* Profile Card */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
        <div className="flex items-center space-x-4 border-b border-slate-100 pb-5">
          <div className="w-16 h-16 rounded-2xl bg-indigo-600 text-white font-extrabold text-2xl flex items-center justify-center shadow-md shadow-indigo-200">
            {user?.fullName?.charAt(0).toUpperCase()}
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900">{user?.fullName}</h2>
            <p className="text-xs text-slate-500">{user?.email}</p>
            <span className="inline-block mt-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
              Role: {user?.role}
            </span>
          </div>
        </div>

        {/* Details Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="text-[10px] font-bold uppercase text-slate-400">Full Name</span>
            <p className="font-bold text-slate-800">{user?.fullName}</p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="text-[10px] font-bold uppercase text-slate-400">Email Address</span>
            <p className="font-bold text-slate-800">{user?.email}</p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="text-[10px] font-bold uppercase text-slate-400">Phone Number</span>
            <p className="font-bold text-slate-800">{user?.phone || '+91 9876543210'}</p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="text-[10px] font-bold uppercase text-slate-400">Account Status</span>
            <p className="font-bold text-emerald-600">Active / Verified</p>
          </div>
        </div>

        {/* Travel Preferences */}
        <div className="pt-4 border-t border-slate-100 space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
            Travel & Dining Preferences
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3 rounded-xl border border-slate-200">
              <span className="text-slate-400 block text-[10px]">Seat Preference</span>
              <span className="font-bold text-slate-800">Window Seat</span>
            </div>
            <div className="p-3 rounded-xl border border-slate-200">
              <span className="text-slate-400 block text-[10px]">Meal Preference</span>
              <span className="font-bold text-slate-800">Vegetarian Hindu Meal</span>
            </div>
            <div className="p-3 rounded-xl border border-slate-200">
              <span className="text-slate-400 block text-[10px]">Home Base Airport</span>
              <span className="font-bold text-slate-800">BOM (Mumbai)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
