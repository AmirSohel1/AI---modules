import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import {
  Plane,
  Clock,
  ArrowRight,
  Filter,
  Bot,
  Sliders,
  DollarSign,
  AlertTriangle,
  Sparkles,
} from 'lucide-react';
import { flightApi } from '../../services/api';
import { Flight } from '../../types';
import StatusBadge from '../../components/common/StatusBadge';
import LoadingSpinner from '../../components/common/LoadingSpinner';

export const FlightSearchResultsPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const sourceAirport = searchParams.get('sourceAirport') || '';
  const destinationAirport = searchParams.get('destinationAirport') || '';
  const date = searchParams.get('date') || '';

  const [flights, setFlights] = useState<Flight[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [selectedAirline, setSelectedAirline] = useState<string>('ALL');
  const [maxPrice, setMaxPrice] = useState<number>(15000);
  const [stopsFilter, setStopsFilter] = useState<string>('ALL'); // ALL, DIRECT, ONE_STOP
  const [sortBy, setSortBy] = useState<'PRICE_ASC' | 'DURATION_ASC' | 'DEPARTURE_ASC'>('PRICE_ASC');

  useEffect(() => {
    fetchFlights();
  }, [sourceAirport, destinationAirport, date]);

  const fetchFlights = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await flightApi.searchFlights({
        sourceAirport: sourceAirport || undefined,
        destinationAirport: destinationAirport || undefined,
        date: date || undefined,
      });
      setFlights(data);
    } catch (err: any) {
      setError('Failed to load flights. Please verify backend connection.');
    } finally {
      setLoading(false);
    }
  };

  // Filter & sort logic
  const filteredFlights = flights
    .filter((f) => {
      if (selectedAirline !== 'ALL' && f.airline.name !== selectedAirline) return false;
      if (f.basePrice > maxPrice) return false;
      if (stopsFilter === 'DIRECT' && f.stops > 0) return false;
      if (stopsFilter === 'ONE_STOP' && f.stops !== 1) return false;
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'PRICE_ASC') return a.basePrice - b.basePrice;
      if (sortBy === 'DURATION_ASC') return a.durationMinutes - b.durationMinutes;
      if (sortBy === 'DEPARTURE_ASC')
        return new Date(a.departureTime).getTime() - new Date(b.departureTime).getTime();
      return 0;
    });

  const uniqueAirlines = Array.from(new Set(flights.map((f) => f.airline.name)));

  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {/* Search Header Banner */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2 text-xs font-semibold text-indigo-600 uppercase tracking-wider">
              <span>Flight Search Results</span>
              <span>•</span>
              <span>{filteredFlights.length} Flights Available</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1 flex items-center space-x-3">
              <span>{sourceAirport || 'All Origins'}</span>
              <ArrowRight className="w-5 h-5 text-slate-400" />
              <span>{destinationAirport || 'All Destinations'}</span>
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Travel Date: {date || 'Any Date'}
            </p>
          </div>

          <div className="flex items-center space-x-3 w-full md:w-auto">
            <Link
              to={`/ai-chat?mode=MULTI_AGENT&query=${encodeURIComponent(
                `Find and recommend the best flights from ${sourceAirport} to ${destinationAirport}`
              )}`}
              className="inline-flex items-center space-x-2 px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-50 to-sky-50 text-indigo-700 border border-indigo-200 text-xs font-bold hover:border-indigo-400 transition-colors shadow-sm"
            >
              <Bot className="w-4 h-4 text-indigo-600" />
              <span>Ask AI Recommendation Agent</span>
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            </Link>
          </div>
        </div>

        {/* Content Layout: Filters + Flight List */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1 space-y-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-5">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <span className="font-bold text-slate-900 text-sm flex items-center space-x-2">
                  <Filter className="w-4 h-4 text-indigo-600" />
                  <span>Filters</span>
                </span>
                <button
                  onClick={() => {
                    setSelectedAirline('ALL');
                    setMaxPrice(15000);
                    setStopsFilter('ALL');
                    setSortBy('PRICE_ASC');
                  }}
                  className="text-xs text-indigo-600 hover:underline font-semibold"
                >
                  Reset
                </button>
              </div>

              {/* Sort By */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Sort By
                </label>
                <select
                  value={sortBy}
                  onChange={(e: any) => setSortBy(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                >
                  <option value="PRICE_ASC">Lowest Price (Cheapest)</option>
                  <option value="DURATION_ASC">Shortest Duration (Fastest)</option>
                  <option value="DEPARTURE_ASC">Earliest Departure</option>
                </select>
              </div>

              {/* Stops Filter */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Stops
                </label>
                <div className="space-y-1.5 text-xs font-medium text-slate-700">
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="stops"
                      checked={stopsFilter === 'ALL'}
                      onChange={() => setStopsFilter('ALL')}
                      className="text-indigo-600 focus:ring-indigo-500"
                    />
                    <span>All Flights</span>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="stops"
                      checked={stopsFilter === 'DIRECT'}
                      onChange={() => setStopsFilter('DIRECT')}
                      className="text-indigo-600 focus:ring-indigo-500"
                    />
                    <span>Direct (Non-Stop) Only</span>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="stops"
                      checked={stopsFilter === 'ONE_STOP'}
                      onChange={() => setStopsFilter('ONE_STOP')}
                      className="text-indigo-600 focus:ring-indigo-500"
                    />
                    <span>1 Stop</span>
                  </label>
                </div>
              </div>

              {/* Airlines */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Airlines
                </label>
                <select
                  value={selectedAirline}
                  onChange={(e) => setSelectedAirline(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                >
                  <option value="ALL">All Airlines</option>
                  {uniqueAirlines.map((airline) => (
                    <option key={airline} value={airline}>
                      {airline}
                    </option>
                  ))}
                </select>
              </div>

              {/* Max Budget */}
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Max Budget
                  </label>
                  <span className="text-xs font-bold text-indigo-600">₹{maxPrice.toLocaleString()}</span>
                </div>
                <input
                  type="range"
                  min={3000}
                  max={25000}
                  step={500}
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(Number(e.target.value))}
                  className="w-full accent-indigo-600 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Flight Results List */}
          <div className="lg:col-span-3 space-y-4">
            {loading ? (
              <LoadingSpinner message="Searching live flight schedules & seat inventory..." />
            ) : error ? (
              <div className="bg-rose-50 border border-rose-200 rounded-2xl p-6 text-center text-rose-700 text-xs">
                <AlertTriangle className="w-8 h-8 mx-auto mb-2 text-rose-500" />
                <p className="font-bold">{error}</p>
                <button
                  onClick={fetchFlights}
                  className="mt-3 px-4 py-1.5 bg-rose-600 text-white rounded-lg text-xs font-semibold hover:bg-rose-700"
                >
                  Retry Search
                </button>
              </div>
            ) : filteredFlights.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center space-y-3">
                <Plane className="w-10 h-10 text-slate-300 mx-auto transform -rotate-45" />
                <h3 className="text-base font-bold text-slate-800">No flights matched your criteria</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Try adjusting your budget slider, changing date, or clearing airline filters to see
                  available routes.
                </p>
              </div>
            ) : (
              filteredFlights.map((flight) => {
                const depTime = new Date(flight.departureTime);
                const arrTime = new Date(flight.arrivalTime);
                const hours = Math.floor(flight.durationMinutes / 60);
                const mins = flight.durationMinutes % 60;

                return (
                  <div
                    key={flight.id}
                    className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-5"
                  >
                    {/* Airline & Status */}
                    <div className="w-full md:w-48 flex-shrink-0">
                      <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-700 font-bold flex items-center justify-center text-xs">
                          {flight.airline.code}
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-900">{flight.airline.name}</p>
                          <p className="text-[11px] font-mono text-slate-500">{flight.flightNumber}</p>
                        </div>
                      </div>
                      <div className="mt-2">
                        <StatusBadge status={flight.status} type="flight" />
                      </div>
                    </div>

                    {/* Flight Schedule */}
                    <div className="flex-1 flex items-center justify-between space-x-4 w-full">
                      <div className="text-left">
                        <p className="text-lg font-extrabold text-slate-900">
                          {depTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                        <p className="text-xs font-bold text-slate-700">
                          {flight.sourceAirport.code}
                        </p>
                        <p className="text-[11px] text-slate-400 truncate max-w-[100px]">
                          {flight.sourceAirport.city}
                        </p>
                      </div>

                      <div className="flex-1 flex flex-col items-center px-2">
                        <span className="text-[10px] text-slate-400 font-medium mb-1">
                          {hours}h {mins}m
                        </span>
                        <div className="w-full flex items-center space-x-1">
                          <div className="h-0.5 flex-1 bg-slate-200"></div>
                          <Plane className="w-3.5 h-3.5 text-indigo-600 transform rotate-90" />
                          <div className="h-0.5 flex-1 bg-slate-200"></div>
                        </div>
                        <span className="text-[10px] text-slate-500 mt-1">
                          {flight.stops === 0 ? 'Non-stop' : `${flight.stops} Stop`}
                        </span>
                      </div>

                      <div className="text-right">
                        <p className="text-lg font-extrabold text-slate-900">
                          {arrTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                        <p className="text-xs font-bold text-slate-700">
                          {flight.destinationAirport.code}
                        </p>
                        <p className="text-[11px] text-slate-400 truncate max-w-[100px]">
                          {flight.destinationAirport.city}
                        </p>
                      </div>
                    </div>

                    {/* Price & Action */}
                    <div className="w-full md:w-44 flex md:flex-col items-center md:items-end justify-between border-t md:border-t-0 md:border-l border-slate-100 pt-3 md:pt-0 md:pl-5 gap-2">
                      <div className="text-left md:text-right">
                        <span className="text-[10px] text-slate-400 block">Economy Base</span>
                        <span className="text-xl font-black text-slate-900">
                          ₹{flight.basePrice.toLocaleString()}
                        </span>
                      </div>

                      <button
                        onClick={() =>
                          navigate(
                            `/passenger/book?flightId=${flight.id}&date=${
                              date || depTime.toISOString().split('T')[0]
                            }`
                          )
                        }
                        className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 shadow-md shadow-indigo-200 transition-colors"
                      >
                        Select Seats
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FlightSearchResultsPage;
