import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  Plane,
  Search,
  Bot,
  Calendar,
  ShieldCheck,
  Zap,
  Layers,
  Sparkles,
  ArrowRight,
  TrendingUp,
  MapPin,
  Clock,
  Award,
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const navigate = useNavigate();
  const [source, setSource] = useState('BOM');
  const [destination, setDestination] = useState('DEL');
  const [date, setDate] = useState('2026-11-25');
  const [cabinClass, setCabinClass] = useState('ECONOMY');

  const airports = [
    { code: 'BOM', city: 'Mumbai', name: 'Chhatrapati Shivaji Maharaj Int Airport' },
    { code: 'DEL', city: 'New Delhi', name: 'Indira Gandhi International Airport' },
    { code: 'BLR', city: 'Bengaluru', name: 'Kempegowda International Airport' },
    { code: 'MAA', city: 'Chennai', name: 'Chennai International Airport' },
    { code: 'HYD', city: 'Hyderabad', name: 'Rajiv Gandhi International Airport' },
    { code: 'CCU', city: 'Kolkata', name: 'Netaji Subhash Chandra Bose Int Airport' },
    { code: 'PNQ', city: 'Pune', name: 'Pune International Airport' },
    { code: 'GOI', city: 'Goa', name: 'Dabolim International Airport' },
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/flights?sourceAirport=${source}&destinationAirport=${destination}&date=${date}`);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-indigo-950 to-slate-900 text-white pt-16 pb-24">
        {/* Background glow effects */}
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-sky-500/15 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto space-y-4">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Multi-Agent LangGraph AI + Spring Boot Enterprise Core</span>
            </div>
            <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight leading-tight">
              AI-Powered Intelligent Flight Booking &{' '}
              <span className="bg-gradient-to-r from-sky-400 to-indigo-300 bg-clip-text text-transparent">
                Passenger Assistance
              </span>
            </h1>
            <p className="text-slate-300 text-base sm:text-lg">
              Experience seamless flight reservations backed by collaborative LangGraph AI agents,
              RAG-based policy assistance, automated disruption resolution, and role-based operations.
            </p>
          </div>

          {/* Flight Search Widget Card */}
          <div className="mt-10 max-w-4xl mx-auto bg-white rounded-2xl shadow-2xl p-6 sm:p-8 text-slate-800 border border-slate-100">
            <form onSubmit={handleSearch} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* Source Airport */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1 uppercase tracking-wider">
                    From (Departure)
                  </label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-indigo-600 absolute left-3 top-3" />
                    <select
                      value={source}
                      onChange={(e) => setSource(e.target.value)}
                      className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 text-sm font-semibold focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    >
                      {airports.map((a) => (
                        <option key={a.code} value={a.code}>
                          {a.city} ({a.code})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Destination Airport */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1 uppercase tracking-wider">
                    To (Arrival)
                  </label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-sky-600 absolute left-3 top-3" />
                    <select
                      value={destination}
                      onChange={(e) => setDestination(e.target.value)}
                      className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 text-sm font-semibold focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    >
                      {airports.map((a) => (
                        <option key={a.code} value={a.code}>
                          {a.city} ({a.code})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Date */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1 uppercase tracking-wider">
                    Travel Date
                  </label>
                  <div className="relative">
                    <Calendar className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                    <input
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 text-sm font-semibold focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Class */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1 uppercase tracking-wider">
                    Cabin Class
                  </label>
                  <select
                    value={cabinClass}
                    onChange={(e) => setCabinClass(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 text-sm font-semibold focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    <option value="ECONOMY">Economy Class</option>
                    <option value="BUSINESS">Business Class</option>
                  </select>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-between pt-2 border-t border-slate-100 gap-3">
                <div className="flex items-center space-x-2 text-xs text-slate-500">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" />
                  <span>Real-time MySQL seat inventory & concurrency locking</span>
                </div>
                <div className="flex items-center space-x-3 w-full sm:w-auto">
                  <Link
                    to="/ai-chat"
                    className="flex-1 sm:flex-initial inline-flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl border border-indigo-200 bg-indigo-50 text-indigo-700 text-xs font-bold hover:bg-indigo-100 transition-colors"
                  >
                    <Bot className="w-4 h-4" />
                    <span>Ask AI Agent to Search</span>
                  </Link>
                  <button
                    type="submit"
                    className="flex-1 sm:flex-initial inline-flex items-center justify-center space-x-2 px-6 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 shadow-md shadow-indigo-200 transition-colors"
                  >
                    <Search className="w-4 h-4" />
                    <span>Search Flights</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* Architecture Showcase: Single-Agent vs Multi-Agent */}
      <section className="py-16 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              Comparative AI Architecture
            </h2>
            <p className="text-slate-600 text-sm mt-2">
              Evaluate and demonstrate Single-Agent tool calling versus LangGraph Multi-Agent
              collaborative supervisor architecture with full live activity inspection.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Single Agent Card */}
            <div className="p-6 rounded-2xl border-2 border-slate-200 bg-slate-50 hover:border-slate-300 transition-all space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Zap className="w-6 h-6 text-indigo-600" />
                  <h3 className="text-lg font-bold text-slate-900">Single-Agent Architecture</h3>
                </div>
                <span className="px-2.5 py-1 text-xs font-bold rounded-full bg-slate-200 text-slate-700">
                  Smart Assistant
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                A unified autonomous assistant equipped with direct tool calling to execute flight
                searches, policy queries, and booking lookups.
              </p>
              <ul className="space-y-2 text-xs text-slate-700">
                <li className="flex items-center space-x-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-600"></span>
                  <span>Direct tool dispatch to Spring Boot APIs</span>
                </li>
                <li className="flex items-center space-x-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-600"></span>
                  <span>Lower latency on straightforward, single-domain inquiries</span>
                </li>
                <li className="flex items-center space-x-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-600"></span>
                  <span>Ideal for quick booking status checks and direct Q&A</span>
                </li>
              </ul>
              <div className="pt-3 border-t border-slate-200">
                <Link
                  to="/ai-chat?mode=SINGLE_AGENT"
                  className="text-xs font-bold text-indigo-600 hover:text-indigo-800 inline-flex items-center"
                >
                  Launch Single-Agent Assistant <ArrowRight className="w-3.5 h-3.5 ml-1" />
                </Link>
              </div>
            </div>

            {/* Multi-Agent Card */}
            <div className="p-6 rounded-2xl border-2 border-indigo-500 bg-gradient-to-br from-indigo-50/50 to-sky-50/50 hover:shadow-lg transition-all space-y-4 relative overflow-hidden">
              <div className="absolute top-3 right-3">
                <span className="px-2.5 py-1 text-xs font-bold rounded-full bg-indigo-600 text-white shadow-sm">
                  Recommended Architecture
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <Layers className="w-6 h-6 text-indigo-600" />
                <h3 className="text-lg font-bold text-slate-900">Multi-Agent Architecture</h3>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                LangGraph supervisor pipeline coordinating 8 specialized agents: Search,
                Recommendation, Booking, Disruption, Baggage, Sentiment, RAG, and Accessibility.
              </p>
              <ul className="space-y-2 text-xs text-slate-700">
                <li className="flex items-center space-x-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-600"></span>
                  <span>Dynamic intent classification and task delegation</span>
                </li>
                <li className="flex items-center space-x-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-600"></span>
                  <span>Deterministic multi-criteria recommendation scoring</span>
                </li>
                <li className="flex items-center space-x-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-600"></span>
                  <span>Live Agent Activity Panel showing each specialist's execution trace</span>
                </li>
              </ul>
              <div className="pt-3 border-t border-indigo-200">
                <Link
                  to="/ai-chat?mode=MULTI_AGENT"
                  className="text-xs font-bold text-indigo-700 hover:text-indigo-900 inline-flex items-center"
                >
                  Launch Multi-Agent Supervisor <ArrowRight className="w-3.5 h-3.5 ml-1" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Flights */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                Popular Domestic Routes
              </h2>
              <p className="text-slate-600 text-xs mt-1">
                Direct flights connecting major metro hubs with full live seat mapping
              </p>
            </div>
            <Link
              to="/flights"
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800 inline-flex items-center"
            >
              View all 30 flights <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                flight: 'AI-101',
                airline: 'Air India',
                route: 'BOM → DEL',
                time: '06:00 - 08:15',
                duration: '2h 15m',
                price: '₹5,400',
                stops: 'Non-stop',
              },
              {
                flight: '6E-202',
                airline: 'IndiGo',
                route: 'DEL → BLR',
                time: '07:30 - 10:15',
                duration: '2h 45m',
                price: '₹5,800',
                stops: 'Non-stop',
              },
              {
                flight: 'UK-801',
                airline: 'Vistara',
                route: 'BLR → BOM',
                time: '09:00 - 10:45',
                duration: '1h 45m',
                price: '₹4,900',
                stops: 'Non-stop',
              },
            ].map((f) => (
              <div
                key={f.flight}
                className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-center justify-between text-xs font-semibold text-slate-500 mb-2">
                    <span>{f.airline}</span>
                    <span className="font-mono text-indigo-600">{f.flight}</span>
                  </div>
                  <h4 className="text-base font-bold text-slate-900">{f.route}</h4>
                  <div className="flex items-center space-x-3 text-xs text-slate-600 mt-2">
                    <span className="flex items-center">
                      <Clock className="w-3.5 h-3.5 mr-1 text-slate-400" />
                      {f.duration}
                    </span>
                    <span>•</span>
                    <span>{f.stops}</span>
                    <span>•</span>
                    <span>{f.time}</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Starting from</span>
                    <span className="text-base font-extrabold text-slate-900">{f.price}</span>
                  </div>
                  <Link
                    to="/flights"
                    className="px-3.5 py-1.5 rounded-lg bg-indigo-50 text-indigo-700 text-xs font-bold hover:bg-indigo-100 transition-colors"
                  >
                    Book Now
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Academic Highlights Banner */}
      <section className="py-12 bg-indigo-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <p className="text-3xl font-extrabold text-sky-400">3 Roles</p>
              <p className="text-xs text-indigo-200 mt-1">Passenger, Staff & Admin</p>
            </div>
            <div>
              <p className="text-3xl font-extrabold text-sky-400">8 Agents</p>
              <p className="text-xs text-indigo-200 mt-1">LangGraph Multi-Agent Graph</p>
            </div>
            <div>
              <p className="text-3xl font-extrabold text-sky-400">25 Tables</p>
              <p className="text-xs text-indigo-200 mt-1">Flyway Migrations & JPA Core</p>
            </div>
            <div>
              <p className="text-3xl font-extrabold text-sky-400">100%</p>
              <p className="text-xs text-indigo-200 mt-1">Deterministic Local Demo Ready</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
