import React, { useState } from 'react';
import { Search, User, Ticket, Plane, Phone, Mail, AlertCircle } from 'lucide-react';
import { bookingApi } from '../../services/api';
import { Booking } from '../../types';
import StatusBadge from '../../components/common/StatusBadge';
import LoadingSpinner from '../../components/common/LoadingSpinner';

export const PassengerLookupPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [results, setResults] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchTerm.trim()) return;

    setLoading(true);
    setSearched(true);
    try {
      const data = await bookingApi.getAllBookings(searchTerm.trim());
      setResults(data);
    } catch (err) {
      console.error(err);
      setResults([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">Passenger & PNR Lookup</h1>
        <p className="text-xs text-slate-500">
          Search passenger reservations by PNR reference code, traveler name, or flight number
        </p>
      </div>

      {/* Search Input Box */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <form onSubmit={handleSearch} className="flex gap-3">
          <div className="relative flex-1">
            <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              required
              placeholder="Enter PNR Reference (e.g. PNR-1001), Passenger Name, or Flight No..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-11 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 shadow-md shadow-indigo-200 transition-colors disabled:opacity-50"
          >
            {loading ? 'Searching...' : 'Search Records'}
          </button>
        </form>
      </div>

      {/* Results Section */}
      <div className="space-y-4">
        {loading ? (
          <LoadingSpinner message="Searching flight reservation database..." />
        ) : searched && results.length === 0 ? (
          <div className="bg-white p-10 rounded-2xl border border-slate-200 text-center space-y-2">
            <User className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="text-sm font-bold text-slate-700">No matching passenger records found</p>
            <p className="text-xs text-slate-400">
              Please double check the spelling or try searching by PNR reference.
            </p>
          </div>
        ) : (
          results.map((booking) => (
            <div
              key={booking.id}
              className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4"
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-3 border-b border-slate-100 gap-2">
                <div className="flex items-center space-x-3">
                  <span className="font-mono text-sm font-extrabold text-indigo-700 bg-indigo-50 px-3 py-1 rounded-lg border border-indigo-200">
                    PNR: {booking.bookingReference}
                  </span>
                  <StatusBadge status={booking.status} type="booking" />
                </div>
                <div className="text-xs text-slate-400">
                  Travel Date: <span className="font-bold text-slate-700">{booking.travelDate}</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div>
                  <span className="text-slate-400 block uppercase font-bold text-[10px]">
                    Flight & Airline
                  </span>
                  <p className="font-bold text-slate-900 text-sm mt-0.5">
                    {booking.flight.airline.name} • {booking.flight.flightNumber}
                  </p>
                  <p className="text-slate-500">
                    {booking.flight.sourceAirport.code} → {booking.flight.destinationAirport.code}
                  </p>
                </div>

                <div>
                  <span className="text-slate-400 block uppercase font-bold text-[10px]">
                    Contact Information
                  </span>
                  <p className="text-slate-700 mt-0.5 flex items-center">
                    <Mail className="w-3.5 h-3.5 mr-1 text-slate-400" />
                    {booking.contactEmail}
                  </p>
                  <p className="text-slate-700 flex items-center">
                    <Phone className="w-3.5 h-3.5 mr-1 text-slate-400" />
                    {booking.contactPhone}
                  </p>
                </div>

                <div>
                  <span className="text-slate-400 block uppercase font-bold text-[10px]">
                    Payment Status
                  </span>
                  <p className="text-base font-extrabold text-slate-900 mt-0.5">
                    ₹{booking.totalAmount.toLocaleString()}
                  </p>
                  <span className="text-[11px] text-emerald-600 font-semibold">
                    Paid via UPI / Card
                  </span>
                </div>
              </div>

              {/* Passengers on this PNR */}
              <div className="pt-3 border-t border-slate-100">
                <h4 className="text-[11px] font-bold text-slate-500 uppercase mb-2">
                  Passengers on this booking
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                  {booking.passengers.map((p) => (
                    <div
                      key={p.id}
                      className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 text-xs flex justify-between items-center"
                    >
                      <div>
                        <p className="font-bold text-slate-900">{p.fullName}</p>
                        <p className="text-[10px] text-slate-500">
                          {p.age} yrs • {p.gender}
                        </p>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 font-mono font-bold text-xs">
                        {p.seatNumber}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default PassengerLookupPage;
