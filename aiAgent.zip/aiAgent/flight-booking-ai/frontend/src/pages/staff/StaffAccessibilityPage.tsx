import React, { useState, useEffect } from 'react';
import { HeartHandshake, CheckCircle, UserCheck } from 'lucide-react';
import { accessibilityApi } from '../../services/api';
import { AccessibilityRequest } from '../../types';
import StatusBadge from '../../components/common/StatusBadge';
import LoadingSpinner from '../../components/common/LoadingSpinner';

export const StaffAccessibilityPage: React.FC = () => {
  const [requests, setRequests] = useState<AccessibilityRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedRequest, setSelectedRequest] = useState<AccessibilityRequest | null>(null);
  const [newStatus, setNewStatus] = useState<string>('ASSIGNED');
  const [assignedStaff, setAssignedStaff] = useState<string>('Ramesh Kumar (Ground Team)');
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = async () => {
    setLoading(true);
    try {
      const data = await accessibilityApi.getAllRequests();
      setRequests(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRequest) return;

    setUpdating(true);
    try {
      await accessibilityApi.updateRequestStatus(selectedRequest.id, {
        status: newStatus,
        assignedStaffName: assignedStaff,
      });
      alert('Special assistance task assigned and updated.');
      setSelectedRequest(null);
      fetchRequests();
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed to update assistance request.');
    } finally {
      setUpdating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">
          Airport Special Assistance Queue
        </h1>
        <p className="text-xs text-slate-500">
          Assign airport ground staff for wheelchair transit, visual guides, and elderly care
        </p>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-sm">
            Assistance Requests ({requests.length})
          </h3>
        </div>

        {loading ? (
          <LoadingSpinner message="Loading special assistance queue..." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-100">
                <tr>
                  <th className="px-5 py-3">PNR</th>
                  <th className="px-5 py-3">Passenger</th>
                  <th className="px-5 py-3">Service Type</th>
                  <th className="px-5 py-3">Details</th>
                  <th className="px-5 py-3">Assigned Staff</th>
                  <th className="px-5 py-3">Status</th>
                  <th className="px-5 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {requests.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-5 py-3.5 font-mono font-bold text-indigo-700">
                      {r.bookingReference}
                    </td>
                    <td className="px-5 py-3.5 font-bold text-slate-900">{r.passengerName}</td>
                    <td className="px-5 py-3.5 font-semibold text-slate-700">{r.serviceType}</td>
                    <td className="px-5 py-3.5 max-w-xs truncate text-slate-500">{r.details}</td>
                    <td className="px-5 py-3.5 text-slate-700">
                      {r.assignedStaffName || <span className="text-slate-400">Unassigned</span>}
                    </td>
                    <td className="px-5 py-3.5">
                      <StatusBadge status={r.status} type="accessibility" />
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <button
                        onClick={() => {
                          setSelectedRequest(r);
                          setNewStatus(r.status === 'PENDING' ? 'ASSIGNED' : r.status);
                          setAssignedStaff(r.assignedStaffName || 'Ramesh Kumar (Ground Team)');
                        }}
                        className="px-3 py-1 rounded-lg bg-indigo-50 text-indigo-700 font-bold hover:bg-indigo-100"
                      >
                        Manage
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Manage Modal */}
      {selectedRequest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center space-x-2 text-indigo-600">
              <HeartHandshake className="w-6 h-6" />
              <h3 className="text-lg font-bold">Assign Ground Operations Staff</h3>
            </div>
            <p className="text-xs text-slate-600">
              Passenger:{' '}
              <span className="font-bold text-slate-900">{selectedRequest.passengerName}</span> (PNR:{' '}
              {selectedRequest.bookingReference})
            </p>

            <form onSubmit={handleUpdate} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Assign Staff Member
                </label>
                <input
                  type="text"
                  required
                  value={assignedStaff}
                  onChange={(e) => setAssignedStaff(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-semibold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Assistance Status
                </label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-bold"
                >
                  <option value="PENDING">PENDING (Awaiting Staff)</option>
                  <option value="ASSIGNED">ASSIGNED (Staff Dispatched to Gate)</option>
                  <option value="COMPLETED">COMPLETED (Passenger Boarded)</option>
                  <option value="CANCELLED">CANCELLED</option>
                </select>
              </div>

              <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSelectedRequest(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={updating}
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 disabled:opacity-50"
                >
                  {updating ? 'Saving...' : 'Confirm Assignment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default StaffAccessibilityPage;
