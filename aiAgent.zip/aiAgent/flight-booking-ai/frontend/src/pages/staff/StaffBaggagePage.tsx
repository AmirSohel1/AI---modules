import React, { useState, useEffect } from 'react';
import { Luggage, Edit3, CheckCircle, Search, AlertTriangle } from 'lucide-react';
import { baggageApi } from '../../services/api';
import { BaggageCase } from '../../types';
import StatusBadge from '../../components/common/StatusBadge';
import LoadingSpinner from '../../components/common/LoadingSpinner';

export const StaffBaggagePage: React.FC = () => {
  const [cases, setCases] = useState<BaggageCase[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCase, setSelectedCase] = useState<BaggageCase | null>(null);
  const [newStatus, setNewStatus] = useState<any>('INVESTIGATING');
  const [internalNotes, setInternalNotes] = useState('');
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    fetchCases();
  }, []);

  const fetchCases = async () => {
    setLoading(true);
    try {
      const data = await baggageApi.getAllBaggageCases();
      setCases(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCase) return;

    setUpdating(true);
    try {
      await baggageApi.updateBaggageStatus(selectedCase.id, {
        status: newStatus,
        internalNotes,
      });
      alert(`Baggage case ${selectedCase.caseReference} updated to ${newStatus}.`);
      setSelectedCase(null);
      fetchCases();
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed to update case.');
    } finally {
      setUpdating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">
          Baggage Operations & Case Tracking
        </h1>
        <p className="text-xs text-slate-500">
          Manage mishandled, delayed, and damaged baggage reports across airport carousels
        </p>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-sm">All Baggage Cases ({cases.length})</h3>
        </div>

        {loading ? (
          <LoadingSpinner message="Loading baggage cases..." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-100">
                <tr>
                  <th className="px-5 py-3">Case Ref</th>
                  <th className="px-5 py-3">Tag / Flight</th>
                  <th className="px-5 py-3">Type</th>
                  <th className="px-5 py-3">Description</th>
                  <th className="px-5 py-3">Status</th>
                  <th className="px-5 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {cases.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-5 py-3.5">
                      <span className="font-mono font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                        {c.caseReference}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="font-mono font-bold text-slate-800">{c.tagNumber}</span>
                      <span className="block text-[11px] text-slate-400">Flight: {c.flightNumber}</span>
                    </td>
                    <td className="px-5 py-3.5">
                      <StatusBadge status={c.caseType} type="baggage" />
                    </td>
                    <td className="px-5 py-3.5 max-w-xs truncate text-slate-600">
                      {c.description}
                    </td>
                    <td className="px-5 py-3.5">
                      <StatusBadge status={c.status} type="baggage" />
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <button
                        onClick={() => {
                          setSelectedCase(c);
                          setNewStatus(c.status);
                          setInternalNotes(c.internalNotes || '');
                        }}
                        className="px-3 py-1 rounded-lg bg-indigo-50 text-indigo-700 font-bold hover:bg-indigo-100"
                      >
                        Update
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Update Modal */}
      {selectedCase && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center space-x-2 text-indigo-600">
              <Luggage className="w-6 h-6" />
              <h3 className="text-lg font-bold">Update Baggage Tracking Status</h3>
            </div>
            <p className="text-xs text-slate-600">
              Updating case{' '}
              <span className="font-mono font-bold text-slate-900">{selectedCase.caseReference}</span>{' '}
              (Tag #{selectedCase.tagNumber})
            </p>

            <form onSubmit={handleUpdateStatus} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Investigation Status
                </label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-bold"
                >
                  <option value="REPORTED">REPORTED (New Ticket)</option>
                  <option value="INVESTIGATING">INVESTIGATING (Ground Search in Progress)</option>
                  <option value="LOCATED">LOCATED (Found at Destination Airport)</option>
                  <option value="IN_TRANSIT">IN_TRANSIT (Dispatched for Delivery)</option>
                  <option value="DELIVERED">DELIVERED (Handed to Passenger)</option>
                  <option value="CLOSED">CLOSED (Resolved)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Internal Operations Notes
                </label>
                <textarea
                  rows={3}
                  value={internalNotes}
                  onChange={(e) => setInternalNotes(e.target.value)}
                  placeholder="e.g. Located on carousel 4 at DEL. Transferred to courier partner for residential delivery."
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-medium"
                />
              </div>

              <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSelectedCase(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={updating}
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 disabled:opacity-50"
                >
                  {updating ? 'Saving...' : 'Update Status'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default StaffBaggagePage;
