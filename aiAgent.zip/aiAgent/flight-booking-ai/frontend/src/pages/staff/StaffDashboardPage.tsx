import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  LayoutDashboard,
  Plane,
  AlertTriangle,
  Luggage,
  HeartHandshake,
  Users,
  Clock,
  ArrowRight,
  ShieldCheck,
  RotateCcw,
} from 'lucide-react';
import { flightApi, baggageApi, accessibilityApi, bookingApi } from '../../services/api';
import { Flight, BaggageCase, AccessibilityRequest, Booking } from '../../types';
import StatusBadge from '../../components/common/StatusBadge';
import LoadingSpinner from '../../components/common/LoadingSpinner';

export const StaffDashboardPage: React.FC = () => {
  const [flights, setFlights] = useState<Flight[]>([]);
  const [baggageCases, setBaggageCases] = useState<BaggageCase[]>([]);
  const [accessibilityRequests, setAccessibilityRequests] = useState<AccessibilityRequest[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStaffData();
  }, []);

  const fetchStaffData = async () => {
    setLoading(true);
    try {
      const [fData, bData, aData] = await Promise.all([
        flightApi.getAllFlights(),
        baggageApi.getAllBaggageCases(),
        accessibilityApi.getAllRequests(),
      ]);
      setFlights(fData);
      setBaggageCases(bData);
      setAccessibilityRequests(aData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const delayedFlights = flights.filter((f) => f.status === 'DELAYED');
  const cancelledFlights = flights.filter((f) => f.status === 'CANCELLED');
  const pendingBaggage = baggageCases.filter((b) => b.status === 'REPORTED' || b.status === 'INVESTIGATING');
  const pendingAssistance = accessibilityRequests.filter((a) => a.status === 'PENDING');

  if (loading) return <LoadingSpinner message="Loading airport ground operations data..." />;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30">
              Airport Operations Control (AOC)
            </span>
            <h1 className="text-2xl sm:text-3xl font-black">Staff Ground Operations</h1>
            <p className="text-xs sm:text-sm text-slate-300">
              Monitor flight disruptions, passenger accessibility assistance, and baggage cases.
            </p>
          </div>
          <Link
            to="/staff/disruptions"
            className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold transition-colors shadow-md"
          >
            Manage Flight Disruptions
          </Link>
        </div>
      </div>

      {/* KPI Counters */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Total Scheduled Flights
            </p>
            <p className="text-2xl font-black text-slate-900 mt-1">{flights.length}</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Plane className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Disrupted Flights
            </p>
            <p className="text-2xl font-black text-rose-600 mt-1">
              {delayedFlights.length + cancelledFlights.length}
            </p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
            <AlertTriangle className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Pending Baggage Cases
            </p>
            <p className="text-2xl font-black text-amber-600 mt-1">{pendingBaggage.length}</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <Luggage className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Pending Assistance
            </p>
            <p className="text-2xl font-black text-emerald-600 mt-1">
              {pendingAssistance.length}
            </p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <HeartHandshake className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Disruption Alert Banner if active */}
      {(delayedFlights.length > 0 || cancelledFlights.length > 0) && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-amber-800 font-bold text-sm">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
              <span>Active Disruption Operational Notice</span>
            </div>
            <Link
              to="/staff/disruptions"
              className="text-xs font-bold text-amber-800 hover:underline flex items-center"
            >
              Take Action in Disruption Center <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {[...delayedFlights, ...cancelledFlights].slice(0, 3).map((f) => (
              <div
                key={f.id}
                className="bg-white p-3 rounded-xl border border-amber-200 text-xs space-y-1"
              >
                <div className="flex justify-between items-center">
                  <span className="font-mono font-bold text-slate-900">{f.flightNumber}</span>
                  <StatusBadge status={f.status} type="flight" />
                </div>
                <p className="text-slate-600">
                  {f.sourceAirport.code} → {f.destinationAirport.code}
                </p>
                {f.delayReason && (
                  <p className="text-[11px] text-amber-700 italic">"{f.delayReason}"</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Two Column Section: Quick Tasks */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pending Special Assistance Queue */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-base font-bold text-slate-900 flex items-center space-x-2">
              <HeartHandshake className="w-4 h-4 text-emerald-600" />
              <span>Accessibility Queue</span>
            </h3>
            <Link
              to="/staff/accessibility"
              className="text-xs font-bold text-indigo-600 hover:underline"
            >
              View All ({accessibilityRequests.length})
            </Link>
          </div>

          {accessibilityRequests.slice(0, 4).map((a) => (
            <div
              key={a.id}
              className="p-3 rounded-xl border border-slate-100 bg-slate-50 flex items-center justify-between text-xs"
            >
              <div>
                <p className="font-bold text-slate-900">{a.passengerName}</p>
                <p className="text-[11px] text-slate-500">
                  PNR: {a.bookingReference} • {a.serviceType}
                </p>
              </div>
              <StatusBadge status={a.status} type="accessibility" />
            </div>
          ))}
        </div>

        {/* Pending Baggage Cases */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-base font-bold text-slate-900 flex items-center space-x-2">
              <Luggage className="w-4 h-4 text-amber-600" />
              <span>Recent Baggage Cases</span>
            </h3>
            <Link
              to="/staff/baggage"
              className="text-xs font-bold text-indigo-600 hover:underline"
            >
              View All ({baggageCases.length})
            </Link>
          </div>

          {baggageCases.slice(0, 4).map((b) => (
            <div
              key={b.id}
              className="p-3 rounded-xl border border-slate-100 bg-slate-50 flex items-center justify-between text-xs"
            >
              <div>
                <span className="font-mono font-bold text-slate-900">
                  Tag: {b.tagNumber} ({b.flightNumber})
                </span>
                <p className="text-[11px] text-slate-500 truncate max-w-xs">{b.description}</p>
              </div>
              <StatusBadge status={b.status} type="baggage" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StaffDashboardPage;
