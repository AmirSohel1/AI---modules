import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  Plane,
  Users,
  RotateCcw,
  Sparkles,
  Bot,
  Send,
  CheckCircle,
  Clock,
  ArrowRight,
} from 'lucide-react';
import { flightApi, bookingApi } from '../../services/api';
import { Flight, Booking } from '../../types';
import StatusBadge from '../../components/common/StatusBadge';
import LoadingSpinner from '../../components/common/LoadingSpinner';

export const StaffDisruptionPage: React.FC = () => {
  const [flights, setFlights] = useState<Flight[]>([]);
  const [loading, setLoading] = useState(true);

  // Status Change Modal State
  const [selectedFlight, setSelectedFlight] = useState<Flight | null>(null);
  const [newStatus, setNewStatus] = useState<string>('DELAYED');
  const [delayMinutes, setDelayMinutes] = useState<number>(45);
  const [delayReason, setDelayReason] = useState<string>('Air traffic control congestion at BOM');
  const [updating, setUpdating] = useState(false);

  // Affected Passengers inspection
  const [affectedPassengers, setAffectedPassengers] = useState<any[]>([]);
  const [inspectingFlight, setInspectingFlight] = useState<Flight | null>(null);
  const [loadingAffected, setLoadingAffected] = useState(false);
  const [notifiedCount, setNotifiedCount] = useState<number | null>(null);

  useEffect(() => {
    fetchFlights();
  }, []);

  const fetchFlights = async () => {
    setLoading(true);
    try {
      const data = await flightApi.getAllFlights();
      setFlights(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateFlightStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFlight) return;

    setUpdating(true);
    try {
      await flightApi.updateFlightStatus(selectedFlight.id, {
        status: newStatus,
        delayMinutes: newStatus === 'DELAYED' ? delayMinutes : 0,
        delayReason: newStatus === 'DELAYED' || newStatus === 'CANCELLED' ? delayReason : undefined,
      });

      alert(`Flight ${selectedFlight.flightNumber} status successfully updated to ${newStatus}.`);
      setSelectedFlight(null);
      fetchFlights();
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed to update flight status.');
    } finally {
      setUpdating(false);
    }
  };

  const inspectAffectedPassengers = async (flight: Flight) => {
    setInspectingFlight(flight);
    setLoadingAffected(true);
    setNotifiedCount(null);
    try {
      const allBookings = await bookingApi.getAllBookings();
      const affected = allBookings.filter(
        (b) => b.flight.id === flight.id && b.status === 'CONFIRMED'
      );
      setAffectedPassengers(affected);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingAffected(false);
    }
  };

  const triggerAutomatedDisruptionAlerts = () => {
    setNotifiedCount(affectedPassengers.length);
    alert(
      `Disruption notifications sent to all ${affectedPassengers.length} passengers via SMS & Email!`
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">
            Flight Disruption Control Center
          </h1>
          <p className="text-xs text-slate-500">
            Simulate delays and cancellations, inspect affected passengers, and trigger AI
            rescheduling recommendations
          </p>
        </div>
      </div>

      {/* Flight Schedule Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-sm">Active Flight Schedules ({flights.length})</h3>
          <span className="text-xs text-slate-400">Click "Update Status" to simulate disruption</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-100">
              <tr>
                <th className="px-5 py-3">Flight</th>
                <th className="px-5 py-3">Route</th>
                <th className="px-5 py-3">Departure</th>
                <th className="px-5 py-3">Arrival</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {flights.map((flight) => (
                <tr key={flight.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="px-5 py-3.5">
                    <span className="font-mono font-bold text-slate-900">{flight.flightNumber}</span>
                    <span className="block text-[11px] text-slate-400">{flight.airline.name}</span>
                  </td>
                  <td className="px-5 py-3.5">
                    <span className="font-semibold text-slate-800">
                      {flight.sourceAirport.code} → {flight.destinationAirport.code}
                    </span>
                  </td>
                  <td className="px-5 py-3.5">
                    {new Date(flight.departureTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </td>
                  <td className="px-5 py-3.5">
                    {new Date(flight.arrivalTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </td>
                  <td className="px-5 py-3.5">
                    <StatusBadge status={flight.status} type="flight" />
                    {flight.delayMinutes ? (
                      <span className="text-[10px] text-amber-600 block mt-0.5">
                        +{flight.delayMinutes} mins delay
                      </span>
                    ) : null}
                  </td>
                  <td className="px-5 py-3.5 text-right space-x-2">
                    <button
                      onClick={() => inspectAffectedPassengers(flight)}
                      className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 font-semibold hover:bg-slate-200"
                    >
                      Inspect Passengers
                    </button>
                    <button
                      onClick={() => {
                        setSelectedFlight(flight);
                        setNewStatus(flight.status);
                        setDelayReason(flight.delayReason || 'Weather / Technical delay');
                      }}
                      className="px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 font-bold hover:bg-indigo-100"
                    >
                      Update Status
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Affected Passengers Inspection Card */}
      {inspectingFlight && (
        <div className="bg-white rounded-2xl border border-indigo-200 shadow-md p-6 space-y-4 animate-in fade-in duration-150">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-3 border-b border-slate-100 gap-2">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
                Disruption Passenger Manifest
              </span>
              <h3 className="text-base font-bold text-slate-900 mt-0.5">
                Flight {inspectingFlight.flightNumber} ({inspectingFlight.sourceAirport.code} →{' '}
                {inspectingFlight.destinationAirport.code})
              </h3>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={triggerAutomatedDisruptionAlerts}
                className="px-3.5 py-1.5 rounded-xl bg-amber-500 text-slate-950 text-xs font-bold hover:bg-amber-600 flex items-center space-x-1"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Notify All Affected ({affectedPassengers.length})</span>
              </button>
              <button
                onClick={() => setInspectingFlight(null)}
                className="text-xs text-slate-400 hover:text-slate-600 px-2"
              >
                Close
              </button>
            </div>
          </div>

          {loadingAffected ? (
            <LoadingSpinner message="Scanning booking database for affected passengers..." />
          ) : affectedPassengers.length === 0 ? (
            <p className="text-xs text-slate-500 py-4 text-center">
              No passengers currently booked on this flight.
            </p>
          ) : (
            <div className="space-y-2">
              {affectedPassengers.map((b) => (
                <div
                  key={b.id}
                  className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs flex flex-wrap items-center justify-between gap-2"
                >
                  <div className="flex items-center space-x-3">
                    <span className="font-mono font-bold text-indigo-700 bg-white px-2 py-0.5 rounded border border-indigo-100">
                      {b.bookingReference}
                    </span>
                    <span className="font-semibold text-slate-800">
                      {b.passengers.map((p: any) => p.fullName).join(', ')}
                    </span>
                  </div>
                  <div className="text-slate-500">
                    Contact: {b.contactPhone} • {b.contactEmail}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Status Update Modal */}
      {selectedFlight && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center space-x-2 text-indigo-600">
              <Plane className="w-6 h-6" />
              <h3 className="text-lg font-bold">Update Flight Operational Status</h3>
            </div>
            <p className="text-xs text-slate-600">
              Updating status for flight{' '}
              <span className="font-mono font-bold text-slate-900">
                {selectedFlight.flightNumber}
              </span>{' '}
              ({selectedFlight.sourceAirport.code} → {selectedFlight.destinationAirport.code})
            </p>

            <form onSubmit={handleUpdateFlightStatus} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Operational Status
                </label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-bold"
                >
                  <option value="SCHEDULED">SCHEDULED (Normal)</option>
                  <option value="DELAYED">DELAYED (Air Traffic / Weather)</option>
                  <option value="CANCELLED">CANCELLED (Technical / Extreme Weather)</option>
                  <option value="DEPARTED">DEPARTED (Airborne)</option>
                  <option value="ARRIVED">ARRIVED (Landed)</option>
                </select>
              </div>

              {newStatus === 'DELAYED' && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Delay Duration (Minutes)
                  </label>
                  <input
                    type="number"
                    min={5}
                    max={600}
                    value={delayMinutes}
                    onChange={(e) => setDelayMinutes(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-semibold"
                  />
                </div>
              )}

              {(newStatus === 'DELAYED' || newStatus === 'CANCELLED') && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Disruption Reason / Explanation
                  </label>
                  <input
                    type="text"
                    required
                    value={delayReason}
                    onChange={(e) => setDelayReason(e.target.value)}
                    placeholder="e.g. Heavy monsoon rain & low visibility at BOM"
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-medium"
                  />
                </div>
              )}

              <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSelectedFlight(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={updating}
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 disabled:opacity-50"
                >
                  {updating ? 'Updating...' : 'Save & Propagate Disruption'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default StaffDisruptionPage;
