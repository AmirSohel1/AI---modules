import axios from 'axios';
import {
  AuthResponse,
  Flight,
  FlightSeat,
  Booking,
  CancellationRequest,
  RescheduleRequest,
  BaggageCase,
  AccessibilityRequest,
  Feedback,
  Notification,
  AnalyticsOverview,
  RouteBooking,
  MonthlyTrend,
  KnowledgeDocument,
  User,
} from '../types';

const API_BASE_URL = 'http://localhost:8080/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to attach JWT token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor to handle unauthenticated errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      // Token expired or invalid
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      if (window.location.pathname !== '/login' && window.location.pathname !== '/') {
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

// ================= AUTH APIS =================
export const authApi = {
  login: async (email: string, password: string): Promise<AuthResponse> => {
    const res = await api.post<AuthResponse>('/auth/login', { email, password });
    return res.data;
  },
  register: async (data: {
    fullName: string;
    email: string;
    password: string;
    phone?: string;
  }): Promise<AuthResponse> => {
    const res = await api.post<AuthResponse>('/auth/register', data);
    return res.data;
  },
  getCurrentUser: async (): Promise<User> => {
    const res = await api.get<User>('/auth/me');
    return res.data;
  },
};

// ================= FLIGHTS APIS =================
export const flightApi = {
  searchFlights: async (params: {
    sourceAirport?: string;
    destinationAirport?: string;
    date?: string;
    airline?: string;
    maxPrice?: number;
    maxStops?: number;
    status?: string;
  }): Promise<Flight[]> => {
    const res = await api.get<Flight[]>('/flights/search', { params });
    return res.data;
  },
  getAllFlights: async (): Promise<Flight[]> => {
    const res = await api.get<Flight[]>('/flights');
    return res.data;
  },
  getFlightById: async (id: number): Promise<Flight> => {
    const res = await api.get<Flight>(`/flights/${id}`);
    return res.data;
  },
  getFlightSeats: async (flightId: number): Promise<FlightSeat[]> => {
    const res = await api.get<FlightSeat[]>(`/flights/${flightId}/seats`);
    return res.data;
  },
  updateFlightStatus: async (
    flightId: number,
    data: {
      status: string;
      delayReason?: string;
      delayMinutes?: number;
    }
  ): Promise<Flight> => {
    const res = await api.put<Flight>(`/flights/${flightId}/status`, data);
    return res.data;
  },
  createFlight: async (data: any): Promise<Flight> => {
    const res = await api.post<Flight>('/flights', data);
    return res.data;
  },
};

// ================= BOOKINGS APIS =================
export const bookingApi = {
  createBooking: async (data: {
    flightId: number;
    travelDate: string;
    contactEmail: string;
    contactPhone: string;
    passengers: {
      fullName: string;
      age: number;
      gender: string;
      seatNumber: string;
    }[];
    paymentMethod: string;
  }): Promise<Booking> => {
    const res = await api.post<Booking>('/bookings', data);
    return res.data;
  },
  getMyBookings: async (): Promise<Booking[]> => {
    const res = await api.get<Booking[]>('/bookings/my-bookings');
    return res.data;
  },
  getBookingByReference: async (reference: string): Promise<Booking> => {
    const res = await api.get<Booking>(`/bookings/reference/${reference}`);
    return res.data;
  },
  getAllBookings: async (search?: string): Promise<Booking[]> => {
    const res = await api.get<Booking[]>('/bookings', { params: { search } });
    return res.data;
  },
  downloadTicketPdfUrl: (bookingId: number): string => {
    const token = localStorage.getItem('token') || '';
    return `${API_BASE_URL}/bookings/${bookingId}/ticket-pdf?token=${encodeURIComponent(token)}`;
  },
  downloadTicketPdfBlob: async (bookingId: number): Promise<Blob> => {
    const res = await api.get(`/bookings/${bookingId}/ticket-pdf`, {
      responseType: 'blob',
    });
    return res.data;
  },
};

// ================= CANCELLATIONS APIS =================
export const cancellationApi = {
  requestCancellation: async (data: {
    bookingId: number;
    reason: string;
  }): Promise<CancellationRequest> => {
    const res = await api.post<CancellationRequest>('/cancellations', data);
    return res.data;
  },
  previewCancellationRefund: async (bookingId: number): Promise<{
    bookingId: number;
    originalAmount: number;
    cancellationFee: number;
    estimatedRefund: number;
    hoursUntilDeparture: number;
  }> => {
    const res = await api.get(`/cancellations/preview/${bookingId}`);
    return res.data;
  },
  getAllCancellationRequests: async (): Promise<CancellationRequest[]> => {
    const res = await api.get<CancellationRequest[]>('/cancellations');
    return res.data;
  },
  processRefund: async (
    requestId: number,
    data: { status: 'APPROVED' | 'REJECTED'; notes?: string }
  ): Promise<CancellationRequest> => {
    const res = await api.put<CancellationRequest>(`/cancellations/${requestId}/process`, data);
    return res.data;
  },
};

// ================= RESCHEDULING APIS =================
export const rescheduleApi = {
  requestReschedule: async (data: {
    bookingId: number;
    newFlightId: number;
    notes?: string;
  }): Promise<RescheduleRequest> => {
    const res = await api.post<RescheduleRequest>('/reschedule', data);
    return res.data;
  },
  getAllRescheduleRequests: async (): Promise<RescheduleRequest[]> => {
    const res = await api.get<RescheduleRequest[]>('/reschedule');
    return res.data;
  },
  processReschedule: async (
    requestId: number,
    data: { status: 'APPROVED' | 'REJECTED'; notes?: string }
  ): Promise<RescheduleRequest> => {
    const res = await api.put<RescheduleRequest>(`/reschedule/${requestId}/process`, data);
    return res.data;
  },
};

// ================= BAGGAGE APIS =================
export const baggageApi = {
  reportCase: async (data: {
    bookingReference: string;
    flightNumber: string;
    tagNumber: string;
    caseType: 'MISSING' | 'DELAYED' | 'DAMAGED';
    description: string;
  }): Promise<BaggageCase> => {
    const res = await api.post<BaggageCase>('/baggage', data);
    return res.data;
  },
  getMyBaggageCases: async (): Promise<BaggageCase[]> => {
    const res = await api.get<BaggageCase[]>('/baggage/my-cases');
    return res.data;
  },
  getAllBaggageCases: async (): Promise<BaggageCase[]> => {
    const res = await api.get<BaggageCase[]>('/baggage');
    return res.data;
  },
  updateBaggageStatus: async (
    caseId: number,
    data: {
      status: 'REPORTED' | 'INVESTIGATING' | 'LOCATED' | 'IN_TRANSIT' | 'DELIVERED' | 'CLOSED';
      internalNotes?: string;
    }
  ): Promise<BaggageCase> => {
    const res = await api.put<BaggageCase>(`/baggage/${caseId}/status`, data);
    return res.data;
  },
};

// ================= ACCESSIBILITY APIS =================
export const accessibilityApi = {
  requestAssistance: async (data: {
    bookingReference: string;
    passengerName: string;
    serviceType: string;
    details: string;
  }): Promise<AccessibilityRequest> => {
    const res = await api.post<AccessibilityRequest>('/accessibility', data);
    return res.data;
  },
  getMyRequests: async (): Promise<AccessibilityRequest[]> => {
    const res = await api.get<AccessibilityRequest[]>('/accessibility/my-requests');
    return res.data;
  },
  getAllRequests: async (): Promise<AccessibilityRequest[]> => {
    const res = await api.get<AccessibilityRequest[]>('/accessibility');
    return res.data;
  },
  updateRequestStatus: async (
    id: number,
    data: { status: string; assignedStaffName?: string }
  ): Promise<AccessibilityRequest> => {
    const res = await api.put<AccessibilityRequest>(`/accessibility/${id}/status`, data);
    return res.data;
  },
};

// ================= FEEDBACK APIS =================
export const feedbackApi = {
  submitFeedback: async (data: {
    flightNumber?: string;
    rating: number;
    comment: string;
  }): Promise<Feedback> => {
    const res = await api.post<Feedback>('/feedback', data);
    return res.data;
  },
  getMyFeedback: async (): Promise<Feedback[]> => {
    const res = await api.get<Feedback[]>('/feedback/my-feedback');
    return res.data;
  },
  getAllFeedback: async (): Promise<Feedback[]> => {
    const res = await api.get<Feedback[]>('/feedback');
    return res.data;
  },
};

// ================= NOTIFICATIONS APIS =================
export const notificationApi = {
  getMyNotifications: async (): Promise<Notification[]> => {
    const res = await api.get<Notification[]>('/notifications/my-notifications');
    return res.data;
  },
  markAsRead: async (id: number): Promise<void> => {
    await api.put(`/notifications/${id}/read`);
  },
  markAllAsRead: async (): Promise<void> => {
    await api.put('/notifications/mark-all-read');
  },
};

// ================= ANALYTICS APIS =================
export const analyticsApi = {
  getOverview: async (): Promise<AnalyticsOverview> => {
    const res = await api.get<AnalyticsOverview>('/analytics/overview');
    return res.data;
  },
  getPopularRoutes: async (): Promise<RouteBooking[]> => {
    const res = await api.get<RouteBooking[]>('/analytics/popular-routes');
    return res.data;
  },
  getMonthlyTrends: async (): Promise<MonthlyTrend[]> => {
    const res = await api.get<MonthlyTrend[]>('/analytics/monthly-trends');
    return res.data;
  },
  getAiExecutionLogs: async (): Promise<any[]> => {
    const res = await api.get<any[]>('/analytics/ai-logs');
    return res.data;
  },
};

// ================= KNOWLEDGE BASE APIS =================
export const knowledgeApi = {
  getDocuments: async (): Promise<KnowledgeDocument[]> => {
    const res = await api.get<KnowledgeDocument[]>('/knowledge');
    return res.data;
  },
  uploadDocument: async (data: {
    title: string;
    category: string;
    filename: string;
    fileType: string;
    fullText: string;
  }): Promise<KnowledgeDocument> => {
    const res = await api.post<KnowledgeDocument>('/knowledge', data);
    return res.data;
  },
  deleteDocument: async (id: number): Promise<void> => {
    await api.delete(`/knowledge/${id}`);
  },
  testQuery: async (query: string): Promise<any> => {
    const res = await api.post('/ai/rag/query', { query });
    return res.data;
  },
};

// ================= USER MANAGEMENT (ADMIN) =================
export const userApi = {
  getAllUsers: async (): Promise<User[]> => {
    const res = await api.get<User[]>('/users');
    return res.data;
  },
  toggleUserStatus: async (userId: number): Promise<User> => {
    const res = await api.put<User>(`/users/${userId}/toggle-status`);
    return res.data;
  },
  createStaffUser: async (data: {
    fullName: string;
    email: string;
    password: string;
    phone?: string;
    department?: string;
  }): Promise<User> => {
    const res = await api.post<User>('/users/staff', data);
    return res.data;
  },
};

// ================= AI CHAT APIS =================
export interface AiChatRequest {
  message: string;
  conversationId?: number;
  mode: 'SINGLE_AGENT' | 'MULTI_AGENT';
}

export interface AiChatResponse {
  conversationId: number;
  response: string;
  mode: 'SINGLE_AGENT' | 'MULTI_AGENT';
  modelUsed: string;
  demoMode: boolean;
  agentTraces: {
    agentName: string;
    status: 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED';
    inputSummary?: string;
    outputSummary?: string;
    durationMs: number;
    order: number;
  }[];
  structuredData?: any;
}

export const aiApi = {
  sendMessage: async (data: AiChatRequest): Promise<AiChatResponse> => {
    const res = await api.post<AiChatResponse>('/ai/chat', data);
    return res.data;
  },
  getConversations: async (): Promise<any[]> => {
    const res = await api.get<any[]>('/ai/conversations');
    return res.data;
  },
  getMessages: async (conversationId: number): Promise<any[]> => {
    const res = await api.get<any[]>(`/ai/conversations/${conversationId}/messages`);
    return res.data;
  },
  deleteConversation: async (conversationId: number): Promise<void> => {
    await api.delete(`/ai/conversations/${conversationId}`);
  },
};

export default api;
