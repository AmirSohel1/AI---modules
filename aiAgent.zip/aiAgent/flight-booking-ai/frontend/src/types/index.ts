export interface User {
  id: number;
  username: string;
  email: string;
  fullName: string;
  phone?: string;
  role: 'PASSENGER' | 'STAFF' | 'ADMIN';
  status: string;
  createdAt?: string;
}

export interface AuthResponse {
  token: string;
  tokenType: string;
  user: User;
}

export interface Airline {
  id: number;
  code: string;
  name: string;
  logoUrl?: string;
  contactNumber?: string;
  status: string;
}

export interface Airport {
  id: number;
  code: string;
  name: string;
  city: string;
  country: string;
  terminalCount: number;
}

export interface Aircraft {
  id: number;
  model: string;
  registrationNumber: string;
  totalSeats: number;
  economySeats: number;
  businessSeats: number;
}

export interface Flight {
  id: number;
  flightNumber: string;
  airline: Airline;
  aircraft?: Aircraft;
  sourceAirport: Airport;
  destinationAirport: Airport;
  departureTime: string;
  arrivalTime: string;
  durationMinutes: number;
  stops: number;
  basePrice: number;
  status: 'SCHEDULED' | 'DELAYED' | 'CANCELLED' | 'DEPARTED' | 'ARRIVED';
  delayReason?: string;
  delayMinutes?: number;
  availableSeatsCount?: number;
}

export interface FlightSeat {
  id: number;
  flightId: number;
  seatNumber: string;
  seatClass: 'ECONOMY' | 'BUSINESS';
  priceMultiplier: number;
  isAvailable: boolean;
}

export interface BookingPassenger {
  id: number;
  fullName: string;
  age: number;
  gender: string;
  seatNumber: string;
  ticketNumber: string;
}

export interface Booking {
  id: number;
  bookingReference: string;
  userId: number;
  userName?: string;
  flight: Flight;
  bookingDate: string;
  travelDate: string;
  totalAmount: number;
  status: 'CONFIRMED' | 'CANCELLED' | 'RESCHEDULED' | 'PENDING';
  contactEmail: string;
  contactPhone: string;
  passengers: BookingPassenger[];
}

export interface CancellationRequest {
  id: number;
  bookingId: number;
  bookingReference: string;
  reason: string;
  originalAmount: number;
  cancellationFee: number;
  refundAmount: number;
  status: string;
  requestedAt: string;
  processedAt?: string;
  refundTransactionId?: string;
}

export interface RescheduleRequest {
  id: number;
  bookingId: number;
  bookingReference: string;
  oldFlightId: number;
  oldFlightNumber: string;
  newFlightId: number;
  newFlightNumber: string;
  fareDifference: number;
  fee: number;
  status: string;
  requestedAt: string;
  notes?: string;
}

export interface BaggageCase {
  id: number;
  bookingId: number;
  bookingReference: string;
  caseReference: string;
  caseType: 'MISSING' | 'DELAYED' | 'DAMAGED';
  flightId: number;
  flightNumber: string;
  tagNumber: string;
  description: string;
  status: 'REPORTED' | 'INVESTIGATING' | 'LOCATED' | 'IN_TRANSIT' | 'DELIVERED' | 'CLOSED';
  reportedAt: string;
  updatedAt?: string;
  internalNotes?: string;
}

export interface AccessibilityRequest {
  id: number;
  userId: number;
  passengerName: string;
  bookingId: number;
  bookingReference: string;
  flightNumber: string;
  serviceType: string;
  details: string;
  status: 'PENDING' | 'ASSIGNED' | 'COMPLETED' | 'CANCELLED';
  requestedAt: string;
  assignedStaffName?: string;
}

export interface Feedback {
  id: number;
  userId: number;
  userName: string;
  flightId?: number;
  flightNumber?: string;
  rating: number;
  comment: string;
  submittedAt: string;
  sentiment?: 'POSITIVE' | 'NEUTRAL' | 'NEGATIVE';
  category?: string;
  urgencyScore?: number;
  aiSummary?: string;
}

export interface Notification {
  id: number;
  userId: number;
  title: string;
  message: string;
  type: string;
  isRead: boolean;
  referenceId?: string;
  createdAt: string;
}

export interface AgentActivityLog {
  agentName: string;
  status: 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED';
  inputSummary?: string;
  outputSummary?: string;
  durationMs: number;
  order: number;
}

export interface AiMessage {
  id: number;
  conversationId: number;
  sender: 'USER' | 'ASSISTANT' | 'SYSTEM';
  content: string;
  messageMetadata?: string;
  createdAt: string;
}

export interface AiConversation {
  id: number;
  userId: number;
  mode: 'SINGLE_AGENT' | 'MULTI_AGENT';
  title: string;
  createdAt: string;
  updatedAt: string;
}

export interface KnowledgeDocument {
  id: number;
  title: string;
  category: string;
  filename: string;
  fileType: string;
  chunkCount: number;
  contentSummary?: string;
  fullText?: string;
}

export interface AnalyticsOverview {
  totalPassengers: number;
  totalFlights: number;
  totalBookings: number;
  totalRevenue: number;
  activeFlights: number;
  cancelledFlights: number;
  delayedFlights: number;
  pendingRefundRequests: number;
  pendingComplaints: number;
  averageRating: number;
}

export interface RouteBooking {
  route: string;
  sourceCity: string;
  destCity: string;
  bookingCount: number;
  totalRevenue: number;
}

export interface MonthlyTrend {
  month: string;
  bookingCount: number;
  revenue: number;
  cancellations: number;
}
