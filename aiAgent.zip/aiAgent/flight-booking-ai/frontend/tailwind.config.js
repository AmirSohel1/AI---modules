/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          navy: '#0f172a',
          sky: '#0284c7',
          light: '#f8fafc',
          accent: '#2563eb',
          gold: '#f59e0b',
        }
      }
    },
  },
  plugins: [],
}
