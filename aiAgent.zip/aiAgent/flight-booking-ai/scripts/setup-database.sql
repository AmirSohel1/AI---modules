-- Database setup script for FlightAI
CREATE DATABASE IF NOT EXISTS flight_booking_ai CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE flight_booking_ai;

-- Flyway will execute migrations:
-- V1__initial_schema.sql (creates 25 tables)
-- V2__seed_data.sql (seeds airlines, airports, aircraft, flights, seats, users, bookings, policies)
