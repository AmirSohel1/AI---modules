@echo off
title FlightAI FastAPI AI Service (Port 8000)
echo ========================================================
echo Starting FlightAI FastAPI LangGraph AI Service (Port 8000)
echo ========================================================
cd /d "%~dp0..\ai-service"
if exist .venv\Scripts\activate.bat (
    call .venv\Scripts\activate.bat
)
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
pause
