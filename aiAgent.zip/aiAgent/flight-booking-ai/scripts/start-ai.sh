#!/usr/bin/env bash
echo "========================================================"
echo "Starting FlightAI FastAPI LangGraph AI Service (Port 8000)"
echo "========================================================"
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
cd "$DIR/../ai-service"
if [ -d ".venv" ]; then
    source .venv/bin/activate
fi
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
