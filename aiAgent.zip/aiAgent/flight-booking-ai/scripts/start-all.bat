@echo off
title FlightAI Master Launcher
echo =======================================================================
echo Launching FlightAI Full-Stack Intelligent Booking & Multi-Agent System
echo =======================================================================
echo.
echo 1. Launching Java Spring Boot Backend in a new window...
start "FlightAI Backend (8080)" "%~dp0start-backend.bat"
timeout /t 5 /nobreak >nul

echo 2. Launching FastAPI LangGraph AI Service in a new window...
start "FlightAI AI Service (8000)" "%~dp0start-ai.bat"
timeout /t 3 /nobreak >nul

echo 3. Launching React Frontend in a new window...
start "FlightAI Frontend (5173)" "%~dp0start-frontend.bat"

echo.
echo =======================================================================
echo All services launched!
echo - React Web App:   http://localhost:5173
echo - Spring Boot API: http://localhost:8080/swagger-ui/index.html
echo - Python AI Docs:  http://localhost:8000/docs
echo =======================================================================
pause
