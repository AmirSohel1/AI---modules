#!/usr/bin/env bash
echo "======================================================================="
echo "Launching FlightAI Full-Stack Intelligent Booking & Multi-Agent System"
echo "======================================================================="
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

"$DIR/start-backend.sh" &
sleep 5
"$DIR/start-ai.sh" &
sleep 3
"$DIR/start-frontend.sh" &

echo "All services launched in background!"
