@echo off
title FlightAI Spring Boot Backend (Port 8080)
echo ========================================================
echo Starting FlightAI Java Spring Boot Backend (Port 8080)
echo ========================================================
cd /d "%~dp0..\backend"
call mvn spring-boot:run
pause
