#!/usr/bin/env bash
echo "========================================================"
echo "Starting FlightAI Java Spring Boot Backend (Port 8080)"
echo "========================================================"
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
cd "$DIR/../backend"
mvn spring-boot:run
