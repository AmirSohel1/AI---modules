@echo off
title FlightAI React Frontend (Port 5173)
echo ========================================================
echo Starting FlightAI React TypeScript Frontend (Port 5173)
echo ========================================================
cd /d "%~dp0..\frontend"
call npm run dev
pause
