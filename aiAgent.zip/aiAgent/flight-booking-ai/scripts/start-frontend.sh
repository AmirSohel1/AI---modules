#!/usr/bin/env bash
echo "========================================================"
echo "Starting FlightAI React TypeScript Frontend (Port 5173)"
echo "========================================================"
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
cd "$DIR/../frontend"
npm run dev
